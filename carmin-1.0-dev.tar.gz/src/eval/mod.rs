//! Static Evaluation: Advanced Tapered Hand-Crafted Evaluation (HCE)
//!
//! Modular evaluation pipeline with:
//! - Texel-calibrated PSTs
//! - Non-linear mobility tables
//! - Complex pawn structure (isolated, doubled, backward, phalanx, chain, passed)
//! - Advanced king safety (shelter, storm, attack units, weak squares)
//! - Full threat matrix (pawn→minor, minor→major, rook→queen, hanging, safe threats)
//! - Early queen development penalty
//! - Bad bishop detection
//! - Activity (flank attacks, useful vs cosmetic, defense >> attack)
//! - Inactivity (uncoordinated rooks/queens, isolated/passive pieces)
//! - Endgame scaling and mopup

pub mod params;
pub mod pawns;
pub mod pieces;
pub mod king_safety;
pub mod threats;
pub mod endgame;
pub mod advanced_pawns;
pub mod endgame_fortress;
pub mod initiative;
pub mod active;
pub mod inactive;
pub mod king_danger;
pub mod material_imbalance;
pub mod mobility;
pub mod outposts;
pub mod passed_pawns;
pub mod patterns;
pub mod space_control;

use crate::bitboard::iter;
use crate::board::Board;
use crate::types::{Color, PieceType, PIECE_TYPES};

// Re-export key constants for external use (search.rs etc.)
pub use params::{MATE, MATE_IN_MAX};

// ==============================================================================
// PAWN CACHE (thread-local — cada thread do Lazy SMP tem a sua, sem contenção)
// ==============================================================================

use std::cell::RefCell;

thread_local! {
    static PAWN_CACHE: RefCell<crate::pawn_cache::PawnCache> =
        RefCell::new(crate::pawn_cache::PawnCache::new());
    static EVAL_CACHE: RefCell<crate::eval_cache::EvalCache> =
        RefCell::new(crate::eval_cache::EvalCache::new());
}

/// Hash Zobrist só dos peões (brancos + pretos), usado como chave do pawn cache.
/// Reaproveita as mesmas chaves piece_key já usadas no hash principal do board,
/// então é barato (O(número de peões), no máximo 16 XORs) comparado a recalcular
/// toda a estrutura de peões do zero.
#[inline]
fn pawn_hash(board: &Board) -> u64 {
    let z = crate::zobrist::keys();
    let mut h = 0u64;
    for sq in iter(board.pieces_of(Color::White, PieceType::Pawn)) {
        h ^= z.piece_key(Color::White, PieceType::Pawn, sq);
    }
    for sq in iter(board.pieces_of(Color::Black, PieceType::Pawn)) {
        h ^= z.piece_key(Color::Black, PieceType::Pawn, sq);
    }
    h
}

// ==============================================================================
// EVAL STATE
// ==============================================================================


/// Central evaluation accumulator passed through all sub-evaluators.
pub struct EvalState {
    pub mg: [i32; 2],
    pub eg: [i32; 2],
    pub phase: i32,
    pub mob_area: [u64; 2],
    /// Combined attacks per side (union of all piece attacks).
    pub attacks: [u64; 2],
    /// Attacks broken down by piece type, per side.
    pub attacks_by: [[u64; 6]; 2],
    pub king_ring: [u64; 2],
    pub passed_pawns: [u64; 2],
    /// Pinned pieces by color
    pub pinned: [u64; 2],
}

impl EvalState {
    fn new() -> Self {
        Self {
            mg: [0; 2],
            eg: [0; 2],
            phase: 0,
            mob_area: [0; 2],
            attacks: [0; 2],
            attacks_by: [[0; 6]; 2],
            king_ring: [0; 2],
            passed_pawns: [0; 2],
            pinned: [0; 2],
        }
    }
}

// ==============================================================================
// MAIN EVALUATION PIPELINE
// ==============================================================================
pub fn _evaluate(board: &Board) -> i32 {
    let mut state = EvalState::new();

    // Material + PST
    evaluate_material_and_pst(board, &mut state);

    // Diferença White - Black
    let mg_score =
        state.mg[Color::White.index()] - state.mg[Color::Black.index()];

    let eg_score =
        state.eg[Color::White.index()] - state.eg[Color::Black.index()];

    // Tapered evaluation
    let phase = state.phase.min(params::MAX_PHASE);

    let mut score =
        (mg_score * phase
            + eg_score * (params::MAX_PHASE - phase))
        / params::MAX_PHASE;
    let scale = 2;
    // TODO: Dynamic scaling factor based on material
    score = (score * scale) / 100;
    
    // Adiciona o bônus de tempo para o lado que joga
    let side_score = match board.side {
        Color::White => score,
        Color::Black => -score,
    };
    side_score + params::TEMPO_BONUS
}

pub fn evaluate(board: &Board) -> i32 {
    // Eval hash: mesma posição já avaliada antes (transposição, re-busca
    // de LMR/singular, IID, ProbCut) devolve o score na hora, sem rodar
    // os ~20 módulos de avaliação de novo.
    if let Some(cached) =
        EVAL_CACHE.with(|c| c.borrow().probe(board.hash))
    {
        return cached;
    }

    let mut state = EvalState::new();

    // 1. Material + PST
    evaluate_material_and_pst(board, &mut state);

    // 2. King ring setup and pinned pieces
    // Calculates absolute pins to the king

    state.pinned[Color::White.index()] = board.pinned_pieces(Color::White);
    state.pinned[Color::Black.index()] = board.pinned_pieces(Color::Black);

    state.king_ring[Color::White.index()] = king_safety::get_king_ring(board, Color::White);
    state.king_ring[Color::Black.index()] = king_safety::get_king_ring(board, Color::Black);

    // 3. Pawn structure (basic)
    let white_pawns = pawns::PawnStructure::new(board, Color::White);
    let black_pawns = pawns::PawnStructure::new(board, Color::Black);

    // Pawn attacks go into attacks_by
    let w_pawn_att = pawns::get_pawn_attacks(Color::White, white_pawns.bb);
    let b_pawn_att = pawns::get_pawn_attacks(Color::Black, black_pawns.bb);
    state.attacks_by[Color::White.index()][PieceType::Pawn.index()] = w_pawn_att;
    state.attacks_by[Color::Black.index()][PieceType::Pawn.index()] = b_pawn_att;
    state.attacks[Color::White.index()] |= w_pawn_att;
    state.attacks[Color::Black.index()] |= b_pawn_att;

    // Pontuação de peões (ilhas/isolados/dobrados/backward/phalanx/buracos/cadeia)
    // + candidate passers: cacheada por estrutura de peões (pawn hash), porque
    // essa parte não muda a cada lance — só quando um peão sai/entra/captura.
    let pawn_key = pawn_hash(board);

    let (pawn_mg, pawn_eg, w_candidate_passers, b_candidate_passers) =
        if let Some(entry) = PAWN_CACHE.with(|c| c.borrow().probe(pawn_key).map(|e| {
            (e.mg, e.eg, e.candidate_passers[0], e.candidate_passers[1])
        })) {
            entry
        } else {
            // Cache miss: calcula do zero num EvalState "de rascunho" isolado,
            // pra não sujar o `state` principal antes de sabermos os totais.
            let mut pawn_state = EvalState::new();

            pawns::evaluate_pawns(board, &mut pawn_state, Color::White, &white_pawns, &black_pawns);
            pawns::evaluate_pawns(board, &mut pawn_state, Color::Black, &black_pawns, &white_pawns);

            let w_adv = advanced_pawns::evaluate_advanced_pawns(board, &mut pawn_state, Color::White);
            let b_adv = advanced_pawns::evaluate_advanced_pawns(board, &mut pawn_state, Color::Black);

            let mg = pawn_state.mg;
            let eg = pawn_state.eg;
            let candidates = [w_adv.candidate_passers, b_adv.candidate_passers];

            PAWN_CACHE.with(|c| c.borrow_mut().store(pawn_key, mg, eg, candidates));

            (mg, eg, candidates[0], candidates[1])
        };

    state.mg[Color::White.index()] += pawn_mg[Color::White.index()];
    state.mg[Color::Black.index()] += pawn_mg[Color::Black.index()];
    state.eg[Color::White.index()] += pawn_eg[Color::White.index()];
    state.eg[Color::Black.index()] += pawn_eg[Color::Black.index()];

    let w_adv_candidate_passers = w_candidate_passers;
    let b_adv_candidate_passers = b_candidate_passers;

    // 5. Safe mobility area (not own pieces, not attacked by enemy pawns)
    state.mob_area[Color::White.index()] =
        !board.color_bb[Color::White.index()] & !b_pawn_att;
    state.mob_area[Color::Black.index()] =
        !board.color_bb[Color::Black.index()] & !w_pawn_att;

    // 6. Pieces (Knights, Bishops, Rooks, Queens) — includes mobility
    pieces::evaluate_pieces(board, &mut state, Color::White, &white_pawns, &black_pawns);
    pieces::evaluate_pieces(board, &mut state, Color::Black, &black_pawns, &white_pawns);

    // 7. Passed pawns (including candidate passers from advanced_pawns)
    let w_pp = passed_pawns::evaluate_passed_pawns(board, &mut state, Color::White, w_adv_candidate_passers);
    let b_pp = passed_pawns::evaluate_passed_pawns(board, &mut state, Color::Black, b_adv_candidate_passers);
    state.passed_pawns[Color::White.index()] = w_pp.passed_pawns_bb;
    state.passed_pawns[Color::Black.index()] = b_pp.passed_pawns_bb;

    // 8. Threats
    threats::evaluate_threats(board, &mut state, Color::White);
    threats::evaluate_threats(board, &mut state, Color::Black);

    // 9. Space
    space_control::evaluate_space_control(board, &mut state, Color::White);
    space_control::evaluate_space_control(board, &mut state, Color::Black);

    // 10. King safety (shelter, storm, attack units)
    king_safety::evaluate_king_safety(
        board, &mut state, Color::White, &white_pawns, &black_pawns,
    );
    king_safety::evaluate_king_safety(
        board, &mut state, Color::Black, &black_pawns, &white_pawns,
    );

    // 11. King danger (secondary king safety: tropism, back rank, shield degradation)
    king_danger::evaluate_king_danger(board, &mut state, Color::White);
    king_danger::evaluate_king_danger(board, &mut state, Color::Black);

    // 11b. Outposts
    outposts::evaluate_outposts(board, &mut state, Color::White);
    outposts::evaluate_outposts(board, &mut state, Color::Black);

    // 11c. Patterns (Fianchetto, trapped pieces, blockers)
    patterns::evaluate_patterns(board, &mut state, Color::White);
    patterns::evaluate_patterns(board, &mut state, Color::Black);

    // 11d. Initiative
    initiative::evaluate_initiative(board, &mut state, Color::White);
    initiative::evaluate_initiative(board, &mut state, Color::Black);

    // 11d2. Activity (flank attacks, useful vs cosmetic, defense >> attack)
    active::evaluate_activity(board, &mut state, Color::White);
    active::evaluate_activity(board, &mut state, Color::Black);

    // 11d3. Inactivity (uncoordinated majors, isolated/inactive pieces)
    inactive::evaluate_inactivity(board, &mut state, Color::White);
    inactive::evaluate_inactivity(board, &mut state, Color::Black);

    // 11e. Material Imbalance (tabelas assimétricas do Stockfish —
    // ver eval/material_imbalance.rs). Chamado uma vez só, não por cor.
    material_imbalance::evaluate_material_imbalance(board, &mut state);

    // 12. Tapered evaluation
    let mg_score = state.mg[Color::White.index()] - state.mg[Color::Black.index()];
    let eg_score = state.eg[Color::White.index()] - state.eg[Color::Black.index()];
    let phase = state.phase.min(params::MAX_PHASE);

    let mut score =
        (mg_score * phase + eg_score * (params::MAX_PHASE - phase)) / params::MAX_PHASE;

    let mut scale = 76;
    
    // Glaurung-style dynamic scaling based on opposite colored bishops, etc.
    let op_bishops = (board.pieces_of(Color::White, PieceType::Bishop).count_ones() == 1) &&
                     (board.pieces_of(Color::Black, PieceType::Bishop).count_ones() == 1);
    if op_bishops {
        // scale down
        scale -= 10;
    }
    
    score = (score * scale) / 100;

    // 13. Late endgame: primeiro tenta finais especializados (KBNK,
    // KXK genérico) que sabem empurrar o rei adversário pro canto
    // CERTO — o mopup genérico abaixo empurra pra qualquer canto, o
    // que erra o KBN vs K. Se nenhum padrão especializado bater, cai
    // pro mopup genérico de sempre.
    if let Some(specialized) = endgame::evaluate_specialized_endgame(board) {
        score = specialized;
    } else {
        score += endgame::evaluate_mopup(board);
    }
    score = endgame::apply_endgame_scale(board, score);
    let fortress = endgame_fortress::evaluate_endgame_fortress(board, &mut state);
    score = (score * fortress.scale_factor) / 100;

    // 14. Side-relative score + tempo
    let side_score = match board.side {
        Color::White => score + params::TEMPO_BONUS,
        Color::Black => -score + params::TEMPO_BONUS,
    };
    //println!(
    //    "EVAL side={:?} mg={} eg={} final={}",
    //    board.side,
    //    mg_score,
    //    eg_score,
    //    side_score
    //);

    EVAL_CACHE.with(|c| c.borrow_mut().store(board.hash, side_score));

    side_score
}

// ==============================================================================
// MATERIAL + PST
// ==============================================================================

fn evaluate_material_and_pst(board: &Board, state: &mut EvalState) {
    const BASE_WEIGHT: i32 = 160;

    for &pt in &PIECE_TYPES {
        let pi = pt.index();

        for color in [Color::White, Color::Black] {
            let ci = color.index();

            for sq in iter(board.pieces_of(color, pt)) {
                let idx = match color {
                    Color::White => sq.index() ^ 56,
                    Color::Black => sq.index(),
                };

                let mg = params::MG_VALUE[pi]
                    + params::MG_TABLES[pi][idx];

                let eg = params::EG_VALUE[pi]
                    + params::EG_TABLES[pi][idx];

                state.mg[ci] += mg * BASE_WEIGHT / 100;
                state.eg[ci] += eg * BASE_WEIGHT / 100;

                state.phase += params::PHASE_INC[pi];
            }
        }
    }
}
