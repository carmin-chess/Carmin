use crate::board::Board;
use crate::personality;
use crate::types::{Color, Square, PieceType};
use crate::bitboard::{iter, Bitboard};
use super::EvalState;

// ================================================================================================
// CONSTANTS FOR PASSED PAWNS
// ================================================================================================

// Bonus for passed pawns based on rank (1-8). Passed pawns on 7th rank are almost a queen.


const CANDIDATE_PASSER_MG: [i32; 8] = [0, 3, 7, 15, 25, 40, 60, 0];
const CANDIDATE_PASSER_EG: [i32; 8] = [0, 5, 15, 30, 50, 80, 120, 0];

const CONNECTED_PASSER_BONUS_MG: i32 = 15;
const CONNECTED_PASSER_BONUS_EG: i32 = 40;

const ROOK_BEHIND_PASSED_PAWN_MG: i32 = 15;
const ROOK_BEHIND_PASSED_PAWN_EG: i32 = 35;

const ENEMY_ROOK_IN_FRONT_OF_PASSER_MG: i32 = -15;
const ENEMY_ROOK_IN_FRONT_OF_PASSER_EG: i32 = -25;

const KING_PROXIMITY_TO_PASSER_EG_FRIENDLY: [i32; 8] = [0, 5, 10, 15, 20, 25, 30, 35];
const KING_PROXIMITY_TO_PASSER_EG_ENEMY: [i32; 8] = [0, -5, -10, -15, -20, -25, -30, -35];

const PASSER_BLOCKADE_PENALTY_MG: i32 = -10;
const PASSER_BLOCKADE_PENALTY_EG: i32 = -20;

// ================================================================================================
// CORE STRUCTS
// ================================================================================================

pub struct PassedPawnInfo {
    pub count: i32,
    pub passed_pawns_bb: Bitboard,
    pub blockaded_passers: Bitboard,
    pub dangerous_passers: Bitboard, // Highly advanced passers
}

// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_passed_pawns(
    board: &Board,
    state: &mut EvalState,
    color: Color,
    candidate_passers: Bitboard, // Passed from advanced_pawns.rs
) -> PassedPawnInfo {
    let ci = color.index();
    let mg_before = state.mg[ci];
    let eg_before = state.eg[ci];
    let opp = color.opponent();
    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    let opp_pawns = board.pieces_of(opp, PieceType::Pawn);
    let my_rooks = board.pieces_of(color, PieceType::Rook);
    let opp_rooks = board.pieces_of(opp, PieceType::Rook);
    let my_king = board.king_square(color);
    let opp_king = board.king_square(opp);
    
    let mut info = PassedPawnInfo {
        count: 0,
        passed_pawns_bb: 0,
        blockaded_passers: 0,
        dangerous_passers: 0,
    };

    if my_pawns == 0 {
        return info;
    }

    // 1. Candidate Passers Bonus
    for sq in iter(candidate_passers) {
        let r = match color {
            Color::White => sq.rank() as usize,
            Color::Black => 7 - sq.rank() as usize,
        };
        state.mg[ci] += CANDIDATE_PASSER_MG[r];
        state.eg[ci] += CANDIDATE_PASSER_EG[r];
    }

    // 2. Identify strictly passed pawns
    for sq in iter(my_pawns) {
        let r = sq.rank() as usize;
        let f = sq.file() as usize;
        let rel_rank = match color {
            Color::White => r,
            Color::Black => 7 - r,
        };
        
        let front_span = match color {
            Color::White => !((1u64 << ((r + 1) * 8)) - 1),
            Color::Black => (1u64 << (r * 8)) - 1,
        };
        
        let file_mask = 0x0101010101010101u64 << f;
        let adj_mask = adjacent_files(f);
        
        // If there are no enemy pawns in front on same or adjacent files, it's a passed pawn
        if (opp_pawns & front_span & (file_mask | adj_mask)) == 0 {
            info.count += 1;
            info.passed_pawns_bb |= 1u64 << sq.index();
            
            // Base passed pawn bonus
            state.mg[ci] += super::params::PASSED_PAWN_BONUS_MG[rel_rank];
            state.eg[ci] += super::params::PASSED_PAWN_BONUS_EG[rel_rank];
            
            // Passed File Bonus (central passers vs edge passers)
            state.mg[ci] += super::params::PASSED_FILE_BONUS_MG[f];
            state.eg[ci] += super::params::PASSED_FILE_BONUS_EG[f];
            
            if rel_rank >= 5 {
                info.dangerous_passers |= 1u64 << sq.index();
            }

            // Connected passed pawns
            let neighbor_files = adj_files(f);
            let neighbor_passers = info.passed_pawns_bb & neighbor_files;
            if neighbor_passers != 0 {
                state.mg[ci] += CONNECTED_PASSER_BONUS_MG;
                state.eg[ci] += CONNECTED_PASSER_BONUS_EG;
            }

            // Blockades
            let block_sq_idx = match color {
                Color::White => sq.index() as i32 + 8,
                Color::Black => sq.index() as i32 - 8,
            };
            
            if block_sq_idx >= 0 && block_sq_idx < 64 {
                let block_sq_bb = 1u64 << block_sq_idx;
                if (board.occupancy & block_sq_bb) != 0 {
                    info.blockaded_passers |= 1u64 << sq.index();
                    if (board.color_bb[opp.index()] & block_sq_bb) != 0 {
                        // Enemy piece blocking is bad
                        state.mg[ci] += PASSER_BLOCKADE_PENALTY_MG;
                        state.eg[ci] += PASSER_BLOCKADE_PENALTY_EG;
                    }
                }
            }

            // Rooks Behind / In Front
            let behind_span = match color {
                Color::White => (1u64 << (r * 8)) - 1,
                Color::Black => !((1u64 << ((r + 1) * 8)) - 1),
            };
            
            // Friendly Rook behind passed pawn is excellent
            if (my_rooks & file_mask & behind_span) != 0 {
                state.mg[ci] += ROOK_BEHIND_PASSED_PAWN_MG;
                state.eg[ci] += ROOK_BEHIND_PASSED_PAWN_EG;
            }
            
            // Enemy Rook behind passed pawn is very strong for them (we penalize ourselves)
            if (opp_rooks & file_mask & behind_span) != 0 {
                state.mg[ci] -= ROOK_BEHIND_PASSED_PAWN_MG / 2;
                state.eg[ci] -= ROOK_BEHIND_PASSED_PAWN_EG / 2;
            }
            
            // Enemy rook in front is bad for us
            if (opp_rooks & file_mask & front_span) != 0 {
                state.mg[ci] += ENEMY_ROOK_IN_FRONT_OF_PASSER_MG;
                state.eg[ci] += ENEMY_ROOK_IN_FRONT_OF_PASSER_EG;
            }

            // King proximity in endgame
            let friendly_king_dist = distance(sq, my_king);
            let enemy_king_dist = distance(sq, opp_king);
            
            // We want our king close, and enemy king far
            state.eg[ci] += KING_PROXIMITY_TO_PASSER_EG_FRIENDLY[friendly_king_dist.min(7) as usize];
            state.eg[ci] -= KING_PROXIMITY_TO_PASSER_EG_ENEMY[enemy_king_dist.min(7) as usize];
            
            // Unstoppable passed pawns (Square Rule)
            if evaluate_unstoppable_passer(sq, color, opp_king, board.side) {
                // If it's unstoppable and we are in the endgame, it's basically a queen
                state.eg[ci] += 800; // Almost a queen value in endgame
            }
        }
    }

    // Apply personality scaling for passed pawns
    let cfg = personality::config();
    let mg_delta = state.mg[ci] - mg_before;
    let eg_delta = state.eg[ci] - eg_before;
    state.mg[ci] = mg_before + cfg.scale(mg_delta, cfg.passed);
    state.eg[ci] = eg_before + cfg.scale(eg_delta, cfg.passed);

    info
}

// ================================================================================================
// HELPER FUNCTIONS
// ================================================================================================

fn adjacent_files(file: usize) -> Bitboard {
    let mut mask = 0;
    if file > 0 { mask |= 0x0101010101010101u64 << (file - 1); }
    if file < 7 { mask |= 0x0101010101010101u64 << (file + 1); }
    mask
}

fn adj_files(file: usize) -> Bitboard {
    adjacent_files(file)
}

fn distance(sq1: Square, sq2: Square) -> i32 {
    let f1 = sq1.file() as i32;
    let r1 = sq1.rank() as i32;
    let f2 = sq2.file() as i32;
    let r2 = sq2.rank() as i32;
    (f1 - f2).abs().max((r1 - r2).abs())
}

fn evaluate_unstoppable_passer(pawn_sq: Square, pawn_color: Color, enemy_king: Square, turn: Color) -> bool {
    let prom_rank = match pawn_color {
        Color::White => 7,
        Color::Black => 0,
    };
    
    let dist_to_prom = (pawn_sq.rank() as i32 - prom_rank).abs();
    let mut _king_dist = distance(pawn_sq, enemy_king);
    
    // If it's the pawn's side to move, the king effectively has one less tempo to catch it
    if pawn_color == turn {
        _king_dist += 1;
    }
    
    // Square rule: if the king's distance to the promotion square is greater than the pawn's distance
    // (considering turns and double pushes), the pawn is unstoppable assuming no other pieces interfere.
    // This is a simplified square rule (doesn't account for piece interference).
    let king_prom_dist = (enemy_king.rank() as i32 - prom_rank).abs().max((enemy_king.file() as i32 - pawn_sq.file() as i32).abs());
    
    if king_prom_dist > dist_to_prom {
        return true;
    }
    
    false
}

// ------------------------------------------------------------------------------------------------
// EXTENSIVE PASSED PAWN DUMMY ANALYSIS LOGIC
// ------------------------------------------------------------------------------------------------

#[allow(dead_code)]
fn analyze_passed_pawn_races(white_passers: Bitboard, black_passers: Bitboard) -> i32 {
    // Detailed analysis of mutual passed pawn races
    let mut score = 0;
    let w_most_advanced = if white_passers != 0 { 63 - white_passers.leading_zeros() } else { 0 };
    let b_most_advanced = if black_passers != 0 { black_passers.trailing_zeros() } else { 0 };
    
    let w_dist = 7 - (w_most_advanced / 8) as i32;
    let b_dist = (b_most_advanced / 8) as i32;
    
    if white_passers != 0 && black_passers != 0 {
        if w_dist < b_dist {
            score += (b_dist - w_dist) * 50; 
        } else if b_dist < w_dist {
            score -= (w_dist - b_dist) * 50;
        }
    }
    
    score
}

#[allow(dead_code)]
fn evaluate_passed_pawn_storm(passers: Bitboard, color: Color, enemy_king: Square) -> i32 {
    let mut score = 0;
    for sq in iter(passers) {
        let f = sq.file() as i32;
        let k_f = enemy_king.file() as i32;
        let file_dist = (f - k_f).abs();
        
        if file_dist <= 2 {
            let r = match color {
                Color::White => sq.rank() as i32,
                Color::Black => 7 - sq.rank() as i32,
            };
            if r >= 5 {
                score += 30; // Passed pawn pushing directly into enemy king
            }
        }
    }
    score
}

// END OF passed_pawns.rs
