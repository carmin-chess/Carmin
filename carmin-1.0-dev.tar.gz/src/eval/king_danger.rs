use crate::board::Board;
use crate::types::{Color, Square, PieceType};
use crate::bitboard::{iter, Bitboard};
use super::EvalState;

// ================================================================================================
// CONSTANTS FOR KING DANGER
// ================================================================================================

// Weight of attacks by piece type near the enemy king
// Kept conservative — the main king safety evaluation is in king_safety.rs
const ATTACK_WEIGHT: [i32; 6] = [0, 1, 1, 2, 3, 0]; // Pawn, Knight, Bishop, Rook, Queen, King

const KING_TROPISM_PENALTY_MG: i32 = -1; // per unit of distance closer to king
#[allow(dead_code)]
const KING_TROPISM_PENALTY_EG: i32 = 0;

// Penalty for having pawns moved away from the king shield
const PAWN_SHIELD_DEGRADATION_MG: [i32; 8] = [0, -8, -16, -28, -40, -40, -40, -40]; // by rank moved
const WEAK_BACK_RANK_PENALTY_MG: i32 = -30;

// Scaling for king danger based on attack units — capped at 200cp
const KING_DANGER_SCALE_MG: [i32; 20] = [
    0, 0, 5, 10, 18, 28, 40, 55, 72, 90, 108, 126, 144, 160, 174, 186, 195, 200, 200, 200
];

// ================================================================================================
// CORE STRUCTS
// ================================================================================================

pub struct KingDangerInfo {
    pub attack_units: i32,
    pub attackers_count: i32,
    pub weak_squares_around_king: Bitboard,
    pub shield_quality: i32,
}

// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_king_danger(
    board: &Board,
    state: &mut EvalState,
    color: Color,
) -> KingDangerInfo {
    let ci = color.index();
    let opp = color.opponent();
    let opp_ci = opp.index();
    
    let my_king = board.king_square(color);
    let king_ring = state.king_ring[ci];
    
    let mut info = KingDangerInfo {
        attack_units: 0,
        attackers_count: 0,
        weak_squares_around_king: 0,
        shield_quality: 0,
    };

    // 1. Calculate attackers and attack units
    for &pt in &[PieceType::Knight, PieceType::Bishop, PieceType::Rook, PieceType::Queen] {
        let p_idx = pt.index();
        let opp_attacks_by_pt = state.attacks_by[opp_ci][p_idx];
        
        let attacks_in_ring = opp_attacks_by_pt & king_ring;
        if attacks_in_ring != 0 {
            let _attackers = board.pieces_of(opp, pt);
            // Count how many unique pieces of this type are attacking the ring
            // (Simplified: just check if the bitboard has pieces and how many attacks landed)
            info.attackers_count += 1;
            info.attack_units += ATTACK_WEIGHT[p_idx] * attacks_in_ring.count_ones() as i32;
        }
    }

    // 2. Apply King Danger Scaling
    if info.attackers_count >= 2 {
        let max_idx = KING_DANGER_SCALE_MG.len() - 1;
        let idx = (info.attack_units as usize).min(max_idx);
        state.mg[ci] -= KING_DANGER_SCALE_MG[idx]; // We subtract because this is danger to OUR king
    }

    // 3. Pawn Shield Degradation
    let k_file = my_king.file() as usize;
    let k_rank = my_king.rank() as usize;
    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    
    // Only evaluate shield if king is on 1st or 2nd rank (or 8th/7th for black) and castled/tucked
    let is_tucked = match color {
        Color::White => k_rank <= 1 && (k_file <= 2 || k_file >= 5),
        Color::Black => k_rank >= 6 && (k_file <= 2 || k_file >= 5),
    };

    if is_tucked {
        for f in k_file.saturating_sub(1)..=k_file.saturating_add(1).min(7) {
            let file_mask = 0x0101010101010101u64 << f;
            let pawns_on_f = my_pawns & file_mask;
            
            if pawns_on_f == 0 {
                info.shield_quality -= 50; // Missing pawn
                state.mg[ci] += PAWN_SHIELD_DEGRADATION_MG[4];
            } else {
                let most_backward = match color {
                    Color::White => pawns_on_f.trailing_zeros() as usize / 8,
                    Color::Black => 7 - (63 - pawns_on_f.leading_zeros() as usize) / 8,
                };
                
                let ranks_moved = most_backward.saturating_sub(1);
                info.shield_quality -= (ranks_moved * 10) as i32;
                state.mg[ci] += PAWN_SHIELD_DEGRADATION_MG[ranks_moved.min(7)];
            }
        }
    }

    // 4. Weak Back Rank
    // If king is on back rank, and there are pawns blocking escape, and enemy rooks/queens can access it
    let back_rank = match color {
        Color::White => 0x00000000000000FFu64,
        Color::Black => 0xFF00000000000000u64,
    };
    
    if (1u64 << my_king.index()) & back_rank != 0 {
        let escape_sqs = crate::attacks::king_attacks(my_king) & !back_rank;
        if (escape_sqs & my_pawns) == escape_sqs {
            // All escape squares are blocked by friendly pawns
            let opp_majors = board.pieces_of(opp, PieceType::Rook) | board.pieces_of(opp, PieceType::Queen);
            if opp_majors != 0 {
                state.mg[ci] += WEAK_BACK_RANK_PENALTY_MG;
            }
        }
    }
    
    // 5. King Tropism (Proximity of enemy pieces)
    // We heavily penalize our king for being close to enemy pieces in the middlegame
    for sq in iter(board.pieces_of(opp, PieceType::Knight)) {
        let dist = distance(my_king, sq);
        state.mg[ci] += KING_TROPISM_PENALTY_MG * (8 - dist).max(0);
    }
    for sq in iter(board.pieces_of(opp, PieceType::Queen)) {
        let dist = distance(my_king, sq);
        state.mg[ci] += KING_TROPISM_PENALTY_MG * (8 - dist).max(0);
    }

    info
}

// ================================================================================================
// HELPER FUNCTIONS
// ================================================================================================

fn distance(sq1: Square, sq2: Square) -> i32 {
    let f1 = sq1.file() as i32;
    let r1 = sq1.rank() as i32;
    let f2 = sq2.file() as i32;
    let r2 = sq2.rank() as i32;
    (f1 - f2).abs().max((r1 - r2).abs())
}

// ------------------------------------------------------------------------------------------------
// EXTENSIVE KING DANGER DUMMY ANALYSIS LOGIC
// ------------------------------------------------------------------------------------------------

#[allow(dead_code)]
fn evaluate_virtual_mobility_around_king(board: &Board, color: Color) -> i32 {
    // Calculates how many squares around the king the enemy COULD attack if our pieces weren't there
    let opp = color.opponent();
    let my_king = board.king_square(color);
    let king_ring = crate::attacks::king_attacks(my_king);
    
    let mut virtual_attacks = 0;
    
    // Rooks
    for sq in iter(board.pieces_of(opp, PieceType::Rook)) {
        let att = crate::attacks::rook_attacks(sq, board.occupancy & !king_ring); // ignore pieces in king ring
        virtual_attacks += (att & king_ring).count_ones() as i32;
    }
    
    // Bishops
    for sq in iter(board.pieces_of(opp, PieceType::Bishop)) {
        let att = crate::attacks::bishop_attacks(sq, board.occupancy & !king_ring);
        virtual_attacks += (att & king_ring).count_ones() as i32;
    }
    
    virtual_attacks * -5 // Penalty per virtual attack
}

#[allow(dead_code)]
fn check_mating_nets(board: &Board, color: Color) -> i32 {
    // Detects specific mating patterns (e.g. Anastasia's mate potential, smothered mate potential)
    let opp = color.opponent();
    let my_king = board.king_square(color);
    let opp_knights = board.pieces_of(opp, PieceType::Knight);
    let mut score = 0;
    
    // Smothered mate risk
    let escape_squares = crate::attacks::king_attacks(my_king) & !board.color_bb[color.index()];
    if escape_squares == 0 {
        // King is smothered
        for sq in iter(opp_knights) {
            let knight_att = crate::attacks::knight_attacks(sq);
            if (knight_att & (1u64 << my_king.index())) != 0 {
                // Actually in check, but if we are just evaluating potential:
                score -= 100; // Severe danger
            }
        }
    }
    
    score
}

#[allow(dead_code)]
fn evaluate_king_pawn_storm(board: &Board, color: Color) -> i32 {
    let opp = color.opponent();
    let my_king = board.king_square(color);
    let opp_pawns = board.pieces_of(opp, PieceType::Pawn);
    
    let k_file = my_king.file() as usize;
    let mut score = 0;
    
    for f in k_file.saturating_sub(2)..=k_file.saturating_add(2).min(7) {
        let file_mask = 0x0101010101010101u64 << f;
        let opp_pawns_on_file = opp_pawns & file_mask;
        
        if opp_pawns_on_file != 0 {
            let most_advanced = match opp {
                Color::White => 63 - opp_pawns_on_file.leading_zeros(),
                Color::Black => opp_pawns_on_file.trailing_zeros(),
            };
            
            let rank = most_advanced / 8;
            let dist_to_king = (my_king.rank() as i32 - rank as i32).abs();
            
            if dist_to_king <= 3 {
                score -= 20 - dist_to_king * 5; // Penalty for enemy pawns close to our king
            }
        }
    }
    
    score
}
// END OF king_danger.rs
