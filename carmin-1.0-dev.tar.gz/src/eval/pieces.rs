use crate::attacks;
use crate::bitboard::iter;
use crate::board::Board;
use crate::types::{Color, PieceType};
use super::params::*;
use super::EvalState;

pub fn evaluate_pieces(
    board: &Board,
    state: &mut EvalState,
    color: Color,
    friendly_pawns: &super::pawns::PawnStructure,
    enemy_pawns: &super::pawns::PawnStructure,
) {
    let ci = color.index();
    let opp = color.opponent();
    let occ = board.occupancy;
    let safe_targets = state.mob_area[ci];

    let mut undeveloped_count = 0;
    match color {
        Color::White => {
            let knights = board.pieces_of(Color::White, PieceType::Knight);
            let bishops = board.pieces_of(Color::White, PieceType::Bishop);
            if (knights & (1u64 << 1)) != 0 { undeveloped_count += 1; }
            if (knights & (1u64 << 6)) != 0 { undeveloped_count += 1; }
            if (bishops & (1u64 << 2)) != 0 { undeveloped_count += 1; }
            if (bishops & (1u64 << 5)) != 0 { undeveloped_count += 1; }
        },
        Color::Black => {
            let knights = board.pieces_of(Color::Black, PieceType::Knight);
            let bishops = board.pieces_of(Color::Black, PieceType::Bishop);
            if (knights & (1u64 << 57)) != 0 { undeveloped_count += 1; }
            if (knights & (1u64 << 62)) != 0 { undeveloped_count += 1; }
            if (bishops & (1u64 << 58)) != 0 { undeveloped_count += 1; }
            if (bishops & (1u64 << 61)) != 0 { undeveloped_count += 1; }
        }
    }

    // NOVA ABORDAGEM: Penaliza globalmente a falta de desenvolvimento.
    // Isso incentiva o motor a tirar as peças menores de suas casas iniciais,
    // sem punir as peças que já se moveram para o ataque/centro.
    if undeveloped_count > 0 {
        state.mg[ci] -= (undeveloped_count * 10) as i32;
    }

    // Knights
    for sq in iter(board.pieces_of(color, PieceType::Knight)) {
        let attacks = attacks::knight_attacks(sq);
        state.attacks[ci] |= attacks;
        state.attacks_by[ci][PieceType::Knight.index()] |= attacks;
        
        let mob = (attacks & safe_targets).count_ones() as usize;
        state.mg[ci] += KNIGHT_MOBILITY_MG[mob.min(8)];
        state.eg[ci] += KNIGHT_MOBILITY_EG[mob.min(8)];
        

    }

    // Bishops
    let bishops = board.pieces_of(color, PieceType::Bishop);
    if bishops.count_ones() >= 2 {
        state.mg[ci] += BISHOP_PAIR_BONUS_MG;
        state.eg[ci] += BISHOP_PAIR_BONUS_EG;
    }
    for sq in iter(bishops) {
        let attacks = attacks::bishop_attacks(sq, occ);
        state.attacks[ci] |= attacks;
        state.attacks_by[ci][PieceType::Bishop.index()] |= attacks;
        
        let mob = (attacks & safe_targets).count_ones() as usize;
        state.mg[ci] += BISHOP_MOBILITY_MG[mob.min(13)];
        state.eg[ci] += BISHOP_MOBILITY_EG[mob.min(13)];



        // Bad bishop
        let is_light = (sq.file() + sq.rank()) % 2 == 0;
        let mut bad_pawns = 0;
        for i in 0..friendly_pawns.count {
            let p_sq = friendly_pawns.squares[i];
            let p_light = (p_sq.file() + p_sq.rank()) % 2 == 0;
            if p_light == is_light {
                bad_pawns += 1;
            }
        }
        state.mg[ci] += BAD_BISHOP_PENALTY_PER_PAWN_MG * (bad_pawns as i32);
        state.eg[ci] += BAD_BISHOP_PENALTY_PER_PAWN_EG * (bad_pawns as i32);
    }

    // Rooks
    for sq in iter(board.pieces_of(color, PieceType::Rook)) {
        let attacks = attacks::rook_attacks(sq, occ);
        state.attacks[ci] |= attacks;
        state.attacks_by[ci][PieceType::Rook.index()] |= attacks;
        
        let mob = (attacks & safe_targets).count_ones() as usize;
        state.mg[ci] += ROOK_MOBILITY_MG[mob.min(14)];
        state.eg[ci] += ROOK_MOBILITY_EG[mob.min(14)];

        let f = sq.file() as usize;
        let is_7th = match color { Color::White => sq.rank() == 6, Color::Black => sq.rank() == 1 };
        
        if !friendly_pawns.files[f] {
            if !enemy_pawns.files[f] {
                state.mg[ci] += ROOK_OPEN_FILE_MG;
                state.eg[ci] += ROOK_OPEN_FILE_EG;
            } else {
                state.mg[ci] += ROOK_SEMI_OPEN_FILE_MG;
                state.eg[ci] += ROOK_SEMI_OPEN_FILE_EG;
            }
        }
        
        if is_7th {
            let opp_king_rank = board.king_square(opp).rank();
            let opp_pawns = board.pieces_of(opp, PieceType::Pawn);
            let condition_met = match color {
                Color::White => opp_king_rank == 7 || (opp_pawns & 0xFFFF_0000_0000_0000) != 0,
                Color::Black => opp_king_rank == 0 || (opp_pawns & 0x0000_0000_0000_FFFF) != 0,
            };
            if condition_met {
                state.mg[ci] += ROOK_ON_7TH_MG;
                state.eg[ci] += ROOK_ON_7TH_EG;
            }
        }
    }

    // Queens
    for sq in iter(board.pieces_of(color, PieceType::Queen)) {
        let attacks = attacks::queen_attacks(sq, occ);
        state.attacks[ci] |= attacks;
        state.attacks_by[ci][PieceType::Queen.index()] |= attacks;
        
        let mob = (attacks & safe_targets).count_ones() as usize;
        state.mg[ci] += QUEEN_MOBILITY_MG[mob.min(27)];
        state.eg[ci] += QUEEN_MOBILITY_EG[mob.min(27)];

        // Queen on 7th rank
        let is_7th_q = match color { Color::White => sq.rank() == 6, Color::Black => sq.rank() == 1 };
        if is_7th_q {
            let opp_king_rank = board.king_square(opp).rank();
            let opp_pawns = board.pieces_of(opp, PieceType::Pawn);
            let condition_met = match color {
                Color::White => opp_king_rank == 7 || (opp_pawns & 0xFFFF_0000_0000_0000) != 0,
                Color::Black => opp_king_rank == 0 || (opp_pawns & 0x0000_0000_0000_FFFF) != 0,
            };
            if condition_met {
                state.mg[ci] += QUEEN_ON_7TH_MG;
                state.eg[ci] += QUEEN_ON_7TH_EG;
            }
        }

        let starting_sq = match color { Color::White => 3, Color::Black => 59 };
        if sq.index() as usize != starting_sq {
            if undeveloped_count > 0 {
                // ATENÇÃO: Assegure-se de que as constantes EARLY_QUEEN_PENALTY sejam negativas em params.rs!
                state.mg[ci] += EARLY_QUEEN_PENALTY_MG + EARLY_QUEEN_PENALTY_PER_UNDEVELOPED * (undeveloped_count as i32);
            }
        }
    }
    // King
    let k_sq = board.king_square(color);
    let k_attacks = attacks::king_attacks(k_sq);
    state.attacks[ci] |= k_attacks;
    state.attacks_by[ci][PieceType::King.index()] |= k_attacks;
}

pub fn evaluate_space(_board: &Board, state: &mut EvalState) {
    if state.phase < 12 { return; } // Only evaluate space when board is full
    
    let white_space = (state.attacks[Color::White.index()] & SPACE_MASK_W).count_ones() as i32;
    let black_space = (state.attacks[Color::Black.index()] & SPACE_MASK_B).count_ones() as i32;
    
    let weight = (state.phase * SPACE_WEIGHT_MG) / MAX_PHASE;
    state.mg[Color::White.index()] += white_space * weight;
    state.mg[Color::Black.index()] += black_space * weight;
}
