use crate::bitboard::iter;
use crate::board::Board;
use crate::types::{Color, PieceType, Square};
use super::params::*;
use super::EvalState;

pub struct PawnStructure {
    pub grid: [[bool; 8]; 8],
    pub files: [bool; 8],
    pub squares: [Square; 16],
    pub count: usize,
    pub bb: u64,
}

impl PawnStructure {
    pub fn new(board: &Board, color: Color) -> Self {
        let mut grid = [[false; 8]; 8];
        let mut files = [false; 8];
        let mut squares = [Square::new(0); 16];
        let mut count = 0;
        let bb = board.pieces_of(color, PieceType::Pawn);

        for sq in iter(bb) {
            let f = sq.file() as usize;
            let r = sq.rank() as usize;
            grid[r][f] = true;
            files[f] = true;
            if count < 16 {
                squares[count] = sq;
                count += 1;
            }
        }
        Self { grid, files, squares, count, bb }
    }
}

pub fn evaluate_pawns(
    board: &Board,
    state: &mut EvalState,
    color: Color,
    friendly: &PawnStructure,
    enemy: &PawnStructure,
) {
    let ci = color.index();
    let _fk_sq = board.king_square(color);
    let _ek_sq = board.king_square(color.opponent());

    let mut pawns_per_file = [0u8; 8];
    for &sq in &friendly.squares[..friendly.count] {
        pawns_per_file[sq.file() as usize] += 1;
    }

    let _enemy_pawn_attacks = get_pawn_attacks(color.opponent(), enemy.bb);

    for &sq in &friendly.squares[..friendly.count] {
        let f = sq.file() as usize;
        let r = sq.rank() as usize;

        // Pawn Chain
        let is_defended_by_pawn = {
            let def_r = match color {
                Color::White => r.wrapping_sub(1),
                Color::Black => r + 1,
            };
            def_r < 8 && ((f > 0 && friendly.grid[def_r][f - 1]) || (f < 7 && friendly.grid[def_r][f + 1]))
        };
        if is_defended_by_pawn {
            state.mg[ci] += PAWN_CHAIN_BONUS_MG;
            state.eg[ci] += PAWN_CHAIN_BONUS_EG;
        }

        // Passed Pawns
        if is_passed_pawn(color, r, f, enemy) {
            state.passed_pawns[ci] |= sq.bb();
        }
    }
}

pub fn get_pawn_attacks(color: Color, pawns: u64) -> u64 {
    match color {
        Color::White => ((pawns << 7) & 0x7F7F7F7F7F7F7F7F) | ((pawns << 9) & 0xFEFEFEFEFEFEFEFE),
        Color::Black => ((pawns >> 9) & 0x7F7F7F7F7F7F7F7F) | ((pawns >> 7) & 0xFEFEFEFEFEFEFEFE),
    }
}

pub fn is_passed_pawn(color: Color, r: usize, f: usize, enemy: &PawnStructure) -> bool {
    let min_f = if f > 0 { f - 1 } else { 0 };
    let max_f = if f < 7 { f + 1 } else { 7 };

    match color {
        Color::White => {
            for check_r in r..8 {
                for check_f in min_f..=max_f {
                    if enemy.grid[check_r][check_f] {
                        return false;
                    }
                }
            }
        }
        Color::Black => {
            for check_r in 0..=r {
                for check_f in min_f..=max_f {
                    if enemy.grid[check_r][check_f] {
                        return false;
                    }
                }
            }
        }
    }
    true
}
