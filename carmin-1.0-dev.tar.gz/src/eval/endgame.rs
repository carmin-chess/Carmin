use crate::board::Board;
use crate::types::{Color, PieceType};
use crate::bitboard::lsb;

/// Distância de Chebyshev entre dois quadrados (usada nas tabelas
/// de "empurrar reis" — igual ao `distance()` do Stockfish).
fn king_distance(a: crate::types::Square, b: crate::types::Square) -> i32 {
    let fa = a.file() as i32;
    let fb = b.file() as i32;
    let ra = a.rank() as i32;
    let rb = b.rank() as i32;
    (fa - fb).abs().max((ra - rb).abs())
}

/// Espelha o quadrado verticalmente (a1<->a8), igual ao `operator~`
/// do Stockfish — usado pra "virar o tabuleiro" quando o bispo está
/// na diagonal errada pro KBNK.
fn vflip(sq: crate::types::Square) -> crate::types::Square {
    crate::types::Square::new(sq.index() as u8 ^ 56)
}

/// Retorna true se dois quadrados estão em cores de casa diferentes.
fn opposite_colors(a: crate::types::Square, b: crate::types::Square) -> bool {
    let s = (a.index() as i32) ^ (b.index() as i32);
    ((s >> 3) ^ s) & 1 != 0
}

#[rustfmt::skip]
const PUSH_TO_EDGES: [i32; 64] = [
    100, 90, 80, 70, 70, 80, 90, 100,
     90, 70, 60, 50, 50, 60, 70,  90,
     80, 60, 40, 30, 30, 40, 60,  80,
     70, 50, 30, 20, 20, 30, 50,  70,
     70, 50, 30, 20, 20, 30, 50,  70,
     80, 60, 40, 30, 30, 40, 60,  80,
     90, 70, 60, 50, 50, 60, 70,  90,
    100, 90, 80, 70, 70, 80, 90, 100,
];

#[rustfmt::skip]
const PUSH_TO_CORNERS: [i32; 64] = [
    200, 190, 180, 170, 160, 150, 140, 130,
    190, 180, 170, 160, 150, 140, 130, 140,
    180, 170, 155, 140, 140, 125, 140, 150,
    170, 160, 140, 120, 110, 140, 150, 160,
    160, 150, 140, 110, 120, 140, 160, 170,
    150, 140, 125, 140, 140, 155, 170, 180,
    140, 130, 140, 150, 160, 170, 180, 190,
    130, 140, 150, 160, 170, 180, 190, 200,
];

const PUSH_CLOSE: [i32; 8] = [0, 0, 100, 80, 60, 40, 20, 10];

/// Vantagem de "mate conhecido" usada como piso, igual ao
/// `VALUE_KNOWN_WIN` do Stockfish (aproximado — não precisa ser
/// exato, só grande o bastante pra dominar a avaliação normal).
const KNOWN_WIN: i32 = 10_000;

/// KX vs K: final genérico com vantagem material esmagadora (torre,
/// dama, ou dois bispos/2 peças menores) contra rei sozinho.
/// Estratégia: empurrar o rei perdedor pra QUALQUER borda + aproximar
/// os reis. Só dispara quando o lado fraco não tem peça nenhuma.
fn kxk_eval(board: &Board, strong: Color) -> Option<i32> {
    let weak = strong.opponent();

    let weak_has_material = board.pieces_of(weak, PieceType::Pawn) != 0
        || board.pieces_of(weak, PieceType::Knight) != 0
        || board.pieces_of(weak, PieceType::Bishop) != 0
        || board.pieces_of(weak, PieceType::Rook) != 0
        || board.pieces_of(weak, PieceType::Queen) != 0;

    if weak_has_material {
        return None;
    }

    // Material mínimo pra realmente ser um mate fácil (>= torre, ou
    // 2 peças menores, ou dama).
    let strong_rooks = board.pieces_of(strong, PieceType::Rook).count_ones();
    let strong_queens = board.pieces_of(strong, PieceType::Queen).count_ones();
    let strong_minors = board.pieces_of(strong, PieceType::Knight).count_ones()
        + board.pieces_of(strong, PieceType::Bishop).count_ones();

    if strong_rooks == 0 && strong_queens == 0 && strong_minors < 2 {
        return None;
    }

    let winner_k = board.king_square(strong);
    let loser_k = board.king_square(weak);

    let result = KNOWN_WIN
        + PUSH_TO_EDGES[loser_k.index()]
        + PUSH_CLOSE[king_distance(winner_k, loser_k) as usize];

    Some(if strong == Color::White { result } else { -result })
}

/// KBN vs K: caso especial — o mate só é possível empurrando o rei
/// adversário pro canto da MESMA COR do bispo (a1/h8 se o bispo for
/// de casas escuras "tipo a1", ou a8/h1 caso contrário). Um mopup
/// genérico que empurra pra qualquer canto erra esse final e pode
/// nem conseguir dar mate antes da regra dos 50 lances.
fn kbnk_eval(board: &Board, strong: Color) -> Option<i32> {
    let weak = strong.opponent();

    let weak_has_material = board.pieces_of(weak, PieceType::Pawn) != 0
        || board.pieces_of(weak, PieceType::Knight) != 0
        || board.pieces_of(weak, PieceType::Bishop) != 0
        || board.pieces_of(weak, PieceType::Rook) != 0
        || board.pieces_of(weak, PieceType::Queen) != 0;

    if weak_has_material {
        return None;
    }

    let bishops = board.pieces_of(strong, PieceType::Bishop);
    let knights = board.pieces_of(strong, PieceType::Knight);
    let rooks = board.pieces_of(strong, PieceType::Rook);
    let queens = board.pieces_of(strong, PieceType::Queen);
    let pawns = board.pieces_of(strong, PieceType::Pawn);

    // Exatamente 1 bispo + 1 cavalo, nada mais.
    if bishops.count_ones() != 1
        || knights.count_ones() != 1
        || rooks != 0
        || queens != 0
        || pawns != 0
        || board.pieces_of(strong, PieceType::Bishop).count_ones()
            + board.pieces_of(strong, PieceType::Knight).count_ones()
            != 2
    {
        return None;
    }

    let bishop_sq = lsb(bishops);
    
    let mut winner_k = board.king_square(strong);
    let mut loser_k = board.king_square(weak);

    // A tabela PUSH_TO_CORNERS empurra pra a1/h8. Se o bispo não
    // alcança essas casas (cor errada), viramos o tabuleiro
    // verticalmente pra mirar em a8/h1 em vez disso.
    if opposite_colors(bishop_sq, crate::types::Square::new(0)) {
        winner_k = vflip(winner_k);
        loser_k = vflip(loser_k);
    }

    let result = KNOWN_WIN
        + PUSH_CLOSE[king_distance(winner_k, loser_k) as usize]
        + PUSH_TO_CORNERS[loser_k.index()];

    Some(if strong == Color::White { result } else { -result })
}

/// Tenta as funções especializadas de final (KBNK, depois KXK
/// genérico) pra qualquer um dos lados. Retorna `None` se a posição
/// não bater com nenhum padrão conhecido — nesse caso o chamador
/// deve usar o `evaluate_mopup` genérico.
pub fn evaluate_specialized_endgame(board: &Board) -> Option<i32> {
    for &side in &[Color::White, Color::Black] {
        if let Some(v) = kbnk_eval(board, side) {
            return Some(v);
        }
        if let Some(v) = kxk_eval(board, side) {
            return Some(v);
        }
    }
    None
}

pub fn evaluate_mopup(board: &Board) -> i32 {
    let mut mopup = 0;
    let w_mat = board.pieces[Color::White.index()][PieceType::Pawn.index()].count_ones() * 100 +
                board.pieces[Color::White.index()][PieceType::Knight.index()].count_ones() * 300 +
                board.pieces[Color::White.index()][PieceType::Bishop.index()].count_ones() * 300 +
                board.pieces[Color::White.index()][PieceType::Rook.index()].count_ones() * 500 +
                board.pieces[Color::White.index()][PieceType::Queen.index()].count_ones() * 900;
    let b_mat = board.pieces[Color::Black.index()][PieceType::Pawn.index()].count_ones() * 100 +
                board.pieces[Color::Black.index()][PieceType::Knight.index()].count_ones() * 300 +
                board.pieces[Color::Black.index()][PieceType::Bishop.index()].count_ones() * 300 +
                board.pieces[Color::Black.index()][PieceType::Rook.index()].count_ones() * 500 +
                board.pieces[Color::Black.index()][PieceType::Queen.index()].count_ones() * 900;
                
    if w_mat > b_mat + 200 && b_mat < 1000 {
        let bk = board.king_square(Color::Black);
        let wk = board.king_square(Color::White);
        let center_dist = (3.5 - (bk.file() as f32)).abs() + (3.5 - (bk.rank() as f32)).abs();
        let kings_dist = (bk.file() as i32 - wk.file() as i32).abs() + (bk.rank() as i32 - wk.rank() as i32).abs();
        mopup += (center_dist as i32 * 10) + ((14 - kings_dist) * 4);
    } else if b_mat > w_mat + 200 && w_mat < 1000 {
        let wk = board.king_square(Color::White);
        let bk = board.king_square(Color::Black);
        let center_dist = (3.5 - (wk.file() as f32)).abs() + (3.5 - (wk.rank() as f32)).abs();
        let kings_dist = (wk.file() as i32 - bk.file() as i32).abs() + (wk.rank() as i32 - bk.rank() as i32).abs();
        mopup -= (center_dist as i32 * 10) + ((14 - kings_dist) * 4);
    }
    mopup
}

pub fn apply_endgame_scale(board: &Board, mut score: i32) -> i32 {
    let w_pawns = board.pieces_of(Color::White, PieceType::Pawn).count_ones();
    let b_pawns = board.pieces_of(Color::Black, PieceType::Pawn).count_ones();
    
    let w_majors = board.pieces_of(Color::White, PieceType::Rook).count_ones() + board.pieces_of(Color::White, PieceType::Queen).count_ones();
    let b_majors = board.pieces_of(Color::Black, PieceType::Rook).count_ones() + board.pieces_of(Color::Black, PieceType::Queen).count_ones();
    
    let w_bishops = board.pieces_of(Color::White, PieceType::Bishop).count_ones();
    let b_bishops = board.pieces_of(Color::Black, PieceType::Bishop).count_ones();
    
    let w_knights = board.pieces_of(Color::White, PieceType::Knight).count_ones();
    let b_knights = board.pieces_of(Color::Black, PieceType::Knight).count_ones();

    // K vs K+Material Draw scenarios
    if w_pawns == 0 && b_pawns == 0 {
        let w_pieces = w_majors + w_bishops + w_knights;
        let b_pieces = b_majors + b_bishops + b_knights;
        
        // K v K + Minor
        if w_pieces == 0 && b_pieces == 1 && b_majors == 0 { return 0; }
        if b_pieces == 0 && w_pieces == 1 && w_majors == 0 { return 0; }
        // K v K + 2N
        if w_pieces == 0 && b_knights == 2 && b_pieces == 2 { return 0; }
        if b_pieces == 0 && w_knights == 2 && w_pieces == 2 { return 0; }
    }

    // Opposite colored bishops
    if w_bishops == 1 && b_bishops == 1 && w_majors == 0 && b_majors == 0 && w_knights == 0 && b_knights == 0 {
        let w_b = board.pieces_of(Color::White, PieceType::Bishop);
        let b_b = board.pieces_of(Color::Black, PieceType::Bishop);
        let light_sq = 0x55AA55AA55AA55AAu64;
        if ((w_b & light_sq) != 0) != ((b_b & light_sq) != 0) {
            score /= 2; // Strong tendency to draw
        }
    }

    // NEW: Same-flank pawns scaling
    let pawns = board.pieces_of(Color::White, PieceType::Pawn) | board.pieces_of(Color::Black, PieceType::Pawn);
    if pawns != 0 {
        let w_pieces = w_majors + w_bishops + w_knights;
        let b_pieces = b_majors + b_bishops + b_knights;
        if w_pieces + b_pieces <= 2 && w_majors == 0 && b_majors == 0 {
            let kingside_mask = 0x0F0F0F0F0F0F0F0F; // files a-d
            let queenside_mask = 0xF0F0F0F0F0F0F0F0; // files e-h
            if (pawns & kingside_mask) == 0 || (pawns & queenside_mask) == 0 {
                score = (score * 3) / 4;
            }
        }
    }

    score
}
