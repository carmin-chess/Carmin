// Evaluation Parameters: Constants, Piece-Square Tables, Mobility Arrays, and Weights.
// Versão pessimista – valores reduzidos de atividade, ameaças e peões passados.
// Penalidades estruturais aumentadas. PSTs mais contidas.
// ==============================================================================
// MATERIAL VALUES (Middlegame / Endgame)
// ==============================================================================
pub const MG_VALUE: [i32; 6] = [100, 320, 330, 500, 950, 0];
pub const EG_VALUE: [i32; 6] = [100, 310, 320, 530, 940, 0];

// ==============================================================================
// PHASE
// ==============================================================================
pub const PHASE_INC: [i32; 6] = [0, 1, 1, 2, 4, 0];
pub const MAX_PHASE: i32 = 24;

// ==============================================================================
// SCORES
// ==============================================================================
pub const MATE: i32 = 30_000;
pub const MATE_IN_MAX: i32 = MATE - 1000;
pub const TEMPO_BONUS: i32 = 8;

// ==============================================================================
// PAWN STRUCTURE
// ==============================================================================
pub const ISOLATED_PAWN_PENALTY_MG: i32 = -14;
pub const ISOLATED_PAWN_PENALTY_EG: i32 = -22;
pub const DOUBLED_PAWN_PENALTY_MG: i32 = -12;
pub const DOUBLED_PAWN_PENALTY_EG: i32 = -25;
pub const BACKWARD_PAWN_PENALTY_MG: i32 = -14;
pub const BACKWARD_PAWN_PENALTY_EG: i32 = -20;
pub const PAWN_PHALANX_BONUS_MG: i32 = 5;
pub const PAWN_PHALANX_BONUS_EG: i32 = 8;
pub const PAWN_CHAIN_BONUS_MG: i32 = 6;
pub const PAWN_CHAIN_BONUS_EG: i32 = 4;

/// Passed pawn bonuses indexed by relative rank (0..7, rank 0 = home, rank 7 = promo).
pub const PASSED_PAWN_BONUS_MG: [i32; 8] = [0, 5, 9, 18, 32, 55, 90, 0];
pub const PASSED_PAWN_BONUS_EG: [i32; 8] = [0, 8, 14, 25, 45, 80, 130, 0];

// ==============================================================================
// SPACE EVALUATION
// ==============================================================================
pub const SPACE_MASK_W: u64 = 0x0000_0000_3C3C_3C00; // c2-f2, c3-f3, c4-f4
pub const SPACE_MASK_B: u64 = 0x003C_3C3C_0000_0000; // c5-f5, c6-f6, c7-f7
pub const SPACE_WEIGHT_MG: i32 = 1;

// ==============================================================================
// PIECE POSITIONAL
// ==============================================================================
pub const BISHOP_PAIR_BONUS_MG: i32 = 30;
pub const BISHOP_PAIR_BONUS_EG: i32 = 45;
pub const OUTPOST_BONUS_MG: [i32; 6] = [0, 22, 16, 0, 0, 0]; // N, B
pub const OUTPOST_BONUS_EG: [i32; 6] = [0, 15, 10, 0, 0, 0];
pub const ROOK_OPEN_FILE_MG: i32 = 28;
pub const ROOK_OPEN_FILE_EG: i32 = 18;
pub const ROOK_SEMI_OPEN_FILE_MG: i32 = 12;
pub const ROOK_SEMI_OPEN_FILE_EG: i32 = 8;
pub const ROOK_ON_7TH_MG: i32 = 20;
pub const ROOK_ON_7TH_EG: i32 = 32;
pub const QUEEN_ON_7TH_MG: i32 = 12;
pub const QUEEN_ON_7TH_EG: i32 = 25;

/// Penalty for early queen development (before minors are developed).
pub const EARLY_QUEEN_PENALTY_MG: i32 = -40;
pub const EARLY_QUEEN_PENALTY_PER_UNDEVELOPED: i32 = -12;

/// Minor piece protected by a pawn directly in front of it.
pub const MINOR_BEHIND_PAWN_MG: i32 = 5;
pub const MINOR_BEHIND_PAWN_EG: i32 = 0;

/// Bad bishop: penalty per own pawn on same color complex.
pub const BAD_BISHOP_PENALTY_PER_PAWN_MG: i32 = -6;
pub const BAD_BISHOP_PENALTY_PER_PAWN_EG: i32 = -8;

/// Connectivity: bonus for pieces defended by other pieces.
pub const CONNECTIVITY_BONUS_MG: i32 = 2;
pub const CONNECTIVITY_BONUS_EG: i32 = 2;

// ==============================================================================
// THREATS
// ==============================================================================
pub const THREAT_MINOR_ATTACKS_MAJOR_MG: i32 = 22;
pub const THREAT_MINOR_ATTACKS_MAJOR_EG: i32 = 25;
pub const THREAT_PAWN_ATTACKS_MINOR_MG: i32 = 22;
pub const THREAT_PAWN_ATTACKS_MINOR_EG: i32 = 16;
pub const THREAT_ROOK_ATTACKS_QUEEN_MG: i32 = 28;
pub const THREAT_ROOK_ATTACKS_QUEEN_EG: i32 = 22;
pub const HANGING_PIECE_BONUS_MG: i32 = 50;
pub const HANGING_PIECE_BONUS_EG: i32 = 45;
pub const THREAT_SAFE_PAWN_MG: i32 = 12;
pub const THREAT_SAFE_PAWN_EG: i32 = 9;

// ==============================================================================
// KING SAFETY
// ==============================================================================
pub const KING_ATTACK_WEIGHT: [i32; 6] = [0, 55, 40, 32, 8, 0];
pub const PAWN_ATTACK_KING_WEIGHT: i32 = 4;

/// Safety table capped lower (~255cp) – mais pessimista.
pub const KING_SAFETY_TABLE: [i32; 100] = [
      0,   0,   0,   1,   1,   2,   3,   4,   6,   8,
     10,  13,  16,  19,  23,  27,  32,  37,  42,  48,
     54,  60,  67,  74,  81,  88,  96, 104, 112, 120,
    128, 136, 144, 152, 160, 168, 175, 182, 189, 195,
    201, 207, 212, 217, 222, 226, 230, 234, 237, 240,
    243, 245, 247, 249, 250, 251, 252, 253, 254, 254,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
];

pub const PAWN_SHIELD_BONUS: [i32; 4] = [0, 18, 9, 3];
pub const PAWN_SHIELD_MISSING: i32 = -22;
pub const ENEMY_PAWN_STORM: [i32; 8] = [0, 0, 0, -40, -22, -12, 0, 0];
pub const WEAK_KING_SQUARE_PENALTY: i32 = 5;

// ==============================================================================
// NON-LINEAR MOBILITY TABLES
// ==============================================================================
pub const KNIGHT_MOBILITY_MG: [i32; 9] = [-18, -8, -2, 3, 7, 11, 14, 17, 20];
pub const KNIGHT_MOBILITY_EG: [i32; 9] = [-22, -10, -2, 5, 11, 17, 22, 26, 30];

pub const BISHOP_MOBILITY_MG: [i32; 14] = [-22, -12, -5, 1, 6, 11, 15, 18, 21, 23, 24, 25, 26, 27];
pub const BISHOP_MOBILITY_EG: [i32; 14] = [-28, -14, -5, 3, 9, 15, 20, 24, 27, 30, 32, 33, 34, 35];

pub const ROOK_MOBILITY_MG: [i32; 15] = [-18, -12, -5, 1, 6, 11, 15, 19, 22, 24, 26, 27, 28, 29, 30];
pub const ROOK_MOBILITY_EG: [i32; 15] = [-22, -13, -5, 3, 9, 15, 21, 26, 30, 33, 35, 37, 38, 39, 40];

pub const QUEEN_MOBILITY_MG: [i32; 28] = [
    -35, -22, -12, -6, -1, 3, 7, 11, 14, 17, 19, 21, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38,
];
pub const QUEEN_MOBILITY_EG: [i32; 28] = [
    -40, -26, -14, -5, 3, 9, 15, 21, 26, 30, 33, 36, 38, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54,
];

// ==============================================================================
// PIECE-SQUARE TABLES (PeSTO-style, versão pessimista – magnitudes reduzidas)
// ==============================================================================
#[rustfmt::skip]
pub const MG_PAWN: [i32; 64] = [
      0,   0,   0,   0,   0,   0,   0,   0,
     70,  95,  45,  70,  70,  45,  95,  70,
     -8,   4,  18,  22,  22,  18,   4,  -8,
    -12,   8,   4,  14,  14,   4,   8, -12,
    -20,  -2,   3,  32,  32,   3,  -2, -20,
    -20,  -4,  -4, -16, -16,  -4,  -4, -20,
    -28,  -2, -15, -18, -18, -15,  -2, -28,
      0,   0,   0,   0,   0,   0,   0,   0,
];

#[rustfmt::skip]
pub const EG_PAWN: [i32; 64] = [
      0,   0,   0,   0,   0,   0,   0,   0,
    130, 125, 115, 100, 100, 115, 125, 130,
     70,  75,  62,  50,  50,  62,  75,  70,
     24,  18,  10,   4,   4,  10,  18,  24,
     10,   7,  -2,  -5,  -5,  -2,   7,  10,
      3,   5,  -4,   1,   1,  -4,   5,   3,
     10,   6,   6,   8,   8,   6,   6,  10,
      0,   0,   0,   0,   0,   0,   0,   0,
];

#[rustfmt::skip]
pub const MG_KNIGHT: [i32; 64] = [
   -120, -65, -25, -35,  40, -70, -12, -80,
    -55, -30,  50,  25,  16,  45,   5, -12,
    -35,  42,  26,  45,  58,  90,  50,  30,
     -8,  12,  14,  38,  26,  48,  12,  15,
    -10,   3,  11,   9,  20,  14,  15,  -6,
    -18,  -7,   8,   7,  14,  12,  18, -12,
    -22, -40, -10,  -2,  -1,  12, -12, -15,
    -80, -16, -42, -24, -12, -20, -15, -18,
];

#[rustfmt::skip]
pub const EG_KNIGHT: [i32; 64] = [
    -45, -30, -10, -20, -22, -20, -48, -75,
    -18,  -6, -18,  -2,  -7, -18, -18, -40,
    -18, -15,   7,   6,  -1,  -7, -14, -30,
    -12,   2,  16,  16,  16,   8,   6, -14,
    -14,  -5,  12,  18,  12,  12,   3, -14,
    -18,  -2,  -1,  11,   7,  -2, -15, -16,
    -32, -15,  -8,  -4,  -2, -15, -18, -34,
    -22, -40, -18, -12, -16, -14, -38, -50,
];

#[rustfmt::skip]
pub const MG_BISHOP: [i32; 64] = [
    -22,   3, -60, -28, -18, -30,   5,  -6,
    -20,  12, -14, -10,  22,  42,  14, -35,
    -12,  26,  30,  28,  25,  35,  26,  -2,
     -3,   4,  14,  35,  26,  26,   5,  -2,
     -5,  10,  10,  18,  24,   9,   7,   3,
      0,  11,  11,  11,  10,  19,  13,   7,
      3,  11,  12,   0,   5,  15,  24,   1,
    -25,  -2, -12, -16, -10, -10, -30, -16,
];

#[rustfmt::skip]
pub const EG_BISHOP: [i32; 64] = [
    -12, -16,  -8,  -6,  -5,  -7, -14, -18,
     -6,  -3,   5, -10,  -2, -10,  -3, -12,
      1,  -6,   0,  -1,  -2,   4,   0,   3,
     -2,   7,   9,   7,  10,   7,   2,   1,
     -5,   2,  10,  14,   5,   7,  -2,  -7,
    -10,  -2,   6,   7,  10,   2,  -5, -12,
    -12, -14,  -5,  -1,   3,  -7, -12, -20,
    -18,  -7, -18,  -4,  -7, -12,  -4, -14,
];

#[rustfmt::skip]
pub const MG_ROOK: [i32; 64] = [
     22,  30,  22,  36,  45,   6,  22,  30,
     18,  22,  40,  44,  55,  48,  18,  30,
     -4,  14,  18,  25,  12,  32,  42,  12,
    -18,  -8,   5,  18,  16,  25,  -6, -15,
    -26, -18,  -9,  -1,   6,  -5,   4, -16,
    -32, -18, -12, -12,   2,   0,  -4, -24,
    -32, -12, -15,  -7,  -1,   8,  -5, -50,
    -14, -10,   1,  12,  12,   5, -26, -18,
];

#[rustfmt::skip]
pub const EG_ROOK: [i32; 64] = [
      9,   7,  13,  11,   9,   9,   6,   4,
      8,   9,   9,   8,  -2,   2,   6,   2,
      5,   5,   5,   4,   3,  -2,  -4,  -2,
      3,   2,   9,   1,   1,   1,  -1,   1,
      2,   4,   6,   3,  -4,  -5,  -6,  -8,
     -3,   0,  -4,  -1,  -5,  -9,  -6, -12,
     -5,  -5,   0,   1,  -7,  -7,  -8,  -2,
     -7,   1,   2,  -1,  -4, -10,   3, -15,
];

#[rustfmt::skip]
pub const MG_QUEEN: [i32; 64] = [
    -20,   0,  20,   8,  40,  30,  30,  32,
    -18, -28,  -4,   1, -12,  40,  20,  38,
    -10, -12,   5,   6,  20,  40,  33,  40,
    -20, -20, -12, -12,  -1,  12,  -2,   1,
     -7, -18,  -7,  -8,  -2,  -3,   2,  -2,
    -10,   1,  -8,  -2,  -4,   1,  10,   4,
    -25,  -6,   8,   1,   6,  11,  -2,   1,
     -1, -14,  -7,   7, -12, -18, -22, -35,
];

#[rustfmt::skip]
pub const EG_QUEEN: [i32; 64] = [
     -7,  16,  16,  20,  20,  14,   7,  15,
    -12,  15,  24,  30,  42,  18,  22,   0,
    -15,   4,   7,  35,  34,  25,  14,   7,
      2,  16,  18,  32,  40,  28,  40,  26,
    -14,  20,  14,  34,  22,  24,  28,  16,
    -12, -20,  11,   4,   7,  12,   7,   4,
    -16, -18, -22, -12, -12, -18, -26, -24,
    -25, -20, -16, -32,  -4, -24, -15, -30,
];

#[rustfmt::skip]
pub const MG_KING: [i32; 64] = [
    -50,  16,  12, -12, -42, -25,   1,  10,
     20,  -1, -15,  -5,  -6,  -3, -28, -22,
     -7,  18,   1, -12, -15,   4,  16, -16,
    -14, -15,  -9, -20, -22, -18, -10, -28,
    -38,  -1, -20, -30, -35, -32, -25, -40,
    -12, -12, -16, -35, -32, -22, -12, -20,
      1,   5,  -6, -48, -32, -12,   7,   6,
    -12,  25,   9, -40,   6, -20,  18,  10,
];

#[rustfmt::skip]
pub const EG_KING: [i32; 64] = [
    -55, -25, -14, -14,  -8,  12,   3, -14,
    -10,  12,  10,  12,  12,  28,  16,   8,
      7,  12,  16,  11,  15,  32,  32,  10,
     -6,  16,  18,  20,  18,  24,  18,   2,
    -14,  -3,  15,  18,  20,  16,   7,  -8,
    -14,  -2,   8,  15,  16,  12,   5,  -7,
    -20,  -8,   3,  10,  10,   3,  -4, -14,
    -40, -25, -16,  -8, -20, -12, -18, -32,
];

pub const MG_TABLES: [&[i32; 64]; 6] = [
    &MG_PAWN, &MG_KNIGHT, &MG_BISHOP, &MG_ROOK, &MG_QUEEN, &MG_KING,
];
pub const EG_TABLES: [&[i32; 64]; 6] = [
    &EG_PAWN, &EG_KNIGHT, &EG_BISHOP, &EG_ROOK, &EG_QUEEN, &EG_KING,
];

// ==============================================================================
// ENDGAME
// ==============================================================================
pub const LIGHT_SQUARES: u64 = 0x55AA_55AA_55AA_55AAu64;

// ==============================================================================
// GLAURUNG THREAT MATRICES
// ==============================================================================
pub const THREAT_BY_MINOR_MG: [i32; 7] = [0, 3, 18, 25, 32, 40, 0];
pub const THREAT_BY_MINOR_EG: [i32; 7] = [0, 3, 18, 25, 32, 40, 0];
pub const THREAT_BY_ROOK_MG: [i32; 7] = [0, 3, 7, 10, 14, 32, 0];
pub const THREAT_BY_ROOK_EG: [i32; 7] = [0, 3, 7, 10, 14, 32, 0];
pub const THREAT_BY_KING_MG: [i32; 7] = [0, 12, 12, 12, 12, 12, 0];
pub const THREAT_BY_KING_EG: [i32; 7] = [0, 12, 12, 12, 12, 12, 0];

pub const WEAK_QUEEN_PENALTY_MG: i32 = -65;
pub const WEAK_QUEEN_PENALTY_EG: i32 = -65;
pub const SLIDER_ON_QUEEN_PENALTY_MG: i32 = -28;
pub const SLIDER_ON_QUEEN_PENALTY_EG: i32 = -28;

pub const ROOK_ON_FILE_MG: [i32; 2] = [12, 30]; // semi-open, open
pub const ROOK_ON_FILE_EG: [i32; 2] = [5, 14];

pub const TRAPPED_ROOK_PENALTY_MG: i32 = -70;
pub const TRAPPED_ROOK_PENALTY_EG: i32 = -20;
pub const CORNERED_BISHOP_PENALTY_MG: i32 = -35;
pub const CORNERED_BISHOP_PENALTY_EG: i32 = -35;
pub const PAWNLESS_FLANK_PENALTY_MG: i32 = -22;
pub const PAWNLESS_FLANK_PENALTY_EG: i32 = -22;
pub const BISHOP_PAWNS_PENALTY_MG: i32 = -5;
pub const BISHOP_PAWNS_PENALTY_EG: i32 = -6;

pub const PASSED_FILE_BONUS_MG: [i32; 8] = [6, 6, 10, 14, 14, 10, 6, 6];
pub const PASSED_FILE_BONUS_EG: [i32; 8] = [10, 10, 16, 22, 22, 16, 10, 10];

pub const CONNECTED_BONUS_MG: [i32; 8] = [0, 0, 6, 12, 18, 28, 40, 0];
pub const CONNECTED_BONUS_EG: [i32; 8] = [0, 0, 10, 16, 26, 40, 55, 0];
