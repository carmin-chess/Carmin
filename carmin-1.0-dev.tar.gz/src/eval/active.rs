use crate::board::Board;
use crate::personality;
use crate::types::{Color, PieceType};
use crate::bitboard::iter;
use super::EvalState;

// ================================================================================================
// CONSTANTS FOR ACTIVITY / ACTIVE PIECES
// ================================================================================================

// ================================================================================================
// CONSTANTS FOR ACTIVITY / ACTIVE PIECES
// ================================================================================================

const FLANK_ATTACK_MG: [i32; 6] = [0, 2, 3, 4, 5, 0];
const FLANK_ATTACK_EG: [i32; 6] = [0, 1, 2, 2, 3, 0];

const KING_FLANK_CONTACT_MG: i32 = 4;
const KING_FLANK_CONTACT_EG: i32 = 2;

const USEFUL_ATTACK_BONUS_MG: i32 = 2;
const USEFUL_ATTACK_BONUS_EG: i32 = 1;
const COSMETIC_ATTACK_PENALTY_MG: i32 = -1;
const COSMETIC_ATTACK_PENALTY_EG: i32 = -1;

const DEFENSE_WEIGHT_MG: i32 = 3;
const DEFENSE_WEIGHT_EG: i32 = 2;
const OVER_ATTACK_PENALTY_MG: i32 = -2;
const OVER_ATTACK_PENALTY_EG: i32 = -2;

const SAFETY_RATIO_THRESHOLD: i32 = 2;

// ----- Rook penetration & concrete function -----

const ROOK_ON_7TH_MG: i32 = 7;
const ROOK_ON_7TH_EG: i32 = 11;
const ROOK_ON_6TH_MG: i32 = 4;
const ROOK_ON_6TH_EG: i32 = 6;

const ROOK_DUAL_THREAT_MG: i32 = 5;
const ROOK_DUAL_THREAT_EG: i32 = 6;

const ROOK_PENETRATING_FILE_MG: i32 = 3;
const ROOK_PENETRATING_FILE_EG: i32 = 4;

const ROOK_SUPPORTS_PASSED_MG: i32 = 2;
const ROOK_SUPPORTS_PASSED_EG: i32 = 5;

// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_activity(
    board: &Board,
    state: &mut EvalState,
    color: Color,
) {
    let ci = color.index();
    let mg_before = state.mg[ci];
    let eg_before = state.eg[ci];
    let opp = color.opponent();
    let opp_ci = opp.index();

    let my_king = board.king_square(color);
    let opp_king = board.king_square(opp);
    let opp_king_ring = state.king_ring[opp_ci];
    let my_king_ring = state.king_ring[ci];

    // Determine enemy king flank (queenside = files 0-3, kingside = files 4-7)
    let opp_k_file = opp_king.file() as usize;
    let flank_mask = if opp_k_file < 4 {
        0x0F0F0F0F0F0F0F0Fu64 // a–d
    } else {
        0xF0F0F0F0F0F0F0F0u64 // e–h
    };

    let enemies = board.color_bb[opp_ci];
    let my_pieces = board.color_bb[ci]
        ^ board.pieces_of(color, PieceType::Pawn)
        ^ board.pieces_of(color, PieceType::King);
    let occ = board.occupancy;
    let my_passed = state.passed_pawns[ci];

    let mut pure_attackers = 0i32;
    let mut defenders_near_king = 0i32;

    // ------------------------------------------------------------------
    // 1. Pieces attacking the enemy king / queen flank
    // ------------------------------------------------------------------
    for &pt in &[PieceType::Knight, PieceType::Bishop, PieceType::Rook, PieceType::Queen] {
        let pieces = board.pieces_of(color, pt);
        let p_idx = pt.index();

        for sq in iter(pieces) {
            let att = match pt {
                PieceType::Knight => crate::attacks::knight_attacks(sq),
                PieceType::Bishop => crate::attacks::bishop_attacks(sq, occ),
                PieceType::Rook => crate::attacks::rook_attacks(sq, occ),
                PieceType::Queen => crate::attacks::queen_attacks(sq, occ),
                _ => 0,
            };

            // Flank pressure
            let flank_hits = att & flank_mask;
            if flank_hits != 0 {
                state.mg[ci] += FLANK_ATTACK_MG[p_idx];
                state.eg[ci] += FLANK_ATTACK_EG[p_idx];

                // Contact with king ring is especially useful
                if (flank_hits & opp_king_ring) != 0 {
                    state.mg[ci] += KING_FLANK_CONTACT_MG;
                    state.eg[ci] += KING_FLANK_CONTACT_EG;
                }
            }

            // ------------------------------------------------------------------
            // 2. Useful vs cosmetic attacks
            // ------------------------------------------------------------------
            let hits_enemy = att & enemies;
            let hits_king_ring = att & opp_king_ring;
            let hits_weak = att & state.mob_area[opp_ci]; // squares the enemy does not safely control

            if hits_enemy != 0 || hits_king_ring != 0 || (hits_weak & flank_mask) != 0 {
                state.mg[ci] += USEFUL_ATTACK_BONUS_MG;
                state.eg[ci] += USEFUL_ATTACK_BONUS_EG;
            } else if (att & !board.color_bb[ci]).count_ones() >= 3 {
                // Lots of empty squares far from the action → cosmetic
                state.mg[ci] += COSMETIC_ATTACK_PENALTY_MG;
                state.eg[ci] += COSMETIC_ATTACK_PENALTY_EG;
            }

            // Track pure attackers (pieces that attack enemy territory but are not near our king)
            let near_our_king = ((1u64 << sq.index()) & my_king_ring) != 0
                || (crate::attacks::king_attacks(my_king) & (1u64 << sq.index())) != 0;
            if (att & (enemies | opp_king_ring)) != 0 && !near_our_king {
                pure_attackers += 1;
            }

            // ------------------------------------------------------------------
            // 3. Rook-specific concrete activity (penetration & function)
            // ------------------------------------------------------------------
            if pt == PieceType::Rook {
                let rank = sq.rank() as i32;
                let is_white = color == Color::White;

                // 7th rank (relative)
                let on_7th = if is_white { rank == 6 } else { rank == 1 };
                let on_6th = if is_white { rank == 5 } else { rank == 2 };

                if on_7th {
                    state.mg[ci] += ROOK_ON_7TH_MG;
                    state.eg[ci] += ROOK_ON_7TH_EG;
                } else if on_6th && (att & opp_king_ring) != 0 {
                    // 6th only counts if it already restricts the king
                    state.mg[ci] += ROOK_ON_6TH_MG;
                    state.eg[ci] += ROOK_ON_6TH_EG;
                }

                // Dual threat: hits king ring AND an enemy piece/pawn
                if (att & opp_king_ring) != 0 && (att & enemies) != 0 {
                    state.mg[ci] += ROOK_DUAL_THREAT_MG;
                    state.eg[ci] += ROOK_DUAL_THREAT_EG;
                }

                // Penetrating file: open/semi-open file pointing into the enemy king flank
                let f = sq.file() as usize;
                let file_mask = 0x0101010101010101u64 << f;
                let own_pawns = board.pieces_of(color, PieceType::Pawn);
                let on_openish = (own_pawns & file_mask) == 0;
                if on_openish && (file_mask & flank_mask) != 0 {
                    // Rook on a file that belongs to the enemy king flank and is (semi)open
                    if (att & flank_mask & (enemies | opp_king_ring | state.mob_area[opp_ci])) != 0 {
                        state.mg[ci] += ROOK_PENETRATING_FILE_MG;
                        state.eg[ci] += ROOK_PENETRATING_FILE_EG;
                    }
                }

                // Supports own passed pawn (rook behind or on adjacent file with forward scope)
                if my_passed != 0 {
                    let behind_or_side = if is_white {
                        let mut mask = 0u64;
                        for psq in iter(my_passed) {
                            let pf = psq.file() as i32;
                            let pr = psq.rank() as i32;
                            for r in 0..pr {
                                for df in -1i32..=1 {
                                    let nf = pf + df;
                                    if nf >= 0 && nf <= 7 {
                                        mask |= 1u64 << (r * 8 + nf);
                                    }
                                }
                            }
                        }
                        mask
                    } else {
                        let mut mask = 0u64;
                        for psq in iter(my_passed) {
                            let pf = psq.file() as i32;
                            let pr = psq.rank() as i32;
                            for r in (pr + 1)..=7 {
                                for df in -1i32..=1 {
                                    let nf = pf + df;
                                    if nf >= 0 && nf <= 7 {
                                        mask |= 1u64 << (r * 8 + nf);
                                    }
                                }
                            }
                        }
                        mask
                    };
                    if ((1u64 << sq.index()) & behind_or_side) != 0 {
                        // and the rook still has some forward attacks (not completely blocked)
                        let forward_dir = if is_white { att >> 8 } else { att << 8 };
                        if forward_dir != 0 || (att & my_passed) != 0 {
                            state.mg[ci] += ROOK_SUPPORTS_PASSED_MG;
                            state.eg[ci] += ROOK_SUPPORTS_PASSED_EG;
                        }
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // 4. Safety: defense >> attack
    // Count pieces that are actively defending our king ring or our hanging pieces
    // ------------------------------------------------------------------
    let my_hanging = my_pieces & state.attacks[opp_ci] & !state.attacks[ci];
    let defensive_zone = my_king_ring | my_hanging;

    for &pt in &[PieceType::Knight, PieceType::Bishop, PieceType::Rook, PieceType::Queen] {
        let pieces = board.pieces_of(color, pt);
        for sq in iter(pieces) {
            let att = match pt {
                PieceType::Knight => crate::attacks::knight_attacks(sq),
                PieceType::Bishop => crate::attacks::bishop_attacks(sq, occ),
                PieceType::Rook => crate::attacks::rook_attacks(sq, occ),
                PieceType::Queen => crate::attacks::queen_attacks(sq, occ),
                _ => 0,
            };

            if (att & defensive_zone) != 0 || ((1u64 << sq.index()) & my_king_ring) != 0 {
                defenders_near_king += 1;
                state.mg[ci] += DEFENSE_WEIGHT_MG;
                state.eg[ci] += DEFENSE_WEIGHT_EG;
            }
        }
    }

    // Also count friendly pawns that shield the king
    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    if (my_pawns & my_king_ring) != 0 {
        defenders_near_king += (my_pawns & my_king_ring).count_ones() as i32;
        state.mg[ci] += DEFENSE_WEIGHT_MG;
        state.eg[ci] += DEFENSE_WEIGHT_EG / 2;
    }

    // Over-attack penalty: many pure attackers but few defenders → reckless
    if pure_attackers >= SAFETY_RATIO_THRESHOLD && defenders_near_king < pure_attackers {
        let excess = pure_attackers - defenders_near_king;
        state.mg[ci] += excess * OVER_ATTACK_PENALTY_MG;
        state.eg[ci] += excess * OVER_ATTACK_PENALTY_EG;
    }

    // Apply personality scaling (activity / initiative axis)
    let cfg = personality::config();
    let mg_delta = state.mg[ci] - mg_before;
    let eg_delta = state.eg[ci] - eg_before;
    state.mg[ci] = mg_before + cfg.scale(mg_delta, cfg.initiative);
    state.eg[ci] = eg_before + cfg.scale(eg_delta, cfg.initiative);
}

// ------------------------------------------------------------------------------------------------
// HELPER / DUMMY ANALYSIS (kept for future tuning)
// ------------------------------------------------------------------------------------------------

#[allow(dead_code)]
fn count_flank_pressure(board: &Board, color: Color, flank_mask: u64) -> i32 {
    let mut pressure = 0;
    let opp = color.opponent();
    let occ = board.occupancy;
    for &pt in &[PieceType::Knight, PieceType::Bishop, PieceType::Rook, PieceType::Queen] {
        for sq in iter(board.pieces_of(color, pt)) {
            let att = match pt {
                PieceType::Knight => crate::attacks::knight_attacks(sq),
                PieceType::Bishop => crate::attacks::bishop_attacks(sq, occ),
                PieceType::Rook => crate::attacks::rook_attacks(sq, occ),
                PieceType::Queen => crate::attacks::queen_attacks(sq, occ),
                _ => 0,
            };
            pressure += (att & flank_mask & board.color_bb[opp.index()]).count_ones() as i32;
        }
    }
    pressure
}

#[allow(dead_code)]
fn is_cosmetic_only(att: u64, enemies: u64, king_ring: u64, flank: u64) -> bool {
    (att & enemies) == 0 && (att & king_ring) == 0 && (att & flank) == 0
}
// END OF active.rs
