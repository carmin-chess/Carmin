use crate::attacks;
use crate::bitboard::iter;
use crate::board::Board;
use crate::personality;
use crate::types::{Color, PieceType};
use super::params::*;

pub fn evaluate_threats(board: &Board, state: &mut super::EvalState, color: Color) {
    let ci = color.index();
    let opp = color.opponent();
    let opp_ci = opp.index();

    let mg_before = state.mg[ci];
    let eg_before = state.eg[ci];

    let my_attacks = state.attacks[ci];
    let opp_attacks = state.attacks[opp_ci];
    
    let opp_rooks = board.pieces_of(opp, PieceType::Rook);
    let opp_queens = board.pieces_of(opp, PieceType::Queen);
    let _opp_majors = opp_rooks | opp_queens;
    
    let opp_knights = board.pieces_of(opp, PieceType::Knight);
    let opp_bishops = board.pieces_of(opp, PieceType::Bishop);
    let _opp_minors = opp_knights | opp_bishops;

    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    let my_knights = board.pieces_of(color, PieceType::Knight);
    let my_bishops = board.pieces_of(color, PieceType::Bishop);
    let my_rooks = board.pieces_of(color, PieceType::Rook);
    
    let enemies = board.color_bb[opp_ci];

    // 1. Threats using Glaurung matrices
    // Minors attacking enemies
    let my_minor_attacks = state.attacks_by[ci][PieceType::Knight.index()] | state.attacks_by[ci][PieceType::Bishop.index()];
    for &pt in crate::types::PIECE_TYPES.iter() {
        let opp_pieces_pt = board.pieces_of(opp, pt);
        let attacked = my_minor_attacks & opp_pieces_pt;
        if attacked != 0 {
            let count = attacked.count_ones() as i32;
            state.mg[ci] += count * THREAT_BY_MINOR_MG[pt.index()];
            state.eg[ci] += count * THREAT_BY_MINOR_EG[pt.index()];
        }
    }

    // Rooks attacking enemies
    let my_rook_attacks = state.attacks_by[ci][PieceType::Rook.index()];
    for &pt in crate::types::PIECE_TYPES.iter() {
        let opp_pieces_pt = board.pieces_of(opp, pt);
        let attacked = my_rook_attacks & opp_pieces_pt;
        if attacked != 0 {
            let count = attacked.count_ones() as i32;
            state.mg[ci] += count * THREAT_BY_ROOK_MG[pt.index()];
            state.eg[ci] += count * THREAT_BY_ROOK_EG[pt.index()];
        }
    }
    
    // King threats (when king can capture undefended pieces)
    let my_king_sq = board.king_square(color);
    let my_king_attacks = crate::attacks::king_attacks(my_king_sq);
    let undefended_enemies = enemies & !opp_attacks;
    let king_threats = my_king_attacks & undefended_enemies;
    for &pt in crate::types::PIECE_TYPES.iter() {
        let opp_pieces_pt = board.pieces_of(opp, pt);
        let attacked = king_threats & opp_pieces_pt;
        if attacked != 0 {
            let count = attacked.count_ones() as i32;
            state.mg[ci] += count * THREAT_BY_KING_MG[pt.index()];
            state.eg[ci] += count * THREAT_BY_KING_EG[pt.index()];
        }
    }

    // 3. Rook attacks queen
    for sq in iter(my_rooks) {
        let att = attacks::rook_attacks(sq, board.occupancy);
        if (att & opp_queens) != 0 {
            state.mg[ci] += THREAT_ROOK_ATTACKS_QUEEN_MG;
            state.eg[ci] += THREAT_ROOK_ATTACKS_QUEEN_EG;
        }
    }

    // 4. Hanging pieces
    let hanging = enemies & my_attacks & !opp_attacks;
    if hanging != 0 {
        let count = hanging.count_ones() as i32;
        state.mg[ci] += count * HANGING_PIECE_BONUS_MG;
        state.eg[ci] += count * HANGING_PIECE_BONUS_EG;
    }

    // 5. Safe pawn threats
    let safe_pawns = my_pawns & my_attacks;
    for sq in iter(safe_pawns) {
        let p_att = attacks::pawn_attacks(color, sq);
        if (p_att & enemies) != 0 {
            state.mg[ci] += THREAT_SAFE_PAWN_MG;
            state.eg[ci] += THREAT_SAFE_PAWN_EG;
        }
    }

    // Weak Queen Penalty
    for sq in iter(board.pieces_of(color, PieceType::Queen)) {
        // If our queen is attacked by an enemy slider (X-ray)
        let _opp_sliders = board.pieces_of(opp, PieceType::Rook) | board.pieces_of(opp, PieceType::Bishop) | board.pieces_of(opp, PieceType::Queen);
        let slider_attacks = (crate::attacks::rook_attacks(sq, board.occupancy) & (board.pieces_of(opp, PieceType::Rook) | board.pieces_of(opp, PieceType::Queen))) |
                             (crate::attacks::bishop_attacks(sq, board.occupancy) & (board.pieces_of(opp, PieceType::Bishop) | board.pieces_of(opp, PieceType::Queen)));
        if slider_attacks != 0 {
            state.mg[ci] += WEAK_QUEEN_PENALTY_MG;
            state.eg[ci] += WEAK_QUEEN_PENALTY_EG;
        }
    }

    // 6. Mapa Mental: Penalizar Peças Cravadas
    let cravadas = board.pinned_pieces(color);
    if cravadas != 0 {
        let count = cravadas.count_ones() as i32;
        // Punição de ~10cp como o usuário pediu "só uns 10cp"
        state.mg[ci] -= count * 10;
        state.eg[ci] -= count * 10;
    }

    // Peças "presas" (sem mobilidade e atacadas)
    // Uma heurística simples: cavalo ou bispo nas bordas que estão atacados por peões
    let bordas = 0xff818181818181ff;
    let presas = (my_knights | my_bishops) & bordas & opp_attacks;
    if presas != 0 {
        let count = presas.count_ones() as i32;
        state.mg[ci] -= count * 10;
        state.eg[ci] -= count * 10;
    }

    // Apply personality scaling to the threat contribution of this side
    let cfg = personality::config();
    let mg_delta = state.mg[ci] - mg_before;
    let eg_delta = state.eg[ci] - eg_before;
    state.mg[ci] = mg_before + cfg.scale(mg_delta, cfg.threats);
    state.eg[ci] = eg_before + cfg.scale(eg_delta, cfg.threats);
}
