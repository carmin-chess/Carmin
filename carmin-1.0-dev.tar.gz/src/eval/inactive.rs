use crate::board::Board;
use crate::personality;
use crate::types::{Color, PieceType, Square};
use crate::bitboard::iter;
use super::EvalState;

// ================================================================================================
// CONSTANTS FOR INACTIVITY / UNCOORDINATED PIECES
// ================================================================================================

// Rooks not on the same file/rank and not connected
const UNCOORDINATED_ROOKS_MG: i32 = -12;
const UNCOORDINATED_ROOKS_EG: i32 = -18;

// Queen not supported by a rook (no shared file/rank / no mutual attack)
const QUEEN_ROOK_UNCOORDINATED_MG: i32 = -8;
const QUEEN_ROOK_UNCOORDINATED_EG: i32 = -10;

// Two queens with no mutual support
const UNCOORDINATED_QUEENS_MG: i32 = -15;
const UNCOORDINATED_QUEENS_EG: i32 = -20;

// Piece has almost no useful attacks and is not defended → inactive
const INACTIVE_MINOR_MG: i32 = -10;
const INACTIVE_MINOR_EG: i32 = -8;
const INACTIVE_ROOK_MG: i32 = -14;
const INACTIVE_ROOK_EG: i32 = -12;
const INACTIVE_QUEEN_MG: i32 = -18;
const INACTIVE_QUEEN_EG: i32 = -15;

// Isolated piece (no friendly non-pawn piece nearby)
const ISOLATED_PIECE_MG: i32 = -6;
const ISOLATED_PIECE_EG: i32 = -5;

// Minimum safe mobility to be considered "active"
const MIN_ACTIVE_MOBILITY_MINOR: u32 = 2;
const MIN_ACTIVE_MOBILITY_ROOK: u32 = 3;
const MIN_ACTIVE_MOBILITY_QUEEN: u32 = 4;

// ----- Function-based inactivity (the key lesson from the game) -----
// A piece without concrete function is worse than a piece that is merely "quiet".
// Useful defence (holding a passer, restricting the king, protecting a key square)
// should NOT be treated as inactivity.

// Rook that does none of: restrict enemy king, hold enemy passer, sit on open file,
// attack anything relevant, or defend a hanging piece → pure reactive / functionless
const FUNCTIONLESS_ROOK_MG: i32 = -16;
const FUNCTIONLESS_ROOK_EG: i32 = -20;

// Minor/Queen without any concrete role (no attack, no defence of key assets, no restriction)
const FUNCTIONLESS_MINOR_MG: i32 = -9;
const FUNCTIONLESS_MINOR_EG: i32 = -7;
const FUNCTIONLESS_QUEEN_MG: i32 = -14;
const FUNCTIONLESS_QUEEN_EG: i32 = -12;

// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_inactivity(
    board: &Board,
    state: &mut EvalState,
    color: Color,
) {
    let ci = color.index();
    let mg_before = state.mg[ci];
    let eg_before = state.eg[ci];
    let opp = color.opponent();
    let opp_ci = opp.index();
    let occ = board.occupancy;
    let safe = state.mob_area[ci];
    let my_attacks = state.attacks[ci];

    let my_rooks = board.pieces_of(color, PieceType::Rook);
    let my_queens = board.pieces_of(color, PieceType::Queen);
    let my_knights = board.pieces_of(color, PieceType::Knight);
    let my_bishops = board.pieces_of(color, PieceType::Bishop);
    let my_pieces = board.color_bb[ci]
        ^ board.pieces_of(color, PieceType::Pawn)
        ^ board.pieces_of(color, PieceType::King);

    let opp_bb = board.color_bb[opp_ci];
    let opp_ring = state.king_ring[opp_ci];
    let my_king_ring = state.king_ring[ci];
    let pawn_def = state.attacks_by[ci][PieceType::Pawn.index()];
    let my_passed = state.passed_pawns[ci];
    let opp_passed = state.passed_pawns[opp_ci];
    let my_hanging = my_pieces & state.attacks[opp_ci] & !state.attacks[ci];

    // ------------------------------------------------------------------
    // 1. Uncoordinated Rooks
    // ------------------------------------------------------------------
    let rook_count = my_rooks.count_ones();
    if rook_count >= 2 {
        let mut squares: [Option<Square>; 4] = [None; 4];
        let mut n = 0usize;
        for sq in iter(my_rooks) {
            if n < 4 {
                squares[n] = Some(sq);
                n += 1;
            }
        }
        let mut coordinated = false;
        for i in 0..n {
            for j in (i + 1)..n {
                let a = squares[i].unwrap();
                let b = squares[j].unwrap();
                if rooks_connected(a, b, occ) {
                    coordinated = true;
                    break;
                }
            }
            if coordinated {
                break;
            }
        }
        if !coordinated {
            state.mg[ci] += UNCOORDINATED_ROOKS_MG;
            state.eg[ci] += UNCOORDINATED_ROOKS_EG;
        }
    }

    // ------------------------------------------------------------------
    // 2. Queen–Rook uncoordinated
    // ------------------------------------------------------------------
    if my_queens != 0 && my_rooks != 0 {
        let mut qr_coord = false;
        for qsq in iter(my_queens) {
            for rsq in iter(my_rooks) {
                if major_pieces_connected(qsq, rsq, occ) {
                    qr_coord = true;
                    break;
                }
            }
            if qr_coord {
                break;
            }
        }
        if !qr_coord {
            state.mg[ci] += QUEEN_ROOK_UNCOORDINATED_MG;
            state.eg[ci] += QUEEN_ROOK_UNCOORDINATED_EG;
        }
    }

    // ------------------------------------------------------------------
    // 3. Uncoordinated Queens
    // ------------------------------------------------------------------
    if my_queens.count_ones() >= 2 {
        let mut qs: [Option<Square>; 2] = [None; 2];
        let mut n = 0usize;
        for sq in iter(my_queens) {
            if n < 2 {
                qs[n] = Some(sq);
                n += 1;
            }
        }
        let mut q_coord = false;
        if n >= 2 {
            let a = qs[0].unwrap();
            let b = qs[1].unwrap();
            if major_pieces_connected(a, b, occ) || on_same_diagonal_clear(a, b, occ) {
                q_coord = true;
            }
        }
        if !q_coord {
            state.mg[ci] += UNCOORDINATED_QUEENS_MG;
            state.eg[ci] += UNCOORDINATED_QUEENS_EG;
        }
    }

    // ------------------------------------------------------------------
    // 4. Inactive / isolated pieces  +  function-based penalties
    // ------------------------------------------------------------------

    // Knights
    for sq in iter(my_knights) {
        let att = crate::attacks::knight_attacks(sq);
        let safe_mob = (att & safe).count_ones();
        let is_defended = (my_attacks & (1u64 << sq.index())) != 0
            || (pawn_def & (1u64 << sq.index())) != 0;
        let hits = (att & opp_bb) != 0 || (att & opp_ring) != 0;

        let has_function = piece_has_function(
            att, sq, my_king_ring, opp_ring, my_passed, opp_passed, my_hanging, my_pieces, true,
        );

        if safe_mob < MIN_ACTIVE_MOBILITY_MINOR && !hits && !is_defended && !has_function {
            state.mg[ci] += INACTIVE_MINOR_MG;
            state.eg[ci] += INACTIVE_MINOR_EG;
        }
        if !has_function && safe_mob <= 1 {
            // Extra: truly functionless minor
            state.mg[ci] += FUNCTIONLESS_MINOR_MG;
            state.eg[ci] += FUNCTIONLESS_MINOR_EG;
        }
        if is_isolated(sq, my_pieces) {
            state.mg[ci] += ISOLATED_PIECE_MG;
            state.eg[ci] += ISOLATED_PIECE_EG;
        }
    }

    // Bishops
    for sq in iter(my_bishops) {
        let att = crate::attacks::bishop_attacks(sq, occ);
        let safe_mob = (att & safe).count_ones();
        let is_defended = (my_attacks & (1u64 << sq.index())) != 0
            || (pawn_def & (1u64 << sq.index())) != 0;
        let hits = (att & opp_bb) != 0 || (att & opp_ring) != 0;

        let has_function = piece_has_function(
            att, sq, my_king_ring, opp_ring, my_passed, opp_passed, my_hanging, my_pieces, true,
        );

        if safe_mob < MIN_ACTIVE_MOBILITY_MINOR && !hits && !is_defended && !has_function {
            state.mg[ci] += INACTIVE_MINOR_MG;
            state.eg[ci] += INACTIVE_MINOR_EG;
        }
        if !has_function && safe_mob <= 1 {
            state.mg[ci] += FUNCTIONLESS_MINOR_MG;
            state.eg[ci] += FUNCTIONLESS_MINOR_EG;
        }
        if is_isolated(sq, my_pieces) {
            state.mg[ci] += ISOLATED_PIECE_MG;
            state.eg[ci] += ISOLATED_PIECE_EG;
        }
    }

    // Rooks — the most important case from the game
    for sq in iter(my_rooks) {
        let att = crate::attacks::rook_attacks(sq, occ);
        let safe_mob = (att & safe).count_ones();
        let is_defended = (my_attacks & (1u64 << sq.index())) != 0;
        let hits = (att & opp_bb) != 0 || (att & opp_ring) != 0;

        let f = sq.file() as usize;
        let file_mask = 0x0101010101010101u64 << f;
        let own_pawns = board.pieces_of(color, PieceType::Pawn);
        let on_openish = (own_pawns & file_mask) == 0;

        let has_function = piece_has_function(
            att, sq, my_king_ring, opp_ring, my_passed, opp_passed, my_hanging, my_pieces, false,
        ) || on_openish;

        // Classic low-mobility inactivity (only if no real function)
        if safe_mob < MIN_ACTIVE_MOBILITY_ROOK && !hits && !is_defended && !has_function {
            state.mg[ci] += INACTIVE_ROOK_MG;
            state.eg[ci] += INACTIVE_ROOK_EG;
        }

        // Stronger penalty: rook that is purely reactive / functionless
        // (the Carmin rook in the endgame — defending, capturing, reacting, never creating)
        if !has_function && !hits && safe_mob < 4 {
            state.mg[ci] += FUNCTIONLESS_ROOK_MG;
            state.eg[ci] += FUNCTIONLESS_ROOK_EG;
        }

        if is_isolated(sq, my_pieces) {
            state.mg[ci] += ISOLATED_PIECE_MG;
            state.eg[ci] += ISOLATED_PIECE_EG;
        }
    }

    // Queens
    for sq in iter(my_queens) {
        let att = crate::attacks::queen_attacks(sq, occ);
        let safe_mob = (att & safe).count_ones();
        let is_defended = (my_attacks & (1u64 << sq.index())) != 0;
        let hits = (att & opp_bb) != 0 || (att & opp_ring) != 0;

        let has_function = piece_has_function(
            att, sq, my_king_ring, opp_ring, my_passed, opp_passed, my_hanging, my_pieces, false,
        );

        if safe_mob < MIN_ACTIVE_MOBILITY_QUEEN && !hits && !is_defended && !has_function {
            state.mg[ci] += INACTIVE_QUEEN_MG;
            state.eg[ci] += INACTIVE_QUEEN_EG;
        }
        if !has_function && safe_mob < 3 {
            state.mg[ci] += FUNCTIONLESS_QUEEN_MG;
            state.eg[ci] += FUNCTIONLESS_QUEEN_EG;
        }
        if is_isolated(sq, my_pieces) {
            state.mg[ci] += ISOLATED_PIECE_MG;
            state.eg[ci] += ISOLATED_PIECE_EG;
        }
    }

    // Personality scaling
    let cfg = personality::config();
    let mg_delta = state.mg[ci] - mg_before;
    let eg_delta = state.eg[ci] - eg_before;
    state.mg[ci] = mg_before + cfg.scale(mg_delta, cfg.initiative);
    state.eg[ci] = eg_before + cfg.scale(eg_delta, cfg.initiative);
}

// ================================================================================================
// HELPERS
// ================================================================================================

/// Returns true if the piece has a concrete useful function:
/// - restricts the enemy king (attacks king ring)
/// - defends own king ring
/// - holds / blocks an enemy passed pawn
/// - supports own passed pawn
/// - defends a hanging friendly piece
fn piece_has_function(
    att: u64,
    sq: Square,
    my_king_ring: u64,
    opp_ring: u64,
    my_passed: u64,
    opp_passed: u64,
    my_hanging: u64,
    my_pieces: u64,
    is_minor: bool,
) -> bool {
    // 1. Restricts enemy king
    if (att & opp_ring) != 0 {
        return true;
    }
    // 2. Defends own king
    if (att & my_king_ring) != 0 || ((1u64 << sq.index()) & my_king_ring) != 0 {
        return true;
    }
    // 3. Stops / attacks enemy passed pawn
    if opp_passed != 0 && (att & opp_passed) != 0 {
        return true;
    }
    // 4. Supports own passed pawn
    if my_passed != 0 && (att & my_passed) != 0 {
        return true;
    }
    // 5. Defends a hanging piece
    if my_hanging != 0 && (att & my_hanging) != 0 {
        return true;
    }
    // 6. For minors: simply being part of a defensive cluster near own pieces is mild function
    if is_minor {
        let nearby = crate::attacks::king_attacks(sq);
        if (nearby & my_pieces) != 0 {
            return true;
        }
    }
    false
}

fn rooks_connected(a: Square, b: Square, occ: u64) -> bool {
    if a.file() == b.file() || a.rank() == b.rank() {
        if ray_clear(a, b, occ) {
            return true;
        }
    }
    let att = crate::attacks::rook_attacks(a, occ);
    (att & (1u64 << b.index())) != 0
}

fn major_pieces_connected(a: Square, b: Square, occ: u64) -> bool {
    if a.file() == b.file() || a.rank() == b.rank() {
        if ray_clear(a, b, occ) {
            return true;
        }
    }
    let ratt = crate::attacks::rook_attacks(a, occ);
    if (ratt & (1u64 << b.index())) != 0 {
        return true;
    }
    let qatt = crate::attacks::queen_attacks(a, occ);
    (qatt & (1u64 << b.index())) != 0
}

fn on_same_diagonal_clear(a: Square, b: Square, occ: u64) -> bool {
    let df = (a.file() as i32 - b.file() as i32).abs();
    let dr = (a.rank() as i32 - b.rank() as i32).abs();
    if df != dr || df == 0 {
        return false;
    }
    ray_clear(a, b, occ)
}

fn ray_clear(a: Square, b: Square, occ: u64) -> bool {
    let af = a.file() as i32;
    let bf = b.file() as i32;
    let ar = a.rank() as i32;
    let br = b.rank() as i32;
    let df = (bf - af).signum();
    let dr = (br - ar).signum();
    if df == 0 && dr == 0 {
        return true;
    }
    let mut f = af + df;
    let mut r = ar + dr;
    while f != bf || r != br {
        if f < 0 || f > 7 || r < 0 || r > 7 {
            return false;
        }
        let idx = (r * 8 + f) as u8;
        if (occ & (1u64 << idx)) != 0 {
            return false;
        }
        f += df;
        r += dr;
    }
    true
}

fn is_isolated(sq: Square, my_pieces: u64) -> bool {
    let f = sq.file() as i32;
    let r = sq.rank() as i32;
    for df in -2i32..=2 {
        for dr in -2i32..=2 {
            if df == 0 && dr == 0 {
                continue;
            }
            let nf = f + df;
            let nr = r + dr;
            if nf < 0 || nf > 7 || nr < 0 || nr > 7 {
                continue;
            }
            let nsq = (nr * 8 + nf) as u8;
            if (my_pieces & (1u64 << nsq)) != 0 {
                return false;
            }
        }
    }
    true
}
// END OF inactive.rs
