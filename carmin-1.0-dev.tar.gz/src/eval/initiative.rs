use crate::board::Board;
use crate::personality;
use crate::types::{Color, PieceType};
use crate::bitboard::iter;
use super::EvalState;

// ================================================================================================
// CONSTANTS FOR INITIATIVE
// ================================================================================================

const HANGING_PIECE_PENALTY: i32 = -10;
const OVERLOADED_PIECE_PENALTY: i32 = -10;

const ATTACK_MOMENTUM_BONUS_MG: i32 = 6; // per piece actively threatening enemy territory


// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_initiative(
    board: &Board,
    state: &mut EvalState,
    color: Color,
) {
    let ci = color.index();
    let mg_before = state.mg[ci];
    let eg_before = state.eg[ci];
    let opp = color.opponent();
    let opp_ci = opp.index();

    // 1. Tempo (Side to move)
    // REMOVIDO: O bônus de tempo já é adicionado no `mod.rs` final `side_score + params::TEMPO_BONUS`.

    // 2. Hanging Pieces (Undefended AND actually attacked by the enemy)
    // Just being undefended is normal in most positions (e.g. Nb1 at move 1)
    // and was firing constantly regardless of real danger. Real "hanging" means
    // the enemy can actually take it for free.
    let my_pieces = board.color_bb[ci] ^ board.pieces_of(color, PieceType::Pawn) ^ board.pieces_of(color, PieceType::King);
    
    // We approximate defended pieces by checking if any of our own attacks intersect with our pieces
    let mut my_defended = 0u64;
    for pt in 0..5 {
        my_defended |= state.attacks_by[ci][pt]; // this includes our own pieces if we generated pseudo-attacks
    }
    
    let undefended = my_pieces & !my_defended & state.attacks[opp_ci];
    let undefended_count = undefended.count_ones();
    
    state.mg[ci] += (undefended_count as i32) * HANGING_PIECE_PENALTY;
    
    // 3. Overloaded Pieces
    // A piece is overloaded if it defends more than 1 piece that is currently being attacked by the enemy
    // This is hard to calculate statically without full dependency graphs, but we can approximate:
    // If a single piece is the ONLY defender of multiple attacked pieces.
    
    let enemy_attacks = state.attacks_by[opp_ci][0] | state.attacks_by[opp_ci][1] | state.attacks_by[opp_ci][2] | state.attacks_by[opp_ci][3] | state.attacks_by[opp_ci][4];
    let attacked_my_pieces = my_pieces & enemy_attacks;
    
    if attacked_my_pieces.count_ones() >= 2 {
        // We have multiple pieces under attack. If we have few defenders, they are likely overloaded.
        // simplified logic:
        state.mg[ci] += OVERLOADED_PIECE_PENALTY;
    }

    // 4. Attack Momentum
    // Pieces residing in the enemy half of the board that are attacking enemy pieces
    let enemy_half = match color {
        Color::White => 0xFFFFFFFF00000000u64,
        Color::Black => 0x00000000FFFFFFFFu64,
    };
    
    let occ = board.occupancy;
    for pt in [PieceType::Knight, PieceType::Bishop, PieceType::Rook, PieceType::Queen] {
        let advanced = board.pieces_of(color, pt) & enemy_half;
        for sq in iter(advanced) {
            let att = match pt {
                PieceType::Knight => crate::attacks::knight_attacks(sq),
                PieceType::Bishop => crate::attacks::bishop_attacks(sq, occ),
                PieceType::Rook => crate::attacks::rook_attacks(sq, occ),
                PieceType::Queen => crate::attacks::queen_attacks(sq, occ),
                _ => 0,
            };
            if (att & board.color_bb[opp_ci]) != 0 {
                state.mg[ci] += ATTACK_MOMENTUM_BONUS_MG;
            }
        }
    }

    // Apply personality scaling for initiative / activity
    let cfg = personality::config();
    let mg_delta = state.mg[ci] - mg_before;
    let eg_delta = state.eg[ci] - eg_before;
    state.mg[ci] = mg_before + cfg.scale(mg_delta, cfg.initiative);
    state.eg[ci] = eg_before + cfg.scale(eg_delta, cfg.initiative);
}

// ------------------------------------------------------------------------------------------------
// EXTENSIVE INITIATIVE DUMMY ANALYSIS LOGIC
// ------------------------------------------------------------------------------------------------

#[allow(dead_code)]
fn evaluate_king_hunt(board: &Board, color: Color) -> i32 {
    let mut score = 0;
    let opp_king = board.king_square(color.opponent());
    
    // If the enemy king has been drawn out of his camp
    let k_rank = opp_king.rank();
    let advanced_king = match color.opponent() {
        Color::White => k_rank >= 3,
        Color::Black => k_rank <= 4,
    };
    
    if advanced_king {
        // King is exposed. We get a massive initiative bonus if we have pieces left.
        let my_majors = (board.pieces_of(color, PieceType::Queen) | board.pieces_of(color, PieceType::Rook)).count_ones();
        score += my_majors as i32 * 50; 
    }
    
    score
}

#[allow(dead_code)]
fn evaluate_pinned_pieces_mobility_loss(board: &Board, color: Color) -> i32 {
    // Actually calculating how much mobility we lose because of pins
    // Relies on board.pinned_pieces()
    let pinned = board.pinned_pieces(color);
    let count = pinned.count_ones();
    
    // If we have a pinned knight, it loses all its mobility
    -(count as i32 * 20)
}
// END OF initiative.rs
