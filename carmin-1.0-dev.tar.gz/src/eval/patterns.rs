use crate::board::Board;
use crate::types::{Color, Square, PieceType};
use crate::bitboard::iter;
use super::EvalState;

// ================================================================================================
// CONSTANTS FOR PATTERNS
// ================================================================================================

const FIANCHETTO_BONUS_MG: i32 = 25;
const FIANCHETTO_BONUS_EG: i32 = 15;

const BROKEN_FIANCHETTO_PENALTY_MG: i32 = -30;
const BROKEN_FIANCHETTO_PENALTY_EG: i32 = -10;

const BLOCKER_BONUS_KNIGHT: i32 = 30; // Knight blocking a passed pawn
const BLOCKER_BONUS_BISHOP: i32 = 15;

const TRAPPED_ROOK_PENALTY_MG: i32 = -40; // Rook trapped by its own king

const GREEK_GIFT_THREAT_BONUS_MG: i32 = 60; // Potential Bxh7 sacrifice

const TRAPPED_BISHOP_PENALTY_MG: i32 = -150;
const TRAPPED_BISHOP_PENALTY_EG: i32 = -100;
const TRAPPED_BISHOP_MINOR_PENALTY_MG: i32 = -75;
const TRAPPED_BISHOP_MINOR_PENALTY_EG: i32 = -50;

// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_patterns(
    board: &Board,
    state: &mut EvalState,
    color: Color,
) {
    let ci = color.index();
    let opp = color.opponent();

    // 1. Fianchetto Patterns
    evaluate_fianchetto(board, state, color, ci);

    // 2. Trapped Rook Pattern
    evaluate_trapped_rook(board, state, color, ci);

    // 3. Blockers of enemy passed pawns
    evaluate_blockers(board, state, color, opp, ci);

    // 4. Greek Gift Potential
    evaluate_greek_gift(board, state, color, opp, ci);

    // 5. Trapped Bishop Pattern
    evaluate_trapped_bishop(board, state, color, ci);
}

fn evaluate_fianchetto(board: &Board, state: &mut EvalState, color: Color, ci: usize) {
    let my_bishops = board.pieces_of(color, PieceType::Bishop);
    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    
    // Kingside fianchetto
    let (_kg_sq, _k_pawn_sq, _k_hole_sq) = match color {
        Color::White => (Square(6), Square(14), Square(15)), // g1(or g2?), g3, h3 etc
        // Actual fianchetto squares:
        // White Kingside: Bishop on g2 (index 14), Pawn on g3 (index 22). Wait, g2 is 14.
        Color::Black => (Square(62), Square(54), Square(55)),
    };
    
    // Proper fianchetto indices
    let (w_ks_b, w_ks_p) = (14, 22); // g2, g3
    let (w_qs_b, w_qs_p) = (9, 17);  // b2, b3
    let (b_ks_b, b_ks_p) = (54, 46); // g7, g6
    let (b_qs_b, b_qs_p) = (49, 41); // b7, b6
    
    let (ks_b, ks_p, qs_b, qs_p) = match color {
        Color::White => (w_ks_b, w_ks_p, w_qs_b, w_qs_p),
        Color::Black => (b_ks_b, b_ks_p, b_qs_b, b_qs_p),
    };

    // Kingside
    if (my_pawns & (1u64 << ks_p)) != 0 {
        if (my_bishops & (1u64 << ks_b)) != 0 {
            state.mg[ci] += FIANCHETTO_BONUS_MG;
            state.eg[ci] += FIANCHETTO_BONUS_EG;
        } else {
            // Broken fianchetto (pawn pushed but bishop is missing)
            state.mg[ci] += BROKEN_FIANCHETTO_PENALTY_MG;
            state.eg[ci] += BROKEN_FIANCHETTO_PENALTY_EG;
        }
    }

    // Queenside
    if (my_pawns & (1u64 << qs_p)) != 0 {
        if (my_bishops & (1u64 << qs_b)) != 0 {
            state.mg[ci] += FIANCHETTO_BONUS_MG;
            state.eg[ci] += FIANCHETTO_BONUS_EG;
        } else {
            state.mg[ci] += BROKEN_FIANCHETTO_PENALTY_MG;
            state.eg[ci] += BROKEN_FIANCHETTO_PENALTY_EG;
        }
    }
}

fn evaluate_trapped_rook(board: &Board, state: &mut EvalState, color: Color, ci: usize) {
    let my_king = board.king_square(color);
    let my_rooks = board.pieces_of(color, PieceType::Rook);
    
    match color {
        Color::White => {
            if my_king.rank() <= 1 && (my_king.file() == 5 || my_king.file() == 6) { // f1, g1
                // Check if h1 rook is trapped
                if (my_rooks & (1u64 << 7)) != 0 && board.piece_on(Square(6)).is_some() {
                    state.mg[ci] += TRAPPED_ROOK_PENALTY_MG;
                }
            }
        },
        Color::Black => {
            if my_king.rank() >= 6 && (my_king.file() == 5 || my_king.file() == 6) { // f8, g8
                if (my_rooks & (1u64 << 63)) != 0 && board.piece_on(Square(62)).is_some() {
                    state.mg[ci] += TRAPPED_ROOK_PENALTY_MG;
                }
            }
        }
    }
}

fn evaluate_blockers(board: &Board, state: &mut EvalState, color: Color, opp: Color, ci: usize) {
    let opp_pawns = board.pieces_of(opp, PieceType::Pawn);
    
    // Simplistic passed pawn blocker check
    for sq in iter(opp_pawns) {
        let block_sq_idx = match opp {
            Color::White => sq.index() as i32 + 8,
            Color::Black => sq.index() as i32 - 8,
        };
        
        if block_sq_idx >= 0 && block_sq_idx < 64 {
            let block_sq = Square(block_sq_idx as u8);
            if let Some(p) = board.piece_on(block_sq) {
                if p.color == color {
                    if p.kind == PieceType::Knight {
                        state.mg[ci] += BLOCKER_BONUS_KNIGHT;
                        state.eg[ci] += BLOCKER_BONUS_KNIGHT;
                    } else if p.kind == PieceType::Bishop {
                        state.mg[ci] += BLOCKER_BONUS_BISHOP;
                        state.eg[ci] += BLOCKER_BONUS_BISHOP;
                    }
                }
            }
        }
    }
}

fn evaluate_greek_gift(board: &Board, state: &mut EvalState, color: Color, opp: Color, ci: usize) {
    // Basic structural check for Greek Gift sacrifice (Bxh7)
    let (target_pawn, target_sq, knight_sq, _queen_sq) = match color {
        Color::White => (55, 55, 21, 27), // h7, h7, f3, d1/h5
        Color::Black => (7, 7, 45, 35),   // h2, h2, f6, d8/h4
    };
    
    let opp_king = board.king_square(opp);
    
    let is_kingside_castled = match opp {
        Color::White => opp_king.index() == 6 || opp_king.index() == 7,
        Color::Black => opp_king.index() == 62 || opp_king.index() == 63,
    };
    
    if is_kingside_castled {
        let my_bishops = board.pieces_of(color, PieceType::Bishop);
        let opp_pawns = board.pieces_of(opp, PieceType::Pawn);
        let my_knights = board.pieces_of(color, PieceType::Knight);
        
        // If opponent has h7 pawn and no knight on f6 (for black defensive knight)
        let def_knight_sq = match opp {
            Color::White => 21, // f3
            Color::Black => 45, // f6
        };
        
        if (opp_pawns & (1u64 << target_pawn)) != 0 && (board.pieces_of(opp, PieceType::Knight) & (1u64 << def_knight_sq)) == 0 {
            // If we have a bishop aiming at h7
            let target_bb = 1u64 << target_sq;
            let mut can_sac = false;
            
            for sq in iter(my_bishops) {
                let att = crate::attacks::bishop_attacks(sq, board.occupancy);
                if (att & target_bb) != 0 {
                    can_sac = true;
                    break;
                }
            }
            
            if can_sac && (my_knights & (1u64 << knight_sq)) != 0 {
                state.mg[ci] += GREEK_GIFT_THREAT_BONUS_MG;
            }
        }
    }
}

// ------------------------------------------------------------------------------------------------
// EXTENSIVE PATTERNS DUMMY ANALYSIS LOGIC
// ------------------------------------------------------------------------------------------------

fn evaluate_trapped_bishop(board: &Board, state: &mut EvalState, color: Color, ci: usize) {
    let my_bishops = board.pieces_of(color, PieceType::Bishop);
    let opp_pawns = board.pieces_of(color.opponent(), PieceType::Pawn);
    
    // Squares where bishops get trapped by enemy pawns
    // White: bishop on a7(48) trapped by pawn on b6(41), bishop on h7(55) trapped by pawn on g6(46)
    // Black: bishop on a2(8) trapped by pawn on b3(17), bishop on h2(15) trapped by pawn on g3(22)
    let (trap_squares, minor_trap_squares) = match color {
        Color::White => (
            [(48u8, 41u8), (55u8, 46u8)],  // a7/b6, h7/g6
            [(40u8, 33u8), (47u8, 38u8)],  // a6/b5, h6/g5
        ),
        Color::Black => (
            [(8u8, 17u8), (15u8, 22u8)],   // a2/b3, h2/g3
            [(16u8, 25u8), (23u8, 30u8)],  // a3/b4, h3/g4
        ),
    };
    
    for &(bishop_sq, pawn_sq) in &trap_squares {
        if (my_bishops & (1u64 << bishop_sq)) != 0 && (opp_pawns & (1u64 << pawn_sq)) != 0 {
            state.mg[ci] += TRAPPED_BISHOP_PENALTY_MG;
            state.eg[ci] += TRAPPED_BISHOP_PENALTY_EG;
        }
    }
    
    for &(bishop_sq, pawn_sq) in &minor_trap_squares {
        if (my_bishops & (1u64 << bishop_sq)) != 0 && (opp_pawns & (1u64 << pawn_sq)) != 0 {
            state.mg[ci] += TRAPPED_BISHOP_MINOR_PENALTY_MG;
            state.eg[ci] += TRAPPED_BISHOP_MINOR_PENALTY_EG;
        }
    }
}

#[allow(dead_code)]
fn evaluate_knight_outpost_patterns(board: &Board, color: Color) -> i32 {
    let mut score = 0;
    let my_knights = board.pieces_of(color, PieceType::Knight);
    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    let _opp_pawns = board.pieces_of(color.opponent(), PieceType::Pawn);
    
    // Knights supported by two pawns
    for sq in iter(my_knights) {
        let defended = super::advanced_pawns::pawn_attacks_span(color.opponent(), my_pawns); // conceptually
        if (defended & (1u64 << sq.index())).count_ones() == 2 {
            score += 25; // Super strong outpost
        }
    }
    score
}

#[allow(dead_code)]
fn evaluate_rook_on_open_file_patterns(board: &Board, color: Color) -> i32 {
    let mut score = 0;
    let my_rooks = board.pieces_of(color, PieceType::Rook);
    
    for sq in iter(my_rooks) {
        let f = sq.file();
        let file_mask = 0x0101010101010101u64 << f;
        let pawns = board.pieces_of(Color::White, PieceType::Pawn) | board.pieces_of(Color::Black, PieceType::Pawn);
        if (pawns & file_mask) == 0 {
            // It's an open file. Check if we have two rooks doubled on it.
            let rooks_on_file = (my_rooks & file_mask).count_ones();
            if rooks_on_file == 2 {
                score += 35; // Doubled rooks on open file
            }
        }
    }
    score
}
// END OF patterns.rs
