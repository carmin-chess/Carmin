use crate::board::Board;
use crate::types::{Color, Square, PieceType};
use crate::bitboard::iter;
use super::EvalState;

// ================================================================================================
// CONSTANTS FOR ENDGAME FORTRESSES
// ================================================================================================

// Scaling down the evaluation to 0.00 when a fortress is detected.
// A scale of 0 means 0% (absolute draw), 50 means 50% (half the original advantage), etc.
const FORTRESS_SCALE_DRAW: i32 = 0;
const FORTRESS_SCALE_OPPOSITE_BISHOPS: i32 = 40;
const FORTRESS_SCALE_WRONG_COLOR_BISHOP: i32 = 0;

// ================================================================================================
// CORE STRUCTS
// ================================================================================================

pub struct FortressInfo {
    pub scale_factor: i32, // Multiplier out of 100
}

// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_endgame_fortress(
    board: &Board,
    _state: &mut EvalState,
) -> FortressInfo {
    let mut info = FortressInfo {
        scale_factor: 100, // 100% means no fortress
    };

    // Fast check for late endgame (few pieces)
    let non_pawns = (board.occupancy ^ board.pieces_of(Color::White, PieceType::Pawn) ^ board.pieces_of(Color::Black, PieceType::Pawn)).count_ones();
    
    if non_pawns > 8 {
        return info; // Too early for fortress rules
    }

    // 1. Opposite Colored Bishops Endgame (OCB)
    if is_opposite_colored_bishops(board) {
        // If it's pure OCB + pawns
        if non_pawns == 4 { // Kings + 2 Bishops
            info.scale_factor = info.scale_factor.min(FORTRESS_SCALE_OPPOSITE_BISHOPS);
            
            // Further analysis: if the winning side has passed pawns that can be blockaded
            // we could scale it down to 0.
        } else if non_pawns == 6 {
            // OCB + 1 pair of Rooks
            info.scale_factor = info.scale_factor.min(65);
        }
    }

    // 2. Wrong Colored Bishop + Rook Pawn
    if check_wrong_colored_bishop(board, Color::White) || check_wrong_colored_bishop(board, Color::Black) {
        info.scale_factor = info.scale_factor.min(FORTRESS_SCALE_WRONG_COLOR_BISHOP);
    }

    // 3. KR vs KN, KR vs KB, etc (if pawns are zero)
    let w_pawns = board.pieces_of(Color::White, PieceType::Pawn);
    let b_pawns = board.pieces_of(Color::Black, PieceType::Pawn);
    
    if w_pawns == 0 && b_pawns == 0 {
        if is_minor_piece_draw(board) {
            info.scale_factor = FORTRESS_SCALE_DRAW;
        }
    }

    info
}

// ================================================================================================
// HELPER FUNCTIONS
// ================================================================================================

fn is_opposite_colored_bishops(board: &Board) -> bool {
    let w_bishops = board.pieces_of(Color::White, PieceType::Bishop);
    let b_bishops = board.pieces_of(Color::Black, PieceType::Bishop);
    
    if w_bishops.count_ones() == 1 && b_bishops.count_ones() == 1 {
        let w_sq = w_bishops.trailing_zeros();
        let b_sq = b_bishops.trailing_zeros();
        
        let w_color = (w_sq / 8 + w_sq % 8) % 2;
        let b_color = (b_sq / 8 + b_sq % 8) % 2;
        
        return w_color != b_color;
    }
    false
}

fn check_wrong_colored_bishop(board: &Board, winning_color: Color) -> bool {
    let losing_color = winning_color.opponent();
    
    let my_pawns = board.pieces_of(winning_color, PieceType::Pawn);
    let my_bishops = board.pieces_of(winning_color, PieceType::Bishop);
    
    let opp_pieces = board.color_bb[losing_color.index()];
    let opp_king = board.king_square(losing_color);
    
    // We only have 1 bishop and pawns, they only have king
    if my_bishops.count_ones() == 1 && my_pawns.count_ones() == 1 && opp_pieces.count_ones() == 1 {
        let pawn_sq = Square(my_pawns.trailing_zeros() as u8);
        let pawn_file = pawn_sq.file();
        
        // Rook pawn (a or h file)
        if pawn_file == 0 || pawn_file == 7 {
            let prom_sq = match winning_color {
                Color::White => Square((7 * 8) + pawn_file),
                Color::Black => Square(pawn_file),
            };
            
            let bishop_sq = my_bishops.trailing_zeros();
            let bishop_color = (bishop_sq / 8 + bishop_sq % 8) % 2;
            let prom_color = (prom_sq.index() as u32 / 8 + prom_sq.index() as u32 % 8) % 2;
            
            // Bishop cannot control the promotion square
            if bishop_color != prom_color {
                // If enemy king is close enough to promotion square to block it
                let k_dist = distance(opp_king, prom_sq);
                if k_dist <= 2 {
                    return true; // Draw!
                }
            }
        }
    }
    false
}

fn is_minor_piece_draw(board: &Board) -> bool {
    // Only works if there are no pawns
    let w_minors = board.pieces_of(Color::White, PieceType::Knight) | board.pieces_of(Color::White, PieceType::Bishop);
    let b_minors = board.pieces_of(Color::Black, PieceType::Knight) | board.pieces_of(Color::Black, PieceType::Bishop);
    
    let w_majors = board.pieces_of(Color::White, PieceType::Rook) | board.pieces_of(Color::White, PieceType::Queen);
    let b_majors = board.pieces_of(Color::Black, PieceType::Rook) | board.pieces_of(Color::Black, PieceType::Queen);
    
    if w_majors == 0 && b_majors == 0 {
        let w_count = w_minors.count_ones();
        let b_count = b_minors.count_ones();
        
        // K v K, KN v K, KB v K, KNN v K
        if w_count <= 2 && b_count <= 2 {
            // Check for KNN v K which is theoretically a draw (unless forced mate exists)
            // But usually engines just score it 0
            if (w_count == 2 && board.pieces_of(Color::White, PieceType::Knight).count_ones() == 2 && b_count == 0) ||
               (b_count == 2 && board.pieces_of(Color::Black, PieceType::Knight).count_ones() == 2 && w_count == 0) {
                return true;
            }
            
            // KN v K, KB v K
            if w_count <= 1 && b_count <= 1 {
                return true;
            }
        }
    }
    false
}

fn distance(sq1: Square, sq2: Square) -> i32 {
    let f1 = sq1.file() as i32;
    let r1 = sq1.rank() as i32;
    let f2 = sq2.file() as i32;
    let r2 = sq2.rank() as i32;
    (f1 - f2).abs().max((r1 - r2).abs())
}

// ------------------------------------------------------------------------------------------------
// EXTENSIVE FORTRESS DUMMY ANALYSIS LOGIC
// ------------------------------------------------------------------------------------------------

#[allow(dead_code)]
fn evaluate_blocked_pawn_chains(board: &Board) -> i32 {
    // Evaluates if the position is entirely locked by pawn chains
    let w_pawns = board.pieces_of(Color::White, PieceType::Pawn);
    let b_pawns = board.pieces_of(Color::Black, PieceType::Pawn);
    
    let mut blocked_count = 0;
    for sq in iter(w_pawns) {
        let push_sq = sq.index() + 8;
        if push_sq < 64 && (b_pawns & (1u64 << push_sq)) != 0 {
            blocked_count += 1;
        }
    }
    
    if blocked_count >= 6 {
        // High likelihood of a locked position
        return 30; // Return a scale factor indicating a high drawing tendency
    }
    100
}

#[allow(dead_code)]
fn evaluate_fortress_with_rook_pawn(board: &Board, color: Color) -> bool {
    // Advanced check for K+R vs K+R where one side has a rook pawn and is trying to win
    let opp = color.opponent();
    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    if my_pawns.count_ones() != 1 { return false; }
    
    let sq = Square(my_pawns.trailing_zeros() as u8);
    if sq.file() == 0 || sq.file() == 7 {
        let opp_king = board.king_square(opp);
        let _my_king = board.king_square(color);
        
        // Vancura position or Philidor position detection
        // If enemy king is in front of the pawn, it's a draw
        let k_f = opp_king.file();
        let k_r = opp_king.rank();
        
        let p_f = sq.file();
        let p_r = sq.rank();
        
        if k_f == p_f {
            let in_front = match color {
                Color::White => k_r > p_r,
                Color::Black => k_r < p_r,
            };
            if in_front { return true; }
        }
    }
    false
}
// END OF endgame_fortress.rs
