use crate::board::Board;
use crate::personality;
use crate::types::{Color, PieceType};
use crate::bitboard::iter;
use super::EvalState;

// ================================================================================================
// CONSTANTS FOR MOBILITY
// ================================================================================================

// Bonus tables for safe mobility
// Values scaled to centipawns

const KNIGHT_MOBILITY_MG: [i32; 9] = [-10, -3, 0, 3, 7, 10, 14, 18, 22];
const KNIGHT_MOBILITY_EG: [i32; 9] = [-14, -7, -3, 0, 3, 7, 10, 14, 18];

const BISHOP_MOBILITY_MG: [i32; 14] = [-18, -7, -3, 0, 3, 7, 11, 15, 18, 22, 25, 28, 30, 32];
const BISHOP_MOBILITY_EG: [i32; 14] = [-22, -10, -5, -2, 0, 3, 7, 11, 15, 18, 22, 25, 28, 30];

const ROOK_MOBILITY_MG: [i32; 15] = [-12, -7, -3, 0, 1, 3, 4, 6, 7, 9, 10, 12, 13, 14, 15];
const ROOK_MOBILITY_EG: [i32; 15] = [-18, -10, -5, -2, 0, 3, 7, 10, 14, 18, 22, 25, 28, 30, 32];

const QUEEN_MOBILITY_MG: [i32; 28] = [
    -15, -10, -7, -3, -1, 0, 1, 3, 4, 6, 7, 9, 10, 11, 12, 14, 15, 16, 17, 18, 20, 21, 22, 23, 24, 25, 26, 27
];
const QUEEN_MOBILITY_EG: [i32; 28] = [
    -22, -15, -10, -5, -2, 0, 3, 7, 10, 14, 18, 22, 25, 28, 32, 35, 38, 42, 45, 48, 52, 55, 58, 62, 65, 68, 72, 75
];

// ================================================================================================
// CORE STRUCTS
// ================================================================================================

pub struct MobilityInfo {
    pub safe_mobility_knight: i32,
    pub safe_mobility_bishop: i32,
    pub safe_mobility_rook: i32,
    pub safe_mobility_queen: i32,
}

// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_mobility(
    board: &Board,
    state: &mut EvalState,
    color: Color,
) -> MobilityInfo {
    let ci = color.index();
    let _opp = color.opponent();
    
    let mut info = MobilityInfo {
        safe_mobility_knight: 0,
        safe_mobility_bishop: 0,
        safe_mobility_rook: 0,
        safe_mobility_queen: 0,
    };

    let safe_squares = state.mob_area[ci];
    let pinned = state.pinned[ci];

    // Knights
    for sq in iter(board.pieces_of(color, PieceType::Knight)) {
        if (1u64 << sq.index()) & pinned != 0 { continue; } // Pinned knights have 0 mobility
        let attacks = crate::attacks::knight_attacks(sq);
        let safe_attacks = attacks & safe_squares;
        let mob = safe_attacks.count_ones() as usize;
        
        info.safe_mobility_knight += mob as i32;
        
        let idx = mob.min(KNIGHT_MOBILITY_MG.len() - 1);
        let cfg = personality::config();
        state.mg[ci] += cfg.scale(KNIGHT_MOBILITY_MG[idx], cfg.mobility);
        state.eg[ci] += cfg.scale(KNIGHT_MOBILITY_EG[idx], cfg.mobility);
    }

    // Bishops
    for sq in iter(board.pieces_of(color, PieceType::Bishop)) {
        let is_pinned = (1u64 << sq.index()) & pinned != 0;
        let mut attacks = crate::attacks::bishop_attacks(sq, board.occupancy);
        if is_pinned {
            // Partial mobility along pin ray
            let ksq = board.king_square(color);
            attacks &= crate::attacks::line_through(sq, ksq);
        }
        let safe_attacks = attacks & safe_squares;
        let mob = safe_attacks.count_ones() as usize;
        
        info.safe_mobility_bishop += mob as i32;
        
        let idx = mob.min(BISHOP_MOBILITY_MG.len() - 1);
        let cfg = personality::config();
        state.mg[ci] += cfg.scale(BISHOP_MOBILITY_MG[idx], cfg.mobility);
        state.eg[ci] += cfg.scale(BISHOP_MOBILITY_EG[idx], cfg.mobility);
    }

    // Rooks
    let xray_occ = board.occupancy ^ (board.pieces_of(color, PieceType::Rook) | board.pieces_of(color, PieceType::Queen));
    for sq in iter(board.pieces_of(color, PieceType::Rook)) {
        let is_pinned = (1u64 << sq.index()) & pinned != 0;
        let mut attacks = crate::attacks::rook_attacks(sq, xray_occ); // X-ray through own major pieces
        if is_pinned {
            let ksq = board.king_square(color);
            attacks &= crate::attacks::line_through(sq, ksq);
        }
        let safe_attacks = attacks & safe_squares;
        let mob = safe_attacks.count_ones() as usize;
        
        info.safe_mobility_rook += mob as i32;
        
        let idx = mob.min(ROOK_MOBILITY_MG.len() - 1);
        let cfg = personality::config();
        state.mg[ci] += cfg.scale(ROOK_MOBILITY_MG[idx], cfg.mobility);
        state.eg[ci] += cfg.scale(ROOK_MOBILITY_EG[idx], cfg.mobility);
        
        // Vertical mobility bonus
        let file_mask = 0x0101010101010101u64 << sq.file();
        let vertical_mob = (safe_attacks & file_mask).count_ones() as i32;
        state.mg[ci] += cfg.scale(vertical_mob * 2, cfg.mobility);
    }

    // Queens
    for sq in iter(board.pieces_of(color, PieceType::Queen)) {
        let is_pinned = (1u64 << sq.index()) & pinned != 0;
        let mut attacks = crate::attacks::queen_attacks(sq, board.occupancy);
        if is_pinned {
            let ksq = board.king_square(color);
            attacks &= crate::attacks::line_through(sq, ksq);
        }
        let safe_attacks = attacks & safe_squares;
        let mob = safe_attacks.count_ones() as usize;
        
        info.safe_mobility_queen += mob as i32;
        
        let idx = mob.min(QUEEN_MOBILITY_MG.len() - 1);
        let cfg = personality::config();
        state.mg[ci] += cfg.scale(QUEEN_MOBILITY_MG[idx], cfg.mobility);
        state.eg[ci] += cfg.scale(QUEEN_MOBILITY_EG[idx], cfg.mobility);
    }

    info
}

// ------------------------------------------------------------------------------------------------
// EXTENSIVE MOBILITY DUMMY ANALYSIS LOGIC
// ------------------------------------------------------------------------------------------------

#[allow(dead_code)]
fn evaluate_virtual_mobility(board: &Board, color: Color) -> i32 {
    let mut score = 0;
    let occ = board.occupancy & !board.color_bb[color.index()]; // Pretend our own pieces aren't blocking
    
    // Virtual mobility is useful for assessing cramped positions
    for sq in iter(board.pieces_of(color, PieceType::Bishop)) {
        let virt_att = crate::attacks::bishop_attacks(sq, occ);
        score += virt_att.count_ones() as i32 * 2;
    }
    
    for sq in iter(board.pieces_of(color, PieceType::Rook)) {
        let virt_att = crate::attacks::rook_attacks(sq, occ);
        score += virt_att.count_ones() as i32;
    }
    
    score
}

#[allow(dead_code)]
fn evaluate_center_mobility(board: &Board, color: Color) -> i32 {
    let center_mask = 0x0000001818000000u64;
    let ext_center_mask = 0x00003C3C3C3C0000u64;
    let mut score = 0;
    
    for sq in iter(board.pieces_of(color, PieceType::Knight)) {
        let att = crate::attacks::knight_attacks(sq);
        score += (att & center_mask).count_ones() as i32 * 5;
        score += (att & ext_center_mask).count_ones() as i32 * 2;
    }
    
    score
}

// END OF mobility.rs
