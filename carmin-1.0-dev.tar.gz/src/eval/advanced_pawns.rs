use crate::board::Board;
use crate::types::{Color, Square, PieceType};
use crate::bitboard::{iter, Bitboard};
use super::EvalState;

// ================================================================================================
// CONSTANTS AND WEIGHTS FOR ADVANCED PAWN STRUCTURE
// ================================================================================================

const PAWN_ISLAND_PENALTY_MG: i32 = -5;
const PAWN_ISLAND_PENALTY_EG: i32 = -15;

const DOUBLED_PAWN_PENALTY_MG: i32 = -11;
const DOUBLED_PAWN_PENALTY_EG: i32 = -25;

const ISOLATED_PAWN_PENALTY_MG: [i32; 8] = [0, -10, -15, -20, -20, -15, -10, 0];
const ISOLATED_PAWN_PENALTY_EG: [i32; 8] = [0, -15, -20, -25, -25, -20, -15, 0];

const BACKWARD_PAWN_PENALTY_MG: [i32; 8] = [0, -8, -12, -18, -18, -12, -8, 0];
const BACKWARD_PAWN_PENALTY_EG: [i32; 8] = [0, -12, -18, -24, -24, -18, -12, 0];

const HOLE_PENALTY_MG: i32 = -10;
const HOLE_PENALTY_EG: i32 = -5;

const PHALANX_BONUS_MG: [i32; 8] = [0, 5, 10, 15, 20, 15, 10, 0];
const PHALANX_BONUS_EG: [i32; 8] = [0, 8, 12, 20, 25, 20, 12, 0];

// Extensive table for pawn structure evaluation based on connected pawns
// Values scaled to centipawns
const CONNECTED_BONUS_MG: [[i32; 8]; 8] = [
    [0, 0, 0, 0, 0, 0, 0, 0],
    [0, 2, 4, 6, 8, 6, 4, 2],
    [0, 3, 6, 9, 12, 9, 6, 3],
    [0, 4, 8, 12, 16, 12, 8, 4],
    [0, 5, 10, 15, 20, 15, 10, 5],
    [0, 6, 12, 18, 24, 18, 12, 6],
    [0, 7, 14, 21, 28, 21, 14, 7],
    [0, 0, 0, 0, 0, 0, 0, 0],
];

const CONNECTED_BONUS_EG: [[i32; 8]; 8] = [
    [0, 0, 0, 0, 0, 0, 0, 0],
    [0, 4, 8, 12, 16, 12, 8, 4],
    [0, 6, 12, 18, 24, 18, 12, 6],
    [0, 8, 16, 24, 32, 24, 16, 8],
    [0, 10, 20, 30, 40, 30, 20, 10],
    [0, 12, 24, 36, 48, 36, 24, 12],
    [0, 14, 28, 42, 56, 42, 28, 14],
    [0, 0, 0, 0, 0, 0, 0, 0],
];

// ================================================================================================
// CORE STRUCTS
// ================================================================================================

pub struct AdvancedPawnInfo {
    pub islands: i32,
    pub isolated: Bitboard,
    pub backward: Bitboard,
    pub doubled: Bitboard,
    pub phalanx: Bitboard,
    pub holes: Bitboard,
    pub connected: Bitboard,
    pub candidate_passers: Bitboard,
}

// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_advanced_pawns(
    board: &Board,
    state: &mut EvalState,
    color: Color,
) -> AdvancedPawnInfo {
    let ci = color.index();
    let opp = color.opponent();
    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    let opp_pawns = board.pieces_of(opp, PieceType::Pawn);

    let mut info = AdvancedPawnInfo {
        islands: 0,
        isolated: 0,
        backward: 0,
        doubled: 0,
        phalanx: 0,
        holes: 0,
        connected: 0,
        candidate_passers: 0,
    };

    if my_pawns == 0 {
        return info;
    }

    // 1. Pawn Islands
    info.islands = count_pawn_islands(my_pawns);
    state.mg[ci] += info.islands * PAWN_ISLAND_PENALTY_MG;
    state.eg[ci] += info.islands * PAWN_ISLAND_PENALTY_EG;

    // 2. Iterate through all pawns for detailed structure
    for sq in iter(my_pawns) {
        let r = sq.rank() as usize;
        let f = sq.file() as usize;

        // Doubled pawns
        let file_mask = 0x0101010101010101u64 << f;
        let pawns_on_file = my_pawns & file_mask;
        if pawns_on_file.count_ones() > 1 {
            info.doubled |= 1u64 << sq.index();
            let in_front = match color {
                Color::White => (file_mask << 8) & !((1u64 << (sq.index() + 1)) - 1),
                Color::Black => (file_mask >> 8) & ((1u64 << sq.index()) - 1),
            };
            if (my_pawns & in_front) != 0 {
                state.mg[ci] += DOUBLED_PAWN_PENALTY_MG;
                state.eg[ci] += DOUBLED_PAWN_PENALTY_EG;
            }
        }

        // Isolated pawns
        let adj_files_mask = adjacent_files(f);
        if (my_pawns & adj_files_mask) == 0 {
            info.isolated |= 1u64 << sq.index();
            state.mg[ci] += ISOLATED_PAWN_PENALTY_MG[f];
            state.eg[ci] += ISOLATED_PAWN_PENALTY_EG[f];
        }

        // Backward pawns
        if is_backward_pawn(sq, color, my_pawns, opp_pawns) {
            info.backward |= 1u64 << sq.index();
            state.mg[ci] += BACKWARD_PAWN_PENALTY_MG[f];
            state.eg[ci] += BACKWARD_PAWN_PENALTY_EG[f];
        }

        // Phalanx (pawns side-by-side)
        if f < 7 {
            let neighbor_sq = match color {
                Color::White => sq.index() + 1,
                Color::Black => sq.index() + 1,
            };
            if (my_pawns & (1u64 << neighbor_sq)) != 0 {
                info.phalanx |= 1u64 << sq.index();
                info.phalanx |= 1u64 << neighbor_sq;
                state.mg[ci] += PHALANX_BONUS_MG[f];
                state.eg[ci] += PHALANX_BONUS_EG[f];
            }
        }

        // Connected Pawns
        let defended_by = pawn_attacks_span(color.opponent(), sq.bb()) & my_pawns;
        if defended_by != 0 {
            info.connected |= 1u64 << sq.index();
            state.mg[ci] += CONNECTED_BONUS_MG[r][f];
            state.eg[ci] += CONNECTED_BONUS_EG[r][f];
        }

        // Holes
        let in_front_sq = match color {
            Color::White => sq.index() as i32 + 8,
            Color::Black => sq.index() as i32 - 8,
        };
        if in_front_sq >= 0 && in_front_sq < 64 {
            let hole_sq = Square(in_front_sq as u8);
            if !can_be_defended_by_pawn(hole_sq, color, my_pawns) {
                info.holes |= 1u64 << hole_sq.index();
                state.mg[ci] += HOLE_PENALTY_MG;
                state.eg[ci] += HOLE_PENALTY_EG;
            }
        }

        // Candidate Passers
        if is_candidate_passer(sq, color, my_pawns, opp_pawns) {
            info.candidate_passers |= 1u64 << sq.index();
        }
    }

    info
}

// ================================================================================================
// HELPER FUNCTIONS
// ================================================================================================

fn adjacent_files(file: usize) -> Bitboard {
    let mut mask = 0;
    if file > 0 { mask |= 0x0101010101010101u64 << (file - 1); }
    if file < 7 { mask |= 0x0101010101010101u64 << (file + 1); }
    mask
}

pub fn pawn_attacks_span(color: Color, pawns: Bitboard) -> Bitboard {
    let not_a = 0xfefefefefefefefe;
    let not_h = 0x7f7f7f7f7f7f7f7f;
    match color {
        Color::White => ((pawns & not_a) << 7) | ((pawns & not_h) << 9),
        Color::Black => ((pawns & not_h) >> 7) | ((pawns & not_a) >> 9),
    }
}

fn is_backward_pawn(sq: Square, color: Color, my_pawns: Bitboard, opp_pawns: Bitboard) -> bool {
    let f = sq.file() as usize;
    let r = sq.rank() as usize;
    let adj = adjacent_files(f);
    let behind_mask = match color {
        Color::White => !((1u64 << (r * 8)) - 1),
        Color::Black => (1u64 << ((r + 1) * 8)) - 1,
    };
    if (my_pawns & adj & behind_mask) != 0 { return false; }
    let stop_sq = match color {
        Color::White => sq.index() as i32 + 8,
        Color::Black => sq.index() as i32 - 8,
    };
    if stop_sq >= 0 && stop_sq < 64 {
        let stop_bb = 1u64 << stop_sq;
        let enemy_attacks = pawn_attacks_span(color.opponent(), opp_pawns);
        if (enemy_attacks & stop_bb) != 0 { return true; }
    }
    false
}

fn count_pawn_islands(pawns: Bitboard) -> i32 {
    let mut islands = 0;
    let mut in_island = false;
    for f in 0..8 {
        let file_mask = 0x0101010101010101u64 << f;
        if (pawns & file_mask) != 0 {
            if !in_island { islands += 1; in_island = true; }
        } else {
            in_island = false;
        }
    }
    islands
}

fn can_be_defended_by_pawn(sq: Square, color: Color, my_pawns: Bitboard) -> bool {
    let f = sq.file() as usize;
    let r = sq.rank() as usize;
    let adj = adjacent_files(f);
    let behind_mask = match color {
        Color::White => (1u64 << (r * 8)) - 1,
        Color::Black => !((1u64 << ((r + 1) * 8)) - 1),
    };
    (my_pawns & adj & behind_mask) != 0
}

fn is_candidate_passer(sq: Square, color: Color, my_pawns: Bitboard, opp_pawns: Bitboard) -> bool {
    let f = sq.file() as usize;
    let r = sq.rank() as usize;
    let front_span = match color {
        Color::White => !((1u64 << ((r + 1) * 8)) - 1),
        Color::Black => (1u64 << (r * 8)) - 1,
    };
    let file_mask = 0x0101010101010101u64 << f;
    let adj_mask = adjacent_files(f);
    let enemy_blockers = opp_pawns & front_span & (file_mask | adj_mask);
    if enemy_blockers == 0 { return true; }
    let my_supporters = my_pawns & front_span & adj_mask;
    let enemy_front = opp_pawns & front_span & file_mask;
    if enemy_front == 0 {
        let my_support_count = my_supporters.count_ones();
        let enemy_adj_count = (enemy_blockers & adj_mask).count_ones();
        if my_support_count >= enemy_adj_count { return true; }
    }
    false
}

#[allow(dead_code)]
fn analyze_pawn_chain(pawns: Bitboard, color: Color) -> i32 {
    let mut score = 0;
    for sq in iter(pawns) {
        let defended = pawn_attacks_span(color.opponent(), pawns) & (1u64 << sq.index());
        if defended != 0 {
            let r = sq.rank() as usize;
            score += r as i32 * 2;
        }
    }
    score
}

#[allow(dead_code)]
fn evaluate_center_pawn_control(pawns: Bitboard) -> i32 {
    let e4 = 1u64 << 28; let d4 = 1u64 << 27; let e5 = 1u64 << 36; let d5 = 1u64 << 35;
    let mut control = 0;
    if (pawns & e4) != 0 { control += 10; }
    if (pawns & d4) != 0 { control += 10; }
    if (pawns & e5) != 0 { control += 10; }
    if (pawns & d5) != 0 { control += 10; }
    control
}

#[allow(dead_code)]
fn find_pawn_storms(my_pawns: Bitboard, enemy_king_sq: Square, color: Color) -> i32 {
    let k_file = enemy_king_sq.file() as usize;
    let mut storm_score = 0;
    for f in k_file.saturating_sub(1)..=k_file.saturating_add(1) {
        if f > 7 { continue; }
        let file_mask = 0x0101010101010101u64 << f;
        let my_pawns_on_file = my_pawns & file_mask;
        if my_pawns_on_file != 0 {
            let most_advanced = match color {
                Color::White => 63 - my_pawns_on_file.leading_zeros(),
                Color::Black => my_pawns_on_file.trailing_zeros(),
            };
            let rank = most_advanced / 8;
            let dist_to_king = (enemy_king_sq.rank() as i32 - rank as i32).abs();
            if dist_to_king <= 3 { storm_score += 15 - dist_to_king * 3; }
        }
    }
    storm_score
}
// End of advanced_pawns.rs
