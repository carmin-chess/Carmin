use crate::board::Board;
use crate::personality;
use crate::types::{Color, PieceType};
use crate::bitboard::Bitboard;
use super::EvalState;

// ================================================================================================
// CONSTANTS FOR SPACE CONTROL
// ================================================================================================

// Weight of squares based on their importance (center is most important)
const CENTER_SQUARES: Bitboard = 0x0000001818000000u64; // e4, d4, e5, d5
const EXTENDED_CENTER: Bitboard = 0x00003C3C3C3C0000u64;

const CENTER_CONTROL_BONUS_MG: i32 = 5; // per attack in center
const CENTER_CONTROL_BONUS_EG: i32 = 2;

const SPACE_BEHIND_PAWNS_BONUS: i32 = 3;

// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_space_control(
    board: &Board,
    state: &mut EvalState,
    color: Color,
) {
    let ci = color.index();
    
    // 1. Center Control
    let mut center_attacks = 0;
    
    // Simplified count of attacks into the center
    // We already have attacks_by from state, but for specific center we can do an intersection
    for pt in 0..5 { // Pawn to Queen
        let attacks = state.attacks_by[ci][pt];
        center_attacks += (attacks & CENTER_SQUARES).count_ones();
        center_attacks += (attacks & EXTENDED_CENTER).count_ones() / 2; // extended center is worth half
    }
    
    let cfg = personality::config();
    state.mg[ci] += cfg.scale(center_attacks as i32 * CENTER_CONTROL_BONUS_MG, cfg.space);
    state.eg[ci] += cfg.scale(center_attacks as i32 * CENTER_CONTROL_BONUS_EG, cfg.space);
    
    // 2. Space Behind Pawns
    // Calculates how much safe space the pieces have behind their own pawn chain
    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    let mut space = 0;
    
    // For every file, find the most advanced pawn, and count squares behind it up to the 2nd/7th rank
    for f in 2..6 { // Only care about central 4 files for space (c, d, e, f)
        let file_mask = 0x0101010101010101u64 << f;
        let pawns_on_file = my_pawns & file_mask;
        
        if pawns_on_file != 0 {
            let most_advanced = match color {
                Color::White => 63 - pawns_on_file.leading_zeros(),
                Color::Black => pawns_on_file.trailing_zeros(),
            };
            
            let rank = most_advanced / 8;
            
            // Count safe squares behind the pawn
            match color {
                Color::White => {
                    if rank > 2 { space += rank - 2; }
                },
                Color::Black => {
                    let r = 7 - rank;
                    if r > 2 { space += r - 2; }
                }
            }
        }
    }
    
    state.mg[ci] += cfg.scale((space as i32) * SPACE_BEHIND_PAWNS_BONUS, cfg.space);
}

// ------------------------------------------------------------------------------------------------
// EXTENSIVE SPACE DUMMY ANALYSIS LOGIC
// ------------------------------------------------------------------------------------------------

#[allow(dead_code)]
fn evaluate_space_weight_by_piece_count(board: &Board, _color: Color, raw_space: i32) -> i32 {
    // Space is more valuable when there are more pieces on the board (cramped positions)
    let non_pawns = (board.occupancy ^ board.pieces_of(Color::White, PieceType::Pawn) ^ board.pieces_of(Color::Black, PieceType::Pawn)).count_ones() as i32;
    
    // Max non_pawns is 16. If we have 16, space weight is 100%. If 4, space weight is 0%.
    let weight = (non_pawns - 4).max(0) * 8; // 12 * 8 = 96%
    
    (raw_space * weight) / 100
}

#[allow(dead_code)]
fn evaluate_central_pawn_wedge(board: &Board, color: Color) -> i32 {
    // Detects a strong pawn wedge in the center (e.g. e5 pawn supported by d4 and f4)
    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    let mut score = 0;
    
    match color {
        Color::White => {
            if (my_pawns & (1u64 << 36)) != 0 { // e5
                if (my_pawns & (1u64 << 27)) != 0 && (my_pawns & (1u64 << 29)) != 0 { // d4, f4
                    score += 40; // Massive space advantage
                }
            }
            if (my_pawns & (1u64 << 35)) != 0 { // d5
                if (my_pawns & (1u64 << 26)) != 0 && (my_pawns & (1u64 << 28)) != 0 { // c4, e4
                    score += 40;
                }
            }
        },
        Color::Black => {
            if (my_pawns & (1u64 << 28)) != 0 { // e4
                if (my_pawns & (1u64 << 35)) != 0 && (my_pawns & (1u64 << 37)) != 0 { // d5, f5
                    score += 40;
                }
            }
        }
    }
    
    score
}
// END OF space_control.rs
