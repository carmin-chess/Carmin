use crate::attacks;
use crate::bitboard::iter;
use crate::board::Board;
use crate::personality;
use crate::types::{Color, PieceType};
use super::params::*;
use super::EvalState;

pub fn get_king_ring(board: &Board, color: Color) -> u64 {
    let k_sq = board.king_square(color);
    let mut ring = attacks::king_attacks(k_sq) | k_sq.bb();
    
    // Extend ring towards the center
    let push = match color { Color::White => 8, Color::Black => -8 };
    let rank_idx = k_sq.rank() as i8;
    if (color == Color::White && rank_idx <= 2) || (color == Color::Black && rank_idx >= 5) {
        ring |= if push > 0 { ring << push } else { ring >> -push };
    }
    ring
}

fn get_pawn_ranks(file: usize, friendly: &super::pawns::PawnStructure, enemy: &super::pawns::PawnStructure, color: Color) -> (usize, usize) {
    let my_r = match color {
        Color::White => {
            let mut r = 8;
            for rank in 1..7 { if friendly.grid[rank][file] { r = rank; break; } }
            r
        },
        Color::Black => {
            let mut r = 8;
            for rank in (1..7).rev() { if friendly.grid[rank][file] { r = 7 - rank; break; } }
            r
        }
    };
    
    let opp_r = match color {
        Color::White => {
            let mut r = 8;
            for rank in (1..7).rev() { if enemy.grid[rank][file] { r = rank; break; } }
            r
        },
        Color::Black => {
            let mut r = 8;
            for rank in 1..7 { if enemy.grid[rank][file] { r = 7 - rank; break; } }
            r
        }
    };
    
    (my_r, opp_r)
}

pub fn evaluate_king_safety(board: &Board, state: &mut EvalState, color: Color, friendly: &super::pawns::PawnStructure, enemy: &super::pawns::PawnStructure) {
    let ci = color.index();
    let mg_before = state.mg[ci];
    let eg_before = state.eg[ci];

    // O anel do rei já foi calculado uma vez em eval/mod.rs (etapa 2) e
    // guardado em state.king_ring — reaproveitamos em vez de chamar
    // get_king_ring() de novo aqui (mesma função, mesmo board, mesma
    // cor: resultado idêntico, custo zero de recalcular).
    let ring = state.king_ring[ci];
    let opp = color.opponent();
    let mut attack_units = 0;
    let mut attacking_pieces = 0;
    
    let occ = board.occupancy;
    
    // Attack units computation
    for &pt in &[PieceType::Knight, PieceType::Bishop, PieceType::Rook, PieceType::Queen] {
        let pieces = board.pieces_of(opp, pt);
        for sq in iter(pieces) {
            let attacks = match pt {
                PieceType::Knight => attacks::knight_attacks(sq),
                PieceType::Bishop => attacks::bishop_attacks(sq, occ),
                PieceType::Rook => attacks::rook_attacks(sq, occ),
                PieceType::Queen => attacks::queen_attacks(sq, occ),
                _ => 0,
            };
            if (attacks & ring) != 0 {
                attack_units += KING_ATTACK_WEIGHT[pt.index()];
                attacking_pieces += 1;
            }
        }
    }
    
    // Pawn attacks on king ring
    let enemy_pawn_attacks = super::pawns::get_pawn_attacks(opp, enemy.bb);
    if (enemy_pawn_attacks & ring) != 0 {
        attack_units += PAWN_ATTACK_KING_WEIGHT;
        attacking_pieces += 1;
    }
    let friendly_pawn_attacks = super::pawns::get_pawn_attacks(color, friendly.bb);
    
    // Queen requirement
    if board.pieces_of(opp, PieceType::Queen) == 0 {
        attack_units /= 2;
    }

    // Safe checks & Contact checks
    let k_sq = board.king_square(color);
    let _my_pieces = board.color_bb[color.index()];
    let _opp_pieces = board.color_bb[opp.index()];
    
    // Knights safe checks
    let knight_checks = attacks::knight_attacks(k_sq) & board.pieces_of(opp, PieceType::Knight);
    if knight_checks != 0 {
        // Very basic safe check: undefended by our pawns
        if (knight_checks & friendly_pawn_attacks) == 0 {
            attack_units += 20; // Safe knight check
        }
    }
    
    // Queen contact checks
    let queen_contact = attacks::king_attacks(k_sq) & board.pieces_of(opp, PieceType::Queen);
    if queen_contact != 0 {
        // If the queen is adjacent and safe, very dangerous
        if (queen_contact & friendly_pawn_attacks) == 0 {
            attack_units += 40; // Queen contact check
        }
    }
    
    // Apply safety penalty
    if attacking_pieces >= 2 {
        let idx = attack_units.min(99) as usize;
        state.mg[color.index()] -= KING_SAFETY_TABLE[idx];
    }
    
    // Pawn shelter & storm
    let k_file = board.king_square(color).file() as usize;
    let min_f = k_file.saturating_sub(1);
    let max_f = (k_file + 1).min(7);
    
    for f in min_f..=max_f {
        let (my_r, opp_r) = get_pawn_ranks(f, friendly, enemy, color);
        
        if my_r == 8 {
            state.mg[color.index()] += PAWN_SHIELD_MISSING;
        } else {
            state.mg[color.index()] += PAWN_SHIELD_BONUS[my_r.min(3)];
        }
        
        if opp_r < 8 {
            state.mg[color.index()] += ENEMY_PAWN_STORM[opp_r];
        }
    }
    
    let friendly_pawn_attacks = super::pawns::get_pawn_attacks(color, friendly.bb);
    
    // Pawnless flank penalty
    let flank_mask = if k_file < 4 { 0x0F0F0F0F0F0F0F0Fu64 } else { 0xF0F0F0F0F0F0F0F0u64 };
    if (friendly.bb & flank_mask) == 0 {
        state.mg[color.index()] += PAWNLESS_FLANK_PENALTY_MG;
        state.eg[color.index()] += PAWNLESS_FLANK_PENALTY_EG;
    }

    // Weak squares
    let weak_squares = ring & !friendly_pawn_attacks;
    let weak_count = weak_squares.count_ones() as i32;
    state.mg[ci] -= weak_count * WEAK_KING_SQUARE_PENALTY;

    // Apply personality scaling (higher king_safety = more careful)
    let cfg = personality::config();
    let mg_delta = state.mg[ci] - mg_before;
    let eg_delta = state.eg[ci] - eg_before;
    state.mg[ci] = mg_before + cfg.scale(mg_delta, cfg.king_safety);
    state.eg[ci] = eg_before + cfg.scale(eg_delta, cfg.king_safety);
}
