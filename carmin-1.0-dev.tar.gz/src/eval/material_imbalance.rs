//! Material Imbalance — porte direto do `material.cpp` do Stockfish 8.
//!
//! Ao contrario da versao anterior (removida), aqui usamos DUAS matrizes
//! diferentes -- `QUADRATIC_OURS` e `QUADRATIC_THEIRS` -- em vez de uma
//! unica tabela simetrica. E exatamente essa assimetria que faz a
//! avaliacao nao se cancelar: o termo "minhas pecas vs minhas pecas"
//! (redundancia, ex: dois cavalos atrapalham um ao outro) e diferente
//! do termo "minhas pecas vs pecas do adversario" (ex: cavalo e melhor
//! contra bispo do adversario do que bispo e contra bispo).
//!
//! Indices (iguais ao Stockfish, e DIFERENTES do enum PieceType do
//! resto do codigo): 0 = par de bispos (peca "virtual"), 1 = peao,
//! 2 = cavalo, 3 = bispo, 4 = torre, 5 = dama.

use crate::board::Board;
use crate::types::{Color, PieceType};
use super::EvalState;

// ================================================================================================
// TABELAS (Tord Romstad / Stockfish) -- nao mexer sem re-tunar via Texel.
// ================================================================================================

// QUADRATIC_OURS[pt1][pt2], so pt2 <= pt1 e usado (triangular inferior).
#[rustfmt::skip]
const QUADRATIC_OURS: [[i32; 6]; 6] = [
    [1667,    0,    0,    0,    0,   0], // par de bispos
    [  40,    2,    0,    0,    0,   0], // peao
    [  32,  255,   -3,    0,    0,   0], // cavalo
    [   0,  104,    4,    0,    0,   0], // bispo
    [ -26,   -2,   47,  105, -149,   0], // torre
    [-185,   24,  122,  137, -134,   0], // dama
];

// QUADRATIC_THEIRS[pt1][pt2], so pt2 <= pt1 e usado.
#[rustfmt::skip]
const QUADRATIC_THEIRS: [[i32; 6]; 6] = [
    [  0,   0,   0,    0,    0,  0], // par de bispos
    [ 36,   0,   0,    0,    0,  0], // peao
    [  9,  63,   0,    0,    0,  0], // cavalo
    [ 59,  65,  42,    0,    0,  0], // bispo
    [ 46,  39,  24,  -24,    0,  0], // torre
    [101, 100, -37,  141,  268,  0], // dama
];

/// Conta de pecas no formato/indice usado pelo Stockfish:
/// [par_de_bispos, peoes, cavalos, bispos, torres, damas]
fn piece_counts(board: &Board, color: Color) -> [i32; 6] {
    let pawns = board.pieces_of(color, PieceType::Pawn).count_ones() as i32;
    let knights = board.pieces_of(color, PieceType::Knight).count_ones() as i32;
    let bishops = board.pieces_of(color, PieceType::Bishop).count_ones() as i32;
    let rooks = board.pieces_of(color, PieceType::Rook).count_ones() as i32;
    let queens = board.pieces_of(color, PieceType::Queen).count_ones() as i32;
    let bishop_pair = (bishops > 1) as i32;
    [bishop_pair, pawns, knights, bishops, rooks, queens]
}

/// imbalance<Us>() do Stockfish: soma polinomial de 2o grau sobre as
/// pecas de `us`, usando tanto a contagem propria quanto a do
/// adversario. Note que isso NAO e simetrico entre `us` e `them`
/// porque QUADRATIC_OURS != QUADRATIC_THEIRS.
fn imbalance_for(us: &[i32; 6], them: &[i32; 6]) -> i32 {
    let mut bonus = 0;

    for pt1 in 0..6 {
        if us[pt1] == 0 {
            continue;
        }

        let mut v = 0;
        for pt2 in 0..=pt1 {
            v += QUADRATIC_OURS[pt1][pt2] * us[pt2]
                + QUADRATIC_THEIRS[pt1][pt2] * them[pt2];
        }

        bonus += us[pt1] * v;
    }

    bonus
}

/// Calcula o imbalance diferencial (Branco - Preto) e aplica inteiro ao
/// lado Branco em `state` (o restante do pipeline ja faz
/// `mg[White] - mg[Black]`, entao colocar a diferenca toda de um lado
/// so produz o mesmo resultado que dividir meio a meio).
///
/// Chame isso UMA VEZ por avaliacao (nao uma vez por cor).
pub fn evaluate_material_imbalance(board: &Board, state: &mut EvalState) {
    let white = piece_counts(board, Color::White);
    let black = piece_counts(board, Color::Black);

    let white_bonus = imbalance_for(&white, &black);
    let black_bonus = imbalance_for(&black, &white);

    // Mesma escala do Stockfish (divisao por 16 no final).
    let diff = (white_bonus - black_bonus) / 16;

    // Stockfish usa make_score(value, value): mesmo valor em MG e EG.
    state.mg[Color::White.index()] += diff;
    state.eg[Color::White.index()] += diff;
}
