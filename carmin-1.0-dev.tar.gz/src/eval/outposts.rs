use crate::board::Board;
use crate::types::{Color, Square, PieceType};
use crate::bitboard::{iter, Bitboard};
use super::EvalState;

// ================================================================================================
// CONSTANTS FOR OUTPOSTS
// ================================================================================================

const OUTPOST_KNIGHT_MG: i32 = 25;
const OUTPOST_KNIGHT_EG: i32 = 15;

const OUTPOST_BISHOP_MG: i32 = 15;
const OUTPOST_BISHOP_EG: i32 = 10;

const SEMI_OUTPOST_BONUS_MG: i32 = 10;

// ================================================================================================
// MAIN EVALUATION
// ================================================================================================

pub fn evaluate_outposts(
    board: &Board,
    state: &mut EvalState,
    color: Color,
) {
    let ci = color.index();
    let opp = color.opponent();

    let my_knights = board.pieces_of(color, PieceType::Knight);
    let my_bishops = board.pieces_of(color, PieceType::Bishop);
    let my_pawns = board.pieces_of(color, PieceType::Pawn);
    let opp_pawns = board.pieces_of(opp, PieceType::Pawn);

    // Outposts are squares on the 4th, 5th, or 6th ranks (from player's perspective)
    // that are defended by a friendly pawn and cannot be attacked by an enemy pawn.
    
    for sq in iter(my_knights) {
        if is_outpost(sq, color, my_pawns, opp_pawns) {
            state.mg[ci] += OUTPOST_KNIGHT_MG;
            state.eg[ci] += OUTPOST_KNIGHT_EG;
            
            // Check if the opponent has a bishop that can contest it
            let sq_color = (sq.file() + sq.rank()) % 2;
            let mut can_be_contested = false;
            for opp_b in iter(board.pieces_of(opp, PieceType::Bishop)) {
                let opp_b_color = (opp_b.file() + opp_b.rank()) % 2;
                if opp_b_color == sq_color {
                    can_be_contested = true;
                    break;
                }
            }
            
            if !can_be_contested {
                // Uncontestable outpost!
                state.mg[ci] += 10;
                state.eg[ci] += 10;
            }
        } else if is_semi_outpost(sq, color, my_pawns, opp_pawns) {
            state.mg[ci] += SEMI_OUTPOST_BONUS_MG;
        }
    }

    for sq in iter(my_bishops) {
        if is_outpost(sq, color, my_pawns, opp_pawns) {
            state.mg[ci] += OUTPOST_BISHOP_MG;
            state.eg[ci] += OUTPOST_BISHOP_EG;
        }
    }
}

// ================================================================================================
// HELPER FUNCTIONS
// ================================================================================================

fn is_outpost(sq: Square, color: Color, my_pawns: Bitboard, opp_pawns: Bitboard) -> bool {
    let r = match color {
        Color::White => sq.rank(),
        Color::Black => 7 - sq.rank(),
    };
    
    if r < 3 || r > 5 {
        return false; // Must be on 4th, 5th, or 6th rank
    }
    
    // 1. Must be defended by a friendly pawn
    let defended = pawn_attacks(color.opponent(), sq.bb()) & my_pawns;
    if defended == 0 {
        return false;
    }
    
    // 2. Cannot be attacked by an enemy pawn (now or in the future on adjacent files)
    let f = sq.file() as usize;
    let adj = adjacent_files(f);
    
    let front_span = match color {
        Color::White => !((1u64 << ((sq.rank() as usize) * 8)) - 1),
        Color::Black => (1u64 << ((sq.rank() as usize + 1) * 8)) - 1,
    };
    
    let enemy_pawns_that_can_attack = opp_pawns & adj & front_span;
    if enemy_pawns_that_can_attack != 0 {
        return false;
    }
    
    true
}

fn is_semi_outpost(sq: Square, color: Color, my_pawns: Bitboard, opp_pawns: Bitboard) -> bool {
    // A semi-outpost is defended by a pawn, and cannot currently be attacked by an enemy pawn,
    // but MIGHT be attacked if the enemy pawn pushes.
    
    let r = match color {
        Color::White => sq.rank(),
        Color::Black => 7 - sq.rank(),
    };
    
    if r < 3 || r > 5 { return false; }
    
    let defended = pawn_attacks(color.opponent(), sq.bb()) & my_pawns;
    if defended == 0 { return false; }
    
    let currently_attacked = pawn_attacks(color, sq.bb()) & opp_pawns;
    if currently_attacked != 0 { return false; }
    
    true
}

fn adjacent_files(file: usize) -> Bitboard {
    let mut mask = 0;
    if file > 0 { mask |= 0x0101010101010101u64 << (file - 1); }
    if file < 7 { mask |= 0x0101010101010101u64 << (file + 1); }
    mask
}

fn pawn_attacks(color: Color, pawns: Bitboard) -> Bitboard {
    let not_a = 0xfefefefefefefefe;
    let not_h = 0x7f7f7f7f7f7f7f7f;
    match color {
        Color::White => ((pawns & not_a) << 7) | ((pawns & not_h) << 9),
        Color::Black => ((pawns & not_h) >> 7) | ((pawns & not_a) >> 9),
    }
}

// ------------------------------------------------------------------------------------------------
// EXTENSIVE OUTPOST DUMMY ANALYSIS LOGIC
// ------------------------------------------------------------------------------------------------

#[allow(dead_code)]
fn evaluate_outpost_hole(board: &Board, color: Color, sq: Square) -> i32 {
    // If an outpost is inside a "hole" (a square that cannot be defended by enemy pawns)
    // we give it extra value.
    let opp = color.opponent();
    let opp_pawns = board.pieces_of(opp, PieceType::Pawn);
    
    let f = sq.file() as usize;
    let adj = adjacent_files(f);
    
    let front_span = match opp {
        Color::White => !((1u64 << ((sq.rank() as usize) * 8)) - 1),
        Color::Black => (1u64 << ((sq.rank() as usize + 1) * 8)) - 1,
    };
    
    // Are there any enemy pawns behind or on the same rank on adjacent files?
    let enemy_pawns_behind = opp_pawns & adj & !front_span;
    
    if enemy_pawns_behind == 0 {
        return 15; // It's a permanent hole
    }
    
    0
}
// END OF outposts.rs
