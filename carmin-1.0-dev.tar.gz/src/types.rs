//! Core value types: colors, pieces, squares, and moves.

use std::fmt;

/// Side to move / piece color.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum Color {
    White = 0,
    Black = 1,
}

impl Color {
    #[inline]
    pub fn opponent(self) -> Color {
        match self {
            Color::White => Color::Black,
            Color::Black => Color::White,
        }
    }

    #[inline]
    pub fn index(self) -> usize {
        self as usize
    }
}

/// The six piece kinds, ordered by convention.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PieceType {
    Pawn = 0,
    Knight = 1,
    Bishop = 2,
    Rook = 3,
    Queen = 4,
    King = 5,
}

pub const PIECE_TYPES: [PieceType; 6] = [
    PieceType::Pawn,
    PieceType::Knight,
    PieceType::Bishop,
    PieceType::Rook,
    PieceType::Queen,
    PieceType::King,
];

impl PieceType {
    #[inline]
    pub fn index(self) -> usize {
        self as usize
    }

    #[inline]
    pub fn from_index(i: usize) -> PieceType {
        PIECE_TYPES[i]
    }

    /// Lowercase character used in FEN/algebraic notation.
    pub fn to_char(self) -> char {
        match self {
            PieceType::Pawn => 'p',
            PieceType::Knight => 'n',
            PieceType::Bishop => 'b',
            PieceType::Rook => 'r',
            PieceType::Queen => 'q',
            PieceType::King => 'k',
        }
    }
}

/// A colored piece.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Piece {
    pub color: Color,
    pub kind: PieceType,
}

impl Piece {
    pub fn new(color: Color, kind: PieceType) -> Piece {
        Piece { color, kind }
    }

    pub fn to_char(self) -> char {
        let c = self.kind.to_char();
        match self.color {
            Color::White => c.to_ascii_uppercase(),
            Color::Black => c,
        }
    }

    pub fn from_char(c: char) -> Option<Piece> {
        let color = if c.is_ascii_uppercase() {
            Color::White
        } else {
            Color::Black
        };
        let kind = match c.to_ascii_lowercase() {
            'p' => PieceType::Pawn,
            'n' => PieceType::Knight,
            'b' => PieceType::Bishop,
            'r' => PieceType::Rook,
            'q' => PieceType::Queen,
            'k' => PieceType::King,
            _ => return None,
        };
        Some(Piece::new(color, kind))
    }
}

/// A board square in the range 0..64 (a1 = 0, h8 = 63).
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct Square(pub u8);

impl Square {
    #[inline]
    pub fn new(index: u8) -> Square {
        debug_assert!(index < 64);
        Square(index)
    }

    #[inline]
    pub fn from_file_rank(file: u8, rank: u8) -> Square {
        Square(rank * 8 + file)
    }

    #[inline]
    pub fn index(self) -> usize {
        self.0 as usize
    }

    #[inline]
    pub fn file(self) -> u8 {
        self.0 % 8
    }

    #[inline]
    pub fn rank(self) -> u8 {
        self.0 / 8
    }

    #[inline]
    pub fn bb(self) -> u64 {
        1u64 << self.0
    }

    /// Parse a square from algebraic notation such as "e4".
    pub fn from_algebraic(s: &str) -> Option<Square> {
        let bytes = s.as_bytes();
        if bytes.len() != 2 {
            return None;
        }
        let file = bytes[0].wrapping_sub(b'a');
        let rank = bytes[1].wrapping_sub(b'1');
        if file < 8 && rank < 8 {
            Some(Square::from_file_rank(file, rank))
        } else {
            None
        }
    }
}

impl fmt::Display for Square {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let file = (b'a' + self.file()) as char;
        let rank = (b'1' + self.rank()) as char;
        write!(f, "{}{}", file, rank)
    }
}

/// Extra information attached to a move.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MoveFlag {
    Quiet,
    DoublePawnPush,
    KingCastle,
    QueenCastle,
    Capture,
    EnPassant,
    Promotion(PieceType),
    PromotionCapture(PieceType),
}

/// A chess move: origin, destination, and a descriptive flag.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct Move {
    pub from: Square,
    pub to: Square,
    pub flag: MoveFlag,
}

impl Move {
    pub fn new(from: Square, to: Square, flag: MoveFlag) -> Move {
        Move { from, to, flag }
    }

    #[inline]
    pub fn is_capture(self) -> bool {
        matches!(
            self.flag,
            MoveFlag::Capture | MoveFlag::EnPassant | MoveFlag::PromotionCapture(_)
        )
    }

    #[inline]
    pub fn promotion(self) -> Option<PieceType> {
        match self.flag {
            MoveFlag::Promotion(pt) | MoveFlag::PromotionCapture(pt) => Some(pt),
            _ => None,
        }
    }

    /// Long algebraic (UCI) representation, e.g. "e2e4" or "e7e8q".
    pub fn to_uci(self) -> String {
        let mut s = format!("{}{}", self.from, self.to);
        if let Some(pt) = self.promotion() {
            s.push(pt.to_char());
        }
        s
    }

    #[inline]
    pub fn encode_u16(self) -> u16 {
        let f_code = match self.flag {
            MoveFlag::Quiet => 0,
            MoveFlag::DoublePawnPush => 1,
            MoveFlag::KingCastle => 2,
            MoveFlag::QueenCastle => 3,
            MoveFlag::Capture => 4,
            MoveFlag::EnPassant => 5,
            MoveFlag::Promotion(PieceType::Knight) => 6,
            MoveFlag::Promotion(PieceType::Bishop) => 7,
            MoveFlag::Promotion(PieceType::Rook) => 8,
            MoveFlag::Promotion(PieceType::Queen) => 9,
            MoveFlag::PromotionCapture(PieceType::Knight) => 10,
            MoveFlag::PromotionCapture(PieceType::Bishop) => 11,
            MoveFlag::PromotionCapture(PieceType::Rook) => 12,
            MoveFlag::PromotionCapture(PieceType::Queen) => 13,
            _ => 0,
        };
        (self.from.0 as u16) | ((self.to.0 as u16) << 6) | (f_code << 12)
    }

    #[inline]
    pub fn decode_u16(encoded: u16) -> Option<Move> {
        if encoded == 0 {
            return None;
        }
        let from = Square(encoded as u8 & 0x3F);
        let to = Square((encoded >> 6) as u8 & 0x3F);
        let f_code = (encoded >> 12) as u8 & 0x0F;
        let flag = match f_code {
            0 => MoveFlag::Quiet,
            1 => MoveFlag::DoublePawnPush,
            2 => MoveFlag::KingCastle,
            3 => MoveFlag::QueenCastle,
            4 => MoveFlag::Capture,
            5 => MoveFlag::EnPassant,
            6 => MoveFlag::Promotion(PieceType::Knight),
            7 => MoveFlag::Promotion(PieceType::Bishop),
            8 => MoveFlag::Promotion(PieceType::Rook),
            9 => MoveFlag::Promotion(PieceType::Queen),
            10 => MoveFlag::PromotionCapture(PieceType::Knight),
            11 => MoveFlag::PromotionCapture(PieceType::Bishop),
            12 => MoveFlag::PromotionCapture(PieceType::Rook),
            13 => MoveFlag::PromotionCapture(PieceType::Queen),
            _ => MoveFlag::Quiet,
        };
        Some(Move::new(from, to, flag))
    }
}

impl fmt::Display for Move {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(f, "{}", self.to_uci())
    }
}
