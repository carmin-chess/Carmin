//! Zobrist hashing keys for transposition-table lookups and repetition
//! detection.

use crate::types::{Color, PieceType, Square};
use std::sync::OnceLock;

pub struct Zobrist {
    /// `piece[color][piece_type][square]`
    pub piece: [[[u64; 64]; 6]; 2],
    /// One key per castling-rights combination (4 bits).
    pub castling: [u64; 16],
    /// One key per en-passant file.
    pub en_passant: [u64; 8],
    /// Applied when it is Black to move.
    pub side: u64,
}

static ZOBRIST: OnceLock<Zobrist> = OnceLock::new();

pub fn keys() -> &'static Zobrist {
    ZOBRIST.get_or_init(build)
}

fn build() -> Zobrist {
    let mut rng = SplitMix64(0x9E37_79B9_7F4A_7C15);
    let mut piece = [[[0u64; 64]; 6]; 2];
    for color in piece.iter_mut() {
        for kind in color.iter_mut() {
            for sq in kind.iter_mut() {
                *sq = rng.next();
            }
        }
    }
    let mut castling = [0u64; 16];
    for c in castling.iter_mut() {
        *c = rng.next();
    }
    let mut en_passant = [0u64; 8];
    for e in en_passant.iter_mut() {
        *e = rng.next();
    }
    let side = rng.next();
    Zobrist {
        piece,
        castling,
        en_passant,
        side,
    }
}

impl Zobrist {
    #[inline]
    pub fn piece_key(&self, color: Color, kind: PieceType, sq: Square) -> u64 {
        self.piece[color.index()][kind.index()][sq.index()]
    }
}

/// SplitMix64 PRNG — good distribution for hashing keys.
struct SplitMix64(u64);

impl SplitMix64 {
    fn next(&mut self) -> u64 {
        self.0 = self.0.wrapping_add(0x9E37_79B9_7F4A_7C15);
        let mut z = self.0;
        z = (z ^ (z >> 30)).wrapping_mul(0xBF58_476D_1CE4_E5B9);
        z = (z ^ (z >> 27)).wrapping_mul(0x94D0_49BB_1331_11EB);
        z ^ (z >> 31)
    }
}
