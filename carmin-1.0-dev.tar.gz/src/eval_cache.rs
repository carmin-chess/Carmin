//! Eval Hash Table
//!
//! Cacheia o resultado final de `eval::evaluate()` (score completo, já
//! side-relative e com tempo bônus) por hash Zobrist da posição inteira.
//! Diferente do pawn cache (que só cacheia a parcela de estrutura de
//! peões), este cache evita refazer TODOS os ~20 módulos de avaliação
//! (mobilidade, king safety/danger, threats, space, outposts, patterns,
//! material imbalance, etc.) quando a mesma posição é reavaliada — o que
//! acontece com frequência via transposições, re-buscas de LMR/singular
//! extension, IID e ProbCut.

pub struct EvalCacheEntry {
    pub key: u64,
    pub score: i32,
}

pub struct EvalCache {
    entries: Vec<EvalCacheEntry>,
    mask: usize,
}

impl EvalCache {
    pub fn new() -> Self {
        // Potência de 2 pra indexação via máscara.
        // 1<<18 = 262144 entradas * 12 bytes ~= 3MB, cabe fácil na L3.
        const SIZE: usize = 1 << 18;

        let mut entries = Vec::with_capacity(SIZE);

        for _ in 0..SIZE {
            entries.push(EvalCacheEntry { key: 0, score: 0 });
        }

        Self { entries, mask: SIZE - 1 }
    }

    #[inline]
    pub fn probe(&self, key: u64) -> Option<i32> {
        let idx = (key as usize) & self.mask;
        let entry = &self.entries[idx];

        // Mesma observação do pawn cache: key==0 é uma colisão
        // teoricamente possível mas inofensiva na prática.
        if entry.key == key {
            Some(entry.score)
        } else {
            None
        }
    }

    #[inline]
    pub fn store(&mut self, key: u64, score: i32) {
        let idx = (key as usize) & self.mask;
        self.entries[idx] = EvalCacheEntry { key, score };
    }
}

impl Default for EvalCache {
    fn default() -> Self {
        Self::new()
    }
}
