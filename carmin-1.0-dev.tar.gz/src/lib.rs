//! A UCI chess engine with bitboards, magic move generation, Texel-tuned HCE,
//! multi-bucket transposition table, and advanced alpha-beta search.

pub mod attacks;
pub mod bitboard;
pub mod board;
pub mod eval;
pub mod eval_cache;
pub mod movegen;
pub mod movepick;
pub mod pawn_cache;
pub mod perft;
pub mod personality;
pub mod search;
pub mod tt;
pub mod types;
pub mod uci;
pub mod zobrist;
pub mod open;
