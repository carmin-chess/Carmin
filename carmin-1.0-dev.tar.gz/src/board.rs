//! Estado do tabuleiro, codificação FEN e make/unmake move.

use crate::attacks;
use crate::bitboard::*;
use crate::types::*;
use crate::zobrist;

/// Flags de Direitos de Roque.
pub const CASTLE_WK: u8 = 1;
pub const CASTLE_WQ: u8 = 2;
pub const CASTLE_BK: u8 = 4;
pub const CASTLE_BQ: u8 = 8;

/// Estado irreversível salvo para desfazer lances (unmake).
#[derive(Clone, Copy)]
pub struct Undo {
    pub captured: Option<Piece>,
    pub castling: u8,
    pub en_passant: Option<Square>,
    pub halfmove_clock: u16,
    pub hash: u64,
}

#[derive(Clone)]
pub struct Board {
    /// `pieces[color][piece_type]`
    pub pieces: [[Bitboard; 6]; 2],
    pub color_bb: [Bitboard; 2],
    pub occupancy: Bitboard,
    pub mailbox: [Option<Piece>; 64],
    pub side: Color,
    pub castling: u8,
    pub en_passant: Option<Square>,
    pub halfmove_clock: u16,
    pub fullmove: u16,
    pub hash: u64,
    pub history: Vec<u64>,
}

impl Board {
    pub fn empty() -> Board {
        Board {
            pieces: [[0; 6]; 2],
            color_bb: [0; 2],
            occupancy: 0,
            mailbox: [None; 64],
            side: Color::White,
            castling: 0,
            en_passant: None,
            halfmove_clock: 0,
            fullmove: 1,
            hash: 0,
            history: Vec::with_capacity(256),
        }
    }

    pub fn startpos() -> Board {
        Board::from_fen("rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1").unwrap()
    }

    #[inline(always)]
    pub fn piece_on(&self, sq: Square) -> Option<Piece> {
        self.mailbox[sq.index()]
    }

    #[inline(always)]
    pub fn pieces_of(&self, color: Color, kind: PieceType) -> Bitboard {
        self.pieces[color.index()][kind.index()]
    }

    #[inline(always)]
    pub fn king_square(&self, color: Color) -> Square {
        lsb(self.pieces_of(color, PieceType::King))
    }

    /// Adiciona uma peça ao tabuleiro.
    #[inline(always)]
    fn add_piece(&mut self, color: Color, kind: PieceType, sq: Square) {
        let bb = sq.bb();
        self.pieces[color.index()][kind.index()] |= bb;
        self.color_bb[color.index()] |= bb;
        self.occupancy |= bb;
        self.mailbox[sq.index()] = Some(Piece::new(color, kind));
        self.hash ^= zobrist::keys().piece_key(color, kind, sq);
    }

    /// Remove uma peça do tabuleiro.
    #[inline(always)]
    fn remove_piece(&mut self, color: Color, kind: PieceType, sq: Square) {
        let bb = sq.bb();
        self.pieces[color.index()][kind.index()] &= !bb;
        self.color_bb[color.index()] &= !bb;
        self.occupancy &= !bb;
        self.mailbox[sq.index()] = None;
        self.hash ^= zobrist::keys().piece_key(color, kind, sq);
    }

    #[inline(always)]
    fn move_piece(&mut self, color: Color, kind: PieceType, from: Square, to: Square) {
        let bb_from = from.bb();
        let bb_to = to.bb();
        let mask = bb_from | bb_to;

        self.pieces[color.index()][kind.index()] ^= mask;
        self.color_bb[color.index()] ^= mask;
        self.occupancy ^= mask;
        self.mailbox[from.index()] = None;
        self.mailbox[to.index()] = Some(Piece::new(color, kind));

        self.hash ^= zobrist::keys().piece_key(color, kind, from);
        self.hash ^= zobrist::keys().piece_key(color, kind, to);
    }

    #[inline(always)]
    fn add_piece_fast(&mut self, color: Color, kind: PieceType, sq: Square) {
        let bb = sq.bb();
        self.pieces[color.index()][kind.index()] |= bb;
        self.color_bb[color.index()] |= bb;
        self.occupancy |= bb;
        self.mailbox[sq.index()] = Some(Piece::new(color, kind));
        self.hash ^= zobrist::keys().piece_key(color, kind, sq);
    }

    #[inline(always)]
    fn remove_piece_fast(&mut self, color: Color, kind: PieceType, sq: Square) {
        let bb = sq.bb();
        self.pieces[color.index()][kind.index()] &= !bb;
        self.color_bb[color.index()] &= !bb;
        self.occupancy &= !bb;
        self.mailbox[sq.index()] = None;
        self.hash ^= zobrist::keys().piece_key(color, kind, sq);
    }

    #[inline(always)]
    fn move_piece_fast(&mut self, color: Color, kind: PieceType, from: Square, to: Square) {
        let mask = from.bb() | to.bb();
        self.pieces[color.index()][kind.index()] ^= mask;
        self.color_bb[color.index()] ^= mask;
        self.occupancy ^= mask;
        self.mailbox[from.index()] = None;
        self.mailbox[to.index()] = Some(Piece::new(color, kind));
        self.hash ^= zobrist::keys().piece_key(color, kind, from);
        self.hash ^= zobrist::keys().piece_key(color, kind, to);
    }

    #[inline(always)]
    fn move_king_fast(&mut self, color: Color, from: Square, to: Square) {
        let mask = from.bb() | to.bb();
        self.pieces[color.index()][PieceType::King.index()] ^= mask;
        self.color_bb[color.index()] ^= mask;
        self.occupancy ^= mask;
        self.mailbox[from.index()] = None;
        self.mailbox[to.index()] = Some(Piece::new(color, PieceType::King));
        self.hash ^= zobrist::keys().piece_key(color, PieceType::King, from);
        self.hash ^= zobrist::keys().piece_key(color, PieceType::King, to);
    }

    // =====================================================================
    // FILTRO DE SANIDADE DE MOVIMENTOS (Corrige o panic da TT e Falsos Stalemates)
    // =====================================================================

    /// Verifica se um lance gerado fora do MoveGen (ex: via TT) é pelo menos
    /// pseudo-legal e não vai quebrar a execução (panic de casa vazia).
    pub fn is_pseudo_legal(&self, mv: Move) -> bool {
        let from = mv.from;
        let to = mv.to;
        let us = self.side;

        // 1. Casa de origem não pode estar vazia (PREVINE O SEU PANIC)
        let moving = match self.piece_on(from) {
            Some(p) => p,
            None => return false,
        };

        // 2. A peça precisa nos pertencer
        if moving.color != us {
            return false;
        }

        // 3. Não podemos capturar nossas próprias peças
        if let Some(target) = self.piece_on(to) {
            if target.color == us {
                return false;
            }
            if !matches!(mv.flag, MoveFlag::Capture | MoveFlag::PromotionCapture(_)) {
                return false;
            }
        } else {
            // Casa de destino vazia: flag de captura não pode existir
            if matches!(mv.flag, MoveFlag::Capture | MoveFlag::PromotionCapture(_)) {
                return false;
            }
        }

        let to_bb = to.bb();
        let occ = self.occupancy;

        // 4. Validação baseada na geometria da peça
        match moving.kind {
            PieceType::Pawn => {
                let forward = if us == Color::White { 8 } else { -8 };

                match mv.flag {
                    MoveFlag::Quiet | MoveFlag::Promotion(_) => {
                        // Peão avançando: casa de destino DEVE estar vazia
                        if self.piece_on(to).is_some() {
                            return false;
                        }
                        // Avanço simples
                        if to.0 as i8 == from.0 as i8 + forward {
                            return true;
                        }
                        false
                    }
                    MoveFlag::DoublePawnPush => {
                        if self.piece_on(to).is_some() {
                            return false;
                        }
                        let start_rank = if us == Color::White { 1 } else { 6 };
                        if from.rank() == start_rank 
                            && to.0 as i8 == from.0 as i8 + (forward * 2) 
                            && self.piece_on(Square((from.0 as i8 + forward) as u8)).is_none() 
                        {
                            return true;
                        }
                        false
                    }
                    MoveFlag::Capture | MoveFlag::PromotionCapture(_) => {
                        let pawn_attacks = attacks::pawn_attacks(us, from);
                        (pawn_attacks & to_bb) != 0
                    }
                    MoveFlag::EnPassant => {
                        let pawn_attacks = attacks::pawn_attacks(us, from);
                        (pawn_attacks & to_bb) != 0 && self.en_passant == Some(to)
                    }
                    _ => false,
                }
            }
            PieceType::Knight => {
                if !matches!(mv.flag, MoveFlag::Quiet | MoveFlag::Capture) { return false; }
                (attacks::knight_attacks(from) & to_bb) != 0
            }
            PieceType::Bishop => {
                if !matches!(mv.flag, MoveFlag::Quiet | MoveFlag::Capture) { return false; }
                (attacks::bishop_attacks(from, occ) & to_bb) != 0
            }
            PieceType::Rook => {
                if !matches!(mv.flag, MoveFlag::Quiet | MoveFlag::Capture) { return false; }
                (attacks::rook_attacks(from, occ) & to_bb) != 0
            }
            PieceType::Queen => {
                if !matches!(mv.flag, MoveFlag::Quiet | MoveFlag::Capture) { return false; }
                let queen_attacks = attacks::bishop_attacks(from, occ) | attacks::rook_attacks(from, occ);
                (queen_attacks & to_bb) != 0
            }
            PieceType::King => {
                if !matches!(mv.flag, MoveFlag::Quiet | MoveFlag::Capture | MoveFlag::KingCastle | MoveFlag::QueenCastle) { return false; }
                // --- CORREÇÃO DO ROQUE FANTASMA ---
                if mv.flag == MoveFlag::KingCastle {
                    let mask = if us == Color::White { CASTLE_WK } else { CASTLE_BK };
                    if (self.castling & mask) == 0 { return false; }
                    
                    return if us == Color::White {
                        self.piece_on(Square(5)).is_none() && // f1 vazia
                        self.piece_on(Square(6)).is_none() && // g1 vazia
                        !self.in_check(us) &&                 // rei não está em xeque
                        !self.is_attacked(Square(5), Color::Black) // f1 não atacada
                    } else {
                        self.piece_on(Square(61)).is_none() && // f8 vazia
                        self.piece_on(Square(62)).is_none() && // g8 vazia
                        !self.in_check(us) &&                  // rei não está em xeque
                        !self.is_attacked(Square(61), Color::White) // f8 não atacada
                    };
                }
                if mv.flag == MoveFlag::QueenCastle {
                    let mask = if us == Color::White { CASTLE_WQ } else { CASTLE_BQ };
                    if (self.castling & mask) == 0 { return false; }

                    return if us == Color::White {
                        self.piece_on(Square(1)).is_none() && // b1 vazia
                        self.piece_on(Square(2)).is_none() && // c1 vazia
                        self.piece_on(Square(3)).is_none() && // d1 vazia
                        !self.in_check(us) &&                 // rei não está em xeque
                        !self.is_attacked(Square(3), Color::Black) && // d1 não atacada
                        !self.is_attacked(Square(2), Color::Black) // c1 não atacada
                    } else {
                        self.piece_on(Square(57)).is_none() && // b8 vazia
                        self.piece_on(Square(58)).is_none() && // c8 vazia
                        self.piece_on(Square(59)).is_none() && // d8 vazia
                        !self.in_check(us) &&                  // rei não está em xeque
                        !self.is_attacked(Square(59), Color::White) && // d8 não atacada
                        !self.is_attacked(Square(58), Color::White) // c8 não atacada
                    };
                }
                (attacks::king_attacks(from) & to_bb) != 0
            }
        }
    }

    /// Executa um lance (filtragem rápida de legalidade em movegen)
    pub fn make_move_fast(&mut self, mv: Move) -> Undo {
        let z = zobrist::keys();
        let us = self.side;
        let them = us.opponent();
        let from = mv.from;
        let to = mv.to;
        
        let moving = self.piece_on(from).expect("sem peça na casa de origem"); 

        let undo = Undo {
            captured: None,
            castling: self.castling,
            en_passant: self.en_passant,
            halfmove_clock: self.halfmove_clock,
            hash: self.hash,
        };
        let mut captured: Option<Piece> = None;

        if let Some(ep) = self.en_passant {
            self.hash ^= z.en_passant[ep.file() as usize];
        }
        self.en_passant = None;

        self.halfmove_clock += 1;
        if moving.kind == PieceType::Pawn {
            self.halfmove_clock = 0;
        }

        match mv.flag {
            MoveFlag::Quiet | MoveFlag::DoublePawnPush => {
                if moving.kind == PieceType::King {
                    self.move_king_fast(us, from, to);
                } else {
                    self.move_piece_fast(us, moving.kind, from, to);
                }

                if mv.flag == MoveFlag::DoublePawnPush {
                    let ep_sq = Square(((from.0 as i8 + to.0 as i8) / 2) as u8);
                    self.en_passant = Some(ep_sq);
                    self.hash ^= z.en_passant[ep_sq.file() as usize];
                }
            }
            MoveFlag::Capture => {
                let cap = self.piece_on(to).expect("sem peça para capturar");
                captured = Some(cap);
                self.halfmove_clock = 0;
                self.remove_piece_fast(them, cap.kind, to);

                if moving.kind == PieceType::King {
                    self.move_king_fast(us, from, to);
                } else {
                    self.move_piece_fast(us, moving.kind, from, to);
                }
            }
            MoveFlag::EnPassant => {
                let cap_sq = Square::from_file_rank(to.file(), from.rank());
                captured = Some(Piece::new(them, PieceType::Pawn));
                self.halfmove_clock = 0;
                self.remove_piece_fast(them, PieceType::Pawn, cap_sq);
                self.move_piece_fast(us, PieceType::Pawn, from, to);
            }
            MoveFlag::KingCastle => {
                self.move_king_fast(us, from, to);
                let (rook_from, rook_to) = match us {
                    Color::White => (Square(7), Square(5)),
                    Color::Black => (Square(63), Square(61)),
                };
                self.move_piece_fast(us, PieceType::Rook, rook_from, rook_to);
            }
            MoveFlag::QueenCastle => {
                self.move_king_fast(us, from, to);
                let (rook_from, rook_to) = match us {
                    Color::White => (Square(0), Square(3)),
                    Color::Black => (Square(56), Square(59)),
                };
                self.move_piece_fast(us, PieceType::Rook, rook_from, rook_to);
            }
            MoveFlag::Promotion(promo) => {
                self.remove_piece_fast(us, PieceType::Pawn, from);
                self.add_piece_fast(us, promo, to);
            }
            MoveFlag::PromotionCapture(promo) => {
                let cap = self.piece_on(to).expect("sem peça para capturar na promoção");
                captured = Some(cap);
                self.halfmove_clock = 0;
                self.remove_piece_fast(them, cap.kind, to);
                self.remove_piece_fast(us, PieceType::Pawn, from);
                self.add_piece_fast(us, promo, to);
            }
        }

        self.hash ^= z.castling[self.castling as usize];
        self.castling &= castle_rights_mask(from) & castle_rights_mask(to);
        self.hash ^= z.castling[self.castling as usize];

        self.side = them;
        self.hash ^= z.side;
        if us == Color::Black {
            self.fullmove += 1;
        }

        let mut undo = undo;
        undo.captured = captured;
        self.history.push(self.hash);
        undo
    }

    /// Desfaz um lance rápido
    pub fn unmake_move_fast(&mut self, mv: Move, undo: Undo) {
        self.history.pop();
        let them = self.side;
        let us = them.opponent();
        self.side = us;
        if us == Color::Black {
            self.fullmove -= 1;
        }
        let from = mv.from;
        let to = mv.to;

        let moving = self.piece_on(to).or_else(|| {
            if matches!(mv.flag, MoveFlag::Promotion(_) | MoveFlag::PromotionCapture(_)) {
                Some(Piece::new(us, PieceType::Pawn))
            } else {
                None
            }
        }).expect("nenhuma peça no destino durante unmake_fast");

        match mv.flag {
            MoveFlag::Quiet | MoveFlag::DoublePawnPush => {
                if moving.kind == PieceType::King {
                    self.move_king_fast(us, to, from);
                } else {
                    self.move_piece_fast(us, moving.kind, to, from);
                }
            }
            MoveFlag::Capture => {
                if moving.kind == PieceType::King {
                    self.move_king_fast(us, to, from);
                } else {
                    self.move_piece_fast(us, moving.kind, to, from);
                }
                if let Some(cap) = undo.captured {
                    self.add_piece_fast(them, cap.kind, to);
                }
            }
            MoveFlag::EnPassant => {
                self.move_piece_fast(us, PieceType::Pawn, to, from);
                let cap_sq = Square::from_file_rank(to.file(), from.rank());
                self.add_piece_fast(them, PieceType::Pawn, cap_sq);
            }
            MoveFlag::KingCastle => {
                let (rook_from, rook_to) = match us {
                    Color::White => (Square(7), Square(5)),
                    Color::Black => (Square(63), Square(61)),
                };
                self.move_piece_fast(us, PieceType::Rook, rook_to, rook_from);
                self.move_king_fast(us, to, from);
            }
            MoveFlag::QueenCastle => {
                let (rook_from, rook_to) = match us {
                    Color::White => (Square(0), Square(3)),
                    Color::Black => (Square(56), Square(59)),
                };
                self.move_piece_fast(us, PieceType::Rook, rook_to, rook_from);
                self.move_king_fast(us, to, from);
            }
            MoveFlag::Promotion(promo) => {
                self.remove_piece_fast(us, promo, to);
                self.add_piece_fast(us, PieceType::Pawn, from);
            }
            MoveFlag::PromotionCapture(promo) => {
                self.remove_piece_fast(us, promo, to);
                self.add_piece_fast(us, PieceType::Pawn, from);
                if let Some(cap) = undo.captured {
                    self.add_piece_fast(them, cap.kind, to);
                }
            }
        }

        self.castling = undo.castling;
        self.en_passant = undo.en_passant;
        self.halfmove_clock = undo.halfmove_clock;
        self.hash = undo.hash;
    }

    // --- Make / Unmake Move Otimizado -----------------------------------

    pub fn make_move(&mut self, mv: Move) -> Undo {
        let z = zobrist::keys();
        let us = self.side;
        let them = us.opponent();
        let from = mv.from;
        let to = mv.to;
        let moving = self.piece_on(from).expect("sem peça na casa de origem");

        let undo = Undo {
            captured: None,
            castling: self.castling,
            en_passant: self.en_passant,
            halfmove_clock: self.halfmove_clock,
            hash: self.hash,
        };
        let mut captured: Option<Piece> = None;

        if let Some(ep) = self.en_passant {
            self.hash ^= z.en_passant[ep.file() as usize];
        }
        self.en_passant = None;

        self.halfmove_clock += 1;
        if moving.kind == PieceType::Pawn {
            self.halfmove_clock = 0;
        }

        match mv.flag {
            MoveFlag::Quiet | MoveFlag::DoublePawnPush => {
                if moving.kind == PieceType::King {
                    self.move_king(us, from, to);
                } else {
                    self.move_piece(us, moving.kind, from, to);
                }

                if mv.flag == MoveFlag::DoublePawnPush {
                    let ep_sq = Square(((from.0 as i8 + to.0 as i8) / 2) as u8);
                    self.en_passant = Some(ep_sq);
                    self.hash ^= z.en_passant[ep_sq.file() as usize];
                }
            }
            MoveFlag::Capture => {
                let cap = self.piece_on(to).expect("sem peça para capturar");
                captured = Some(cap);
                self.halfmove_clock = 0;
                self.remove_piece(them, cap.kind, to);

                if moving.kind == PieceType::King {
                    self.move_king(us, from, to);
                } else {
                    self.move_piece(us, moving.kind, from, to);
                }
            }
            MoveFlag::EnPassant => {
                let cap_sq = Square::from_file_rank(to.file(), from.rank());
                captured = Some(Piece::new(them, PieceType::Pawn));
                self.halfmove_clock = 0;
                self.remove_piece(them, PieceType::Pawn, cap_sq);
                self.move_piece(us, PieceType::Pawn, from, to);
            }
            MoveFlag::KingCastle => {
                self.move_king(us, from, to);
                let (rook_from, rook_to) = match us {
                    Color::White => (Square(7), Square(5)),
                    Color::Black => (Square(63), Square(61)),
                };
                self.move_piece(us, PieceType::Rook, rook_from, rook_to);
            }
            MoveFlag::QueenCastle => {
                self.move_king(us, from, to);
                let (rook_from, rook_to) = match us {
                    Color::White => (Square(0), Square(3)),
                    Color::Black => (Square(56), Square(59)),
                };
                self.move_piece(us, PieceType::Rook, rook_from, rook_to);
            }
            MoveFlag::Promotion(promo) => {
                self.remove_piece(us, PieceType::Pawn, from);
                self.add_piece(us, promo, to);
            }
            MoveFlag::PromotionCapture(promo) => {
                let cap = self.piece_on(to).expect("sem peça para capturar na promoção");
                captured = Some(cap);
                self.halfmove_clock = 0;
                self.remove_piece(them, cap.kind, to);
                self.remove_piece(us, PieceType::Pawn, from);
                self.add_piece(us, promo, to);
            }
        }

        // Atualização dos direitos de roque
        self.hash ^= z.castling[self.castling as usize];
        self.castling &= castle_rights_mask(from) & castle_rights_mask(to);
        self.hash ^= z.castling[self.castling as usize];

        // Troca o lado de jogar
        self.side = them;
        self.hash ^= z.side;
        if us == Color::Black {
            self.fullmove += 1;
        }

        let mut undo = undo;
        undo.captured = captured;
        self.history.push(self.hash);
        undo
    }

    pub fn unmake_move(&mut self, mv: Move, undo: Undo) {
        self.history.pop();
        let them = self.side;
        let us = them.opponent();
        self.side = us;
        if us == Color::Black {
            self.fullmove -= 1;
        }
        let from = mv.from;
        let to = mv.to;

        let moving = self.piece_on(to).or_else(|| {
            if matches!(mv.flag, MoveFlag::Promotion(_) | MoveFlag::PromotionCapture(_)) {
                Some(Piece::new(us, PieceType::Pawn))
            } else {
                None
            }
        }).expect("nenhuma peça no destino durante unmake");

        match mv.flag {
            MoveFlag::Quiet | MoveFlag::DoublePawnPush => {
                if moving.kind == PieceType::King {
                    self.move_king(us, to, from);
                } else {
                    self.move_piece(us, moving.kind, to, from);
                }
            }
            MoveFlag::Capture => {
                if moving.kind == PieceType::King {
                    self.move_king(us, to, from);
                } else {
                    self.move_piece(us, moving.kind, to, from);
                }
                if let Some(cap) = undo.captured {
                    self.add_piece(them, cap.kind, to);
                }
            }
            MoveFlag::EnPassant => {
                self.move_piece(us, PieceType::Pawn, to, from);
                let cap_sq = Square::from_file_rank(to.file(), from.rank());
                self.add_piece(them, PieceType::Pawn, cap_sq);
            }
            MoveFlag::KingCastle => {
                let (rook_from, rook_to) = match us {
                    Color::White => (Square(7), Square(5)),
                    Color::Black => (Square(63), Square(61)),
                };
                self.move_piece(us, PieceType::Rook, rook_to, rook_from);
                self.move_king(us, to, from);
            }
            MoveFlag::QueenCastle => {
                let (rook_from, rook_to) = match us {
                    Color::White => (Square(0), Square(3)),
                    Color::Black => (Square(56), Square(59)),
                };
                self.move_piece(us, PieceType::Rook, rook_to, rook_from);
                self.move_king(us, to, from);
            }
            MoveFlag::Promotion(promo) => {
                self.remove_piece(us, promo, to);
                self.add_piece(us, PieceType::Pawn, from);
            }
            MoveFlag::PromotionCapture(promo) => {
                self.remove_piece(us, promo, to);
                self.add_piece(us, PieceType::Pawn, from);
                if let Some(cap) = undo.captured {
                    self.add_piece(them, cap.kind, to);
                }
            }
        }

        self.castling = undo.castling;
        self.en_passant = undo.en_passant;
        self.halfmove_clock = undo.halfmove_clock;
        self.hash = undo.hash;
    }

    #[inline(always)]
    fn move_king(&mut self, color: Color, from: Square, to: Square) {
        let bb_from = from.bb();
        let bb_to = to.bb();

        self.pieces[color.index()][PieceType::King.index()] ^= bb_from | bb_to;
        self.color_bb[color.index()] ^= bb_from | bb_to;
        self.occupancy ^= bb_from | bb_to;
        self.mailbox[from.index()] = None;
        self.mailbox[to.index()] = Some(Piece::new(color, PieceType::King));

        self.hash ^= zobrist::keys().piece_key(color, PieceType::King, from);
        self.hash ^= zobrist::keys().piece_key(color, PieceType::King, to);
    }

    // --- FEN & Auxiliares ------------------------------------------------

    pub fn from_fen(fen: &str) -> Result<Board, String> {
        let mut board = Board::empty();
        let parts: Vec<&str> = fen.split_whitespace().collect();
        if parts.len() < 4 {
            return Err(format!("FEN inválido: esperado 4+ campos, obtido {}", parts.len()));
        }

        let mut rank: i32 = 7;
        let mut file: i32 = 0;
        for c in parts[0].chars() {
            match c {
                '/' => {
                    rank -= 1;
                    file = 0;
                }
                '1'..='8' => file += c.to_digit(10).unwrap() as i32,
                _ => {
                    let piece = Piece::from_char(c).ok_or_else(|| format!("peça inválida '{}'", c))?;
                    let sq = Square::from_file_rank(file as u8, rank as u8);
                    board.add_piece(piece.color, piece.kind, sq);
                    file += 1;
                }
            }
        }

        board.side = match parts[1] {
            "w" => Color::White,
            "b" => Color::Black,
            _ => return Err("lado inválido".to_string()),
        };

        board.castling = 0;
        if parts[2] != "-" {
            for c in parts[2].chars() {
                match c {
                    'K' => board.castling |= CASTLE_WK,
                    'Q' => board.castling |= CASTLE_WQ,
                    'k' => board.castling |= CASTLE_BK,
                    'q' => board.castling |= CASTLE_BQ,
                    _ => return Err(format!("char roque inválido '{}'", c)),
                }
            }
        }

        board.en_passant = if parts[3] == "-" {
            None
        } else {
            Some(Square::from_algebraic(parts[3]).ok_or("casa e.p. inválida")?)
        };

        board.halfmove_clock = parts.get(4).and_then(|s| s.parse().ok()).unwrap_or(0);
        board.fullmove = parts.get(5).and_then(|s| s.parse().ok()).unwrap_or(1);

        board.hash = board.compute_hash();
        board.history.clear();
        board.history.push(board.hash);

        Ok(board)
    }

    pub fn to_fen(&self) -> String {
        let mut fen = String::new();
        for rank in (0..8).rev() {
            let mut empty = 0;
            for file in 0..8 {
                let sq = Square::from_file_rank(file, rank);
                match self.piece_on(sq) {
                    Some(p) => {
                        if empty > 0 {
                            fen.push_str(&empty.to_string());
                            empty = 0;
                        }
                        fen.push(p.to_char());
                    }
                    None => empty += 1,
                }
            }
            if empty > 0 {
                fen.push_str(&empty.to_string());
            }
            if rank > 0 {
                fen.push('/');
            }
        }
        fen.push(' ');
        fen.push(if self.side == Color::White { 'w' } else { 'b' });
        fen.push(' ');
        if self.castling == 0 {
            fen.push('-');
        } else {
            if self.castling & CASTLE_WK != 0 { fen.push('K'); }
            if self.castling & CASTLE_WQ != 0 { fen.push('Q'); }
            if self.castling & CASTLE_BK != 0 { fen.push('k'); }
            if self.castling & CASTLE_BQ != 0 { fen.push('q'); }
        }
        fen.push(' ');
        match self.en_passant {
            Some(sq) => fen.push_str(&sq.to_string()),
            None => fen.push('-'),
        }
        fen.push_str(&format!(" {} {}", self.halfmove_clock, self.fullmove));
        fen
    }

    fn compute_hash(&self) -> u64 {
        let z = zobrist::keys();
        let mut hash = 0u64;
        for sq in 0..64u8 {
            if let Some(p) = self.mailbox[sq as usize] {
                hash ^= z.piece_key(p.color, p.kind, Square(sq));
            }
        }
        hash ^= z.castling[self.castling as usize];
        if let Some(ep) = self.en_passant {
            hash ^= z.en_passant[ep.file() as usize];
        }
        if self.side == Color::Black {
            hash ^= z.side;
        }
        hash
    }

    pub fn is_attacked(&self, sq: Square, color: Color) -> bool {
        let occ = self.occupancy;
        if attacks::pawn_attacks(color.opponent(), sq) & self.pieces_of(color, PieceType::Pawn) != 0 {
            return true;
        }
        if attacks::knight_attacks(sq) & self.pieces_of(color, PieceType::Knight) != 0 {
            return true;
        }
        if attacks::king_attacks(sq) & self.pieces_of(color, PieceType::King) != 0 {
            return true;
        }
        let bishops = self.pieces_of(color, PieceType::Bishop) | self.pieces_of(color, PieceType::Queen);
        if attacks::bishop_attacks(sq, occ) & bishops != 0 {
            return true;
        }
        let rooks = self.pieces_of(color, PieceType::Rook) | self.pieces_of(color, PieceType::Queen);
        if attacks::rook_attacks(sq, occ) & rooks != 0 {
            return true;
        }
        false
    }

    /// Retorna bitboard com peças da `color` que estão absolutamente cravadas ao rei.
    pub fn pinned_pieces(&self, color: Color) -> Bitboard {
        let mut pinned = 0;
        let king_sq = self.king_square(color);
        let opp = color.opponent();
        
        let opp_rq = self.pieces_of(opp, PieceType::Rook) | self.pieces_of(opp, PieceType::Queen);
        let opp_bq = self.pieces_of(opp, PieceType::Bishop) | self.pieces_of(opp, PieceType::Queen);
        
        let king_rook_attacks = attacks::rook_attacks(king_sq, 0);
        let rook_pinners = opp_rq & king_rook_attacks;
        for pinner_sq in crate::bitboard::iter(rook_pinners) {
            let ray = attacks::rook_attacks(king_sq, 0) & attacks::rook_attacks(pinner_sq, 0);
            let blockers = ray & self.occupancy;
            if blockers.count_ones() == 1 {
                let blocker_sq = crate::bitboard::lsb(blockers);
                if (1u64 << blocker_sq.index()) & self.color_bb[color.index()] != 0 {
                    pinned |= 1u64 << blocker_sq.index();
                }
            }
        }

        let king_bishop_attacks = attacks::bishop_attacks(king_sq, 0);
        let bishop_pinners = opp_bq & king_bishop_attacks;
        for pinner_sq in crate::bitboard::iter(bishop_pinners) {
            let ray = attacks::bishop_attacks(king_sq, 0) & attacks::bishop_attacks(pinner_sq, 0);
            let blockers = ray & self.occupancy;
            if blockers.count_ones() == 1 {
                let blocker_sq = crate::bitboard::lsb(blockers);
                if (1u64 << blocker_sq.index()) & self.color_bb[color.index()] != 0 {
                    pinned |= 1u64 << blocker_sq.index();
                }
            }
        }

        pinned
    }

    // --- Acesso Básico ------------------------------------------------

    #[inline(always)]
    pub fn in_check(&self, color: Color) -> bool {
        self.is_attacked(self.king_square(color), color.opponent())
    }

    pub fn make_null_move(&mut self) -> Undo {
        let z = zobrist::keys();
        let undo = Undo {
            captured: None,
            castling: self.castling,
            en_passant: self.en_passant,
            halfmove_clock: self.halfmove_clock,
            hash: self.hash,
        };
        if let Some(ep) = self.en_passant {
            self.hash ^= z.en_passant[ep.file() as usize];
        }
        self.en_passant = None;
        self.side = self.side.opponent();
        self.hash ^= z.side;
        self.history.push(self.hash);
        undo
    }

    pub fn unmake_null_move(&mut self, undo: Undo) {
        self.history.pop();
        self.side = self.side.opponent();
        self.castling = undo.castling;
        self.en_passant = undo.en_passant;
        self.halfmove_clock = undo.halfmove_clock;
        self.hash = undo.hash;
    }

    pub fn is_draw(&self) -> bool {
        if self.halfmove_clock >= 100 {
            return true;
        }
        let n = self.history.len();
        if n < 2 {
            return false;
        }
        let mut count = 0;
        let limit = self.halfmove_clock as usize;
        let start = n.saturating_sub(limit + 1);
        for &h in self.history[start..n - 1].iter() {
            if h == self.hash {
                count += 1;
                // --- CORREÇÃO DO EMPATE PREMATURO ---
                if count >= 1 {
                    return true;
                }
            }
        }
        false
    }
}

#[inline(always)]
fn castle_rights_mask(sq: Square) -> u8 {
    match sq.0 {
        0 => !CASTLE_WQ,
        4 => !(CASTLE_WK | CASTLE_WQ),
        7 => !CASTLE_WK,
        56 => !CASTLE_BQ,
        60 => !(CASTLE_BK | CASTLE_BQ),
        63 => !CASTLE_BK,
        _ => 0xFF,
    }
}
