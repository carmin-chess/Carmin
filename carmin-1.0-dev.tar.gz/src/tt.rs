//! A lockless 2-bucket compact Transposition Table with age tracking and move retention.
//! Safe for Lazy SMP multi-threading.

use crate::types::Move;
use std::sync::atomic::{AtomicU64, AtomicU8, Ordering};

#[derive(Clone, Copy, PartialEq, Eq, Debug)]
#[repr(u8)]
pub enum Bound {
    Exact = 0,
    Lower = 1,
    Upper = 2,
}

impl Bound {
    pub fn from_u8(b: u8) -> Self {
        match b {
            0 => Bound::Exact,
            1 => Bound::Lower,
            2 => Bound::Upper,
            _ => Bound::Upper,
        }
    }
}

pub struct TtEntry {
    /// 64-bit inteiros para a chave evitam colisões matemáticas em buscas muito profundas.
    pub key: AtomicU64,
    /// data: move (16 bits) | score (16 bits) | depth (8 bits) | bound (8 bits) | age (8 bits)
    pub data: AtomicU64,
}

impl TtEntry {
    pub fn new() -> Self {
        TtEntry {
            key: AtomicU64::new(0),
            data: AtomicU64::new(0),
        }
    }
}

#[derive(Clone, Copy)]
pub struct TtLookup {
    pub key: u64,
    pub depth: i32,
    pub score: i32,
    pub bound: Bound,
    pub best: Option<Move>,
}

struct TtCluster {
    entries: [TtEntry; 2],
}

impl TtCluster {
    fn new() -> Self {
        TtCluster {
            entries: [TtEntry::new(), TtEntry::new()],
        }
    }
}

pub struct TranspositionTable {
    clusters: Vec<TtCluster>,
    mask: usize,
    pub age: AtomicU8,
}

impl TranspositionTable {
    /// Create a table of `mb` megabytes rounded down to power of 2 clusters.
    pub fn new(mb: usize) -> TranspositionTable {
        let bytes = mb * 1024 * 1024;
        let cluster_size = std::mem::size_of::<TtCluster>();
        let mut count = (bytes / cluster_size).max(1);
        count = count.next_power_of_two();
        
        let mut clusters = Vec::with_capacity(count);
        for _ in 0..count {
            clusters.push(TtCluster::new());
        }
        
        TranspositionTable {
            clusters,
            mask: count - 1,
            age: AtomicU8::new(0),
        }
    }

    pub fn new_search(&self) {
        self.age.fetch_add(1, Ordering::Relaxed);
    }

    pub fn clear(&self) {
        for c in self.clusters.iter() {
            for entry in &c.entries {
                entry.key.store(0, Ordering::Relaxed);
                entry.data.store(0, Ordering::Relaxed);
            }
        }
        self.age.store(0, Ordering::Relaxed);
    }

    #[inline]
    fn index(&self, key: u64) -> usize {
        (key as usize) & self.mask
    }

    /// Prefetch da cache line do cluster correspondente a `key`.
    ///
    /// A TT tem tipicamente dezenas/centenas de MB — muito maior que a
    /// cache L2/L3 — então cada probe() é, na prática, quase sempre um
    /// cache miss (~100-300 ciclos de stall esperando a RAM). O hash da
    /// posição filha já é conhecido logo depois de `board.make_move()`,
    /// bem antes do probe() de verdade acontecer lá dentro do próximo
    /// `negamax`/`quiescence` (só depois de check_stop, cálculo de
    /// in_check, etc). Emitir o prefetch nesse intervalo dá tempo da
    /// memória chegar no cache ANTES do probe precisar dela — decisão
    /// de busca não muda em nada, só esconde latência de memória.
    #[inline]
    pub fn prefetch(&self, key: u64) {
        let cluster = &self.clusters[self.index(key)];
        let ptr = cluster as *const TtCluster as *const i8;

        #[cfg(target_arch = "x86_64")]
        unsafe {
            std::arch::x86_64::_mm_prefetch(ptr, std::arch::x86_64::_MM_HINT_T0);
        }

        #[cfg(target_arch = "aarch64")]
        unsafe {
            // aarch64 não tem um intrínseco estável de prefetch em std;
            // um dereference "morto" ainda emite o padrão de acesso pro
            // prefetcher de hardware pegar, sem custo de correção.
            std::ptr::read_volatile(ptr);
        }

        // Em outras arquiteturas, sem prefetch — apenas no-op seguro.
        #[cfg(not(any(target_arch = "x86_64", target_arch = "aarch64")))]
        {
            let _ = ptr;
        }
    }

    pub fn probe(&self, key: u64) -> Option<TtLookup> {
        let cluster = &self.clusters[self.index(key)];

        for entry in &cluster.entries {
            // A chave é gravada como (key ^ data). Lendo os dois campos (em
            // qualquer ordem) e conferindo `stored_key ^ data == key`, uma
            // leitura "torn" (metade de uma escrita antiga, metade de uma
            // nova) quase certamente falha essa checagem, em vez de passar
            // silenciosamente como acontecia comparando a chave crua duas
            // vezes.
            let stored_key = entry.key.load(Ordering::Relaxed);
            let data = entry.data.load(Ordering::Relaxed);

            if stored_key ^ data == key {
                // Leitura segura garantida, desempacotando os bits
                let best_move_u16 = (data & 0xFFFF) as u16;
                let score = ((data >> 16) & 0xFFFF) as i16 as i32;
                let depth = ((data >> 32) & 0xFF) as i8 as i32;
                let bound_u8 = ((data >> 40) & 0xFF) as u8;
                
                return Some(TtLookup {
                    key,
                    depth,
                    score,
                    bound: Bound::from_u8(bound_u8),
                    best: Move::decode_u16(best_move_u16),
                });
            }
        }
        None
    }

    pub fn store(
        &self,
        key: u64,
        depth: i32,
        score: i32,
        bound: Bound,
        best: Option<Move>,
    ) {
        let idx = self.index(key);
        let cluster = &self.clusters[idx];
        let new_mv = best.map(|m| m.encode_u16()).unwrap_or(0);
        let current_age = self.age.load(Ordering::Relaxed);

        let mut final_mv = new_mv;

        // 1. Tenta encontrar uma entrada existente com a mesma chave para atualizá-la
        //    (chave gravada como key ^ data; ver nota em probe())
        for entry in &cluster.entries {
            let stored_key = entry.key.load(Ordering::Relaxed);
            let data = entry.data.load(Ordering::Relaxed);

            if stored_key ^ data == key {
                let entry_depth = ((data >> 32) & 0xFF) as i8 as i32;
                let entry_age = ((data >> 48) & 0xFF) as u8;
                let prev_mv = (data & 0xFFFF) as u16;

                // Mantém o lance da iteração anterior se o novo lance for nulo
                if final_mv == 0 {
                    final_mv = prev_mv;
                }

                if depth >= entry_depth || bound == Bound::Exact || entry_age != current_age {
                    let packed = (final_mv as u64)
                        | (((score.clamp(-32767, 32767) as i16 as u16) as u64) << 16)
                        | (((depth.clamp(-128, 127) as i8 as u8) as u64) << 32)
                        | (((bound as u8) as u64) << 40)
                        | (((current_age as u8) as u64) << 48);

                    // ORDEM DE ESCRITA: Gravar dados PRIMEIRO, a chave (key ^ data) POR ÚLTIMO
                    entry.data.store(packed, Ordering::Relaxed);
                    entry.key.store(key ^ packed, Ordering::Relaxed);
                }
                return;
            }
        }

        // 2. Se não encontrou uma entrada existente, escolhe qual substituir
        let mut replace_idx = 0;
        let mut min_score = i32::MAX;

        for (i, entry) in cluster.entries.iter().enumerate() {
            let k = entry.key.load(Ordering::Relaxed);
            
            if k == 0 { 
                // Entrada completamente vazia, usa ela imediatamente
                replace_idx = i;
                break;
            }

            let d = entry.data.load(Ordering::Relaxed);
            let entry_age = ((d >> 48) & 0xFF) as u8;
            let entry_depth = ((d >> 32) & 0xFF) as i8 as i32;

            // Prioridade máxima de substituição para posições velhas
            let mut replace_score = entry_depth;
            if entry_age != current_age {
                replace_score -= 256; 
            }

            if replace_score < min_score {
                min_score = replace_score;
                replace_idx = i;
            }
        }

        let packed = (new_mv as u64)
            | (((score.clamp(-32767, 32767) as i16 as u16) as u64) << 16)
            | (((depth.clamp(-128, 127) as i8 as u8) as u64) << 32)
            | (((bound as u8) as u64) << 40)
            | (((current_age as u8) as u64) << 48);

        // ORDEM DE ESCRITA: Gravar dados PRIMEIRO, a chave (key ^ data) POR ÚLTIMO
        cluster.entries[replace_idx].data.store(packed, Ordering::Relaxed);
        cluster.entries[replace_idx].key.store(key ^ packed, Ordering::Relaxed);
    }
}
