//! Negamax Alpha-Beta search framework.

use crate::board::Board;
use crate::eval::{evaluate, MATE, MATE_IN_MAX};
use crate::movepick::MovePicker;
use crate::search::params::*;
use crate::search::Searcher;
use crate::search::see::see_ge;
use crate::tt::Bound;
use crate::types::{Move, MoveFlag};

#[inline]
pub fn tt_score_to(score: i32, ply: usize) -> i32 {
    if score >= MATE_IN_MAX {
        score + ply as i32
    } else if score <= -MATE_IN_MAX {
        score - ply as i32
    } else {
        score
    }
}

#[inline]
pub fn tt_score_from(score: i32, ply: usize) -> i32 {
    if score >= MATE_IN_MAX {
        score - ply as i32
    } else if score <= -MATE_IN_MAX {
        score + ply as i32
    } else {
        score
    }
}

impl Searcher {
    pub fn negamax(
        &mut self,
        board: &mut Board,
        mut depth: i32,
        mut alpha: i32,
        beta: i32,
        ply: usize,
        excluded_move: Option<Move>,
    ) -> i32 {
        self.check_stop();

        if self.stop {
            return 0;
        }

        self.pv_table.init_ply(ply);

        let root = ply == 0;
        let in_check = board.in_check(board.side);

        // ------------------------------------------------------------------
        // Limite de profundidade
        // ------------------------------------------------------------------

        if ply >= MAX_PLY - 1 {
            return evaluate(board);
        }

        // ------------------------------------------------------------------
        // Extensão em xeque
        // ------------------------------------------------------------------

        if in_check {
            depth += 1;
        }

        // ------------------------------------------------------------------
        // Quiescence
        // ------------------------------------------------------------------

        if depth <= 0 {
            return self.quiescence(board, alpha, beta, ply);
        }

        self.stats.record_node();
        self.nodes += 1;

        // ------------------------------------------------------------------
        // Draw / mate distance
        // ------------------------------------------------------------------

        if !root {
            if board.is_draw() {
                return -self.contempt;
            }

            let mate_alpha = alpha.max(-MATE + ply as i32);
            let mate_beta = beta.min(MATE - ply as i32 - 1);

            if mate_alpha >= mate_beta {
                return mate_alpha;
            }

            alpha = mate_alpha;
        }

        let is_pv = beta - alpha > 1;

        // ------------------------------------------------------------------
        // Transposition Table
        // ------------------------------------------------------------------

        let mut tt_move: Option<Move> = None;

        if !cfg!(feature = "disable_tt") {
            if let Some(entry) = self.tt.probe(board.hash) {
                self.stats.record_tt_hit();

                tt_move = entry.best;

                let tt_score = tt_score_from(entry.score, ply);

                if !root
                    && !is_pv
                    && entry.depth >= depth
                    && excluded_move.is_none()
                {
                    match entry.bound {
                        Bound::Exact => {
                            self.stats.record_tt_cutoff();
                            return tt_score;
                        }

                        Bound::Lower if tt_score >= beta => {
                            self.stats.record_tt_cutoff();
                            return tt_score;
                        }

                        Bound::Upper if tt_score <= alpha => {
                            self.stats.record_tt_cutoff();
                            return tt_score;
                        }

                        _ => {}
                    }
                }
            }
        }

        // ------------------------------------------------------------------
        // Static evaluation + correction history
        // ------------------------------------------------------------------

        let static_eval = evaluate(board);

        let correction = self.correction_history
            [board.side.index()]
            [(board.hash & 16383) as usize]
            / CORRECTION_GRAVITY_DIVISOR;

        let eval = static_eval + correction;

        if ply < MAX_PLY {
            self.eval_stack[ply] = eval;
        }

        // ------------------------------------------------------------------
        // Razoring
        // ------------------------------------------------------------------

        if !is_pv
            && !in_check
            && depth <= 8
            && excluded_move.is_none()
            && eval.abs() < MATE_IN_MAX
        {
            let razoring_margin = 250 * depth;

            if eval + razoring_margin <= alpha {
                let qscore = self.quiescence(
                    board,
                    alpha - razoring_margin,
                    alpha,
                    ply,
                );

                if qscore <= alpha {
                    return qscore;
                }
            }
        }

        // ------------------------------------------------------------------
        // Reverse Futility Pruning
        // ------------------------------------------------------------------

        if !is_pv
            && !in_check
            && depth <= 8
            && excluded_move.is_none()
            && eval.abs() < MATE_IN_MAX
        {
            let rfp_margin = 140 * depth;

            if eval - rfp_margin >= beta {
                return eval - rfp_margin;
            }
        }

        // ------------------------------------------------------------------
        // Null Move Pruning
        // ------------------------------------------------------------------

        if !is_pv
            && !in_check
            && depth >= 3
            && eval >= beta
            && excluded_move.is_none()
            && eval.abs() < MATE_IN_MAX
            && crate::search::see::has_non_pawn_material(board, board.side)
        {
            let eval_bonus = ((eval - beta) / 200).clamp(0, 3);
            let reduction = 3 + depth / 6 + eval_bonus;
            let null_depth = depth - 1 - reduction;

            if null_depth >= 1 {
                let undo_null = board.make_null_move();

                let null_score = -self.negamax(
                    board,
                    null_depth,
                    -beta,
                    -beta + 1,
                    ply + 1,
                    None,
                );

                board.unmake_null_move(undo_null);

                if self.stop {
                    return 0;
                }

                if null_score >= beta {
                    return if null_score >= MATE_IN_MAX {
                        beta
                    } else {
                        null_score
                    };
                }
            }
        }

        // ------------------------------------------------------------------
        // ProbCut
        // ------------------------------------------------------------------

        if !is_pv
            && !in_check
            && depth >= 5
            && excluded_move.is_none()
            && eval.abs() < MATE_IN_MAX
        {
            let probcut_margin = 80 + 20 * depth;
            let probcut_beta = beta + probcut_margin;

            let probcut_depth = depth - 3;

            if probcut_depth >= 1 {
                let mut pc_picker = MovePicker::new(
                    board,
                    tt_move,
                    killers_for(self, ply),
                    counter_for(self, ply),
                    ply,
                );

                let mut pc_count = 0usize;

                while let Some(pc_mv) = pc_picker.next(board, self) {
                    if !pc_mv.is_capture() && pc_mv.promotion().is_none() {
                        continue;
                    }

                    if !see_ge(board, pc_mv, 0) {
                        continue;
                    }

                    let undo = board.make_move(pc_mv);

                    let legal =
                        !board.in_check(board.side.opponent());

                    if legal {
                        let pc_score = -self.negamax(
                            board,
                            probcut_depth,
                            -probcut_beta,
                            -probcut_beta + 1,
                            ply + 1,
                            None,
                        );

                        board.unmake_move(pc_mv, undo);

                        if self.stop {
                            return 0;
                        }

                        if pc_score >= probcut_beta {
                            return pc_score;
                        }
                    } else {
                        board.unmake_move(pc_mv, undo);
                    }

                    pc_count += 1;

                    if pc_count >= 6 {
                        break;
                    }
                }
            }
        }

        // ------------------------------------------------------------------
        // IID
        // ------------------------------------------------------------------

        if is_pv
            && tt_move.is_none()
            && depth >= IID_PV_DEPTH
            && excluded_move.is_none()
        {
            let iid_depth = (depth / 2).max(1);

            let _ = self.negamax(
                board,
                iid_depth,
                alpha,
                beta,
                ply,
                None,
            );

            if self.stop {
                return 0;
            }

            if !cfg!(feature = "disable_tt") {
                if let Some(entry) = self.tt.probe(board.hash) {
                    tt_move = entry.best;
                }
            }
        }

        // ------------------------------------------------------------------
        // Move ordering
        // ------------------------------------------------------------------

        let killers = if ply < MAX_PLY {
            self.killers[ply]
        } else {
            [None; 2]
        };

        let prev_move = if ply > 0 {
            self.move_stack[ply - 1]
        } else {
            None
        };

        let counter = prev_move.and_then(|pm| {
            self.counter_moves
                [pm.from.index()]
                [pm.to.index()]
        });

        let mut picker =
            MovePicker::new(board, tt_move, killers, counter, ply);

        // ------------------------------------------------------------------
        // Search state
        // ------------------------------------------------------------------

        let mut best_score = -INF;
        let mut best_move: Option<Move> = None;

        let mut bound = Bound::Upper;

        let mut move_count: usize = 0;

        let mut searched_quiets = [None; 64];
        let mut searched_quiets_count: usize = 0;

        // ------------------------------------------------------------------
        // Continuation history
        // ------------------------------------------------------------------

        let prev1_pt_to = if prev_move.is_some() {
            Some(self.piece_stack[ply.saturating_sub(1)])
        } else {
            None
        };

        let prev_move_2 = if ply > 1 {
            self.move_stack[ply - 2]
        } else {
            None
        };

        let prev2_pt_to = if prev_move_2.is_some() {
            Some(self.piece_stack[ply.saturating_sub(2)])
        } else {
            None
        };

        // ------------------------------------------------------------------
        // Move loop
        // ------------------------------------------------------------------

        while let Some(mv) = picker.next(board, self) {
            if root && self.excluded_root_moves.contains(&mv) {
                continue;
            }

            if Some(mv) == excluded_move {
                continue;
            }

            let is_quiet =
                !mv.is_capture() && mv.promotion().is_none();

            // --------------------------------------------------------------
            // Late Move Pruning
            // --------------------------------------------------------------

            if !is_pv
                && !in_check
                && is_quiet
            {
                let d = depth.max(0) as usize;
                let lmp_threshold = LMP_BASE + LMP_SCALE * d * d;

                if move_count > lmp_threshold {
                    continue;
                }
            }

            // --------------------------------------------------------------
            // Futility Pruning
            // --------------------------------------------------------------

            if !is_pv
                && !in_check
                && is_quiet
                && depth <= 8
                && move_count > 1
                && eval.abs() < MATE_IN_MAX
            {
                let futility_margin = 150 * depth;

                if eval + futility_margin <= alpha {
                    continue;
                }
            }

            // --------------------------------------------------------------
            // SEE pruning
            // --------------------------------------------------------------

            if !is_pv
                && !in_check
                && depth <= 8
                && move_count > 1
            {
                let see_threshold = -100 * depth;

                if !see_ge(board, mv, see_threshold) {
                    continue;
                }
            }

            // --------------------------------------------------------------
            // Legalidade (executada APÓS as podas)
            // --------------------------------------------------------------

            let undo_fast = board.make_move_fast(mv);

            let is_legal =
                !board.in_check(board.side.opponent());

            board.unmake_move_fast(mv, undo_fast);

            if !is_legal {
                continue;
            }

            // --------------------------------------------------------------
            // Singular Extension
            // --------------------------------------------------------------

            let mut extension = 0;

            if !root
                && depth >= SINGULAR_MIN_DEPTH + 1
                && Some(mv) == tt_move
                && excluded_move.is_none()
            {
                if let Some(entry) = self.tt.probe(board.hash) {
                    if entry.depth >= depth - SINGULAR_TT_DEPTH_MARGIN
                        && entry.bound != Bound::Upper
                    {
                        let tt_score =
                            tt_score_from(entry.score, ply);

                        if tt_score.abs() < MATE_IN_MAX {
                            let singular_beta =
                                tt_score
                                    - SINGULAR_MARGIN_PER_PLY * depth;

                            let singular_depth =
                                (depth - 1) / 2;

                            let se_score = self.negamax(
                                board,
                                singular_depth,
                                singular_beta - 1,
                                singular_beta,
                                ply,
                                Some(mv),
                            );

                            if self.stop {
                                return 0;
                            }

                            if se_score < singular_beta {
                                extension = 1;
                            } else if singular_beta >= beta {
                                return singular_beta;
                            }
                        }
                    }
                }
            }

            // --------------------------------------------------------------
            // Stack
            // --------------------------------------------------------------

            if ply < MAX_PLY {
                self.move_stack[ply] = Some(mv);

                let pt = board
                    .piece_on(mv.from)
                    .map_or(0, |p| p.kind.index());

                self.piece_stack[ply] =
                    (pt, mv.to.index());
            }

            move_count += 1;

            // --------------------------------------------------------------
            // Fazer lance
            // --------------------------------------------------------------

            let undo = board.make_move(mv);

            self.tt.prefetch(board.hash);

            // --------------------------------------------------------------
            // PVS + LMR
            // --------------------------------------------------------------

            let score;

            if move_count == 1 {
                score = -self.negamax(
                    board,
                    depth - 1 + extension,
                    -beta,
                    -alpha,
                    ply + 1,
                    None,
                );
            } else {
                let mut reduction = 0;

                if extension == 0
                    && depth >= 2
                    && move_count > 2
                    && is_quiet
                {
                    reduction = crate::search::lmr(
                        depth as usize,
                        move_count,
                    );

                    if move_count > 3 {
                        reduction += 1;
                    }

                    if move_count > 6 {
                        reduction += 1;
                    }

                    if move_count > 10 {
                        reduction += 1;
                    }

                    if move_count > 16 {
                        reduction += 1;
                    }

                    if move_count > 24 {
                        reduction += 1;
                    }

                    reduction = reduction.clamp(
                        0,
                        depth - 2,
                    );
                }

                // ----------------------------------------------------------
                // Reduced PVS
                // ----------------------------------------------------------

                let mut pvs_score = -self.negamax(
                    board,
                    depth - 1 + extension - reduction,
                    -alpha - 1,
                    -alpha,
                    ply + 1,
                    None,
                );

                // ----------------------------------------------------------
                // LMR re-search
                // ----------------------------------------------------------

                if pvs_score > alpha && reduction > 0 {
                    pvs_score = -self.negamax(
                        board,
                        depth - 1 + extension,
                        -alpha - 1,
                        -alpha,
                        ply + 1,
                        None,
                    );
                }

                // ----------------------------------------------------------
                // Full window
                // ----------------------------------------------------------

                if pvs_score > alpha && pvs_score < beta {
                    pvs_score = -self.negamax(
                        board,
                        depth - 1 + extension,
                        -beta,
                        -alpha,
                        ply + 1,
                        None,
                    );
                }

                score = pvs_score;
            }

            board.unmake_move(mv, undo);

            // --------------------------------------------------------------
            // Stop
            // --------------------------------------------------------------

            if self.stop {
                return 0;
            }

            // --------------------------------------------------------------
            // Melhor lance
            // --------------------------------------------------------------

            if score > best_score {
                best_score = score;
                best_move = Some(mv);

                if root {
                    self.root_best_move = Some(mv);
                }
            }

            // --------------------------------------------------------------
            // Alpha
            // --------------------------------------------------------------

            if score > alpha {
                alpha = score;
                bound = Bound::Exact;

                self.pv_table.update(ply, mv);
            }

            // --------------------------------------------------------------
            // Beta cutoff
            // --------------------------------------------------------------

            if alpha >= beta {
                bound = Bound::Lower;

                self.stats.record_cutoff(move_count);

                // ----------------------------------------------------------
                // Quiet history
                // ----------------------------------------------------------

                if is_quiet {
                    self.update_killers(mv, ply);

                    if let Some(pm) = prev_move {
                        self.counter_moves
                            [pm.from.index()]
                            [pm.to.index()] = Some(mv);
                    }

                    if searched_quiets_count < 64 {
                        searched_quiets
                            [searched_quiets_count] = Some(mv);

                        searched_quiets_count += 1;
                    }

                    self.update_history_with_gravity(
                        board,
                        mv,
                        board
                            .piece_on(mv.from)
                            .map_or(0, |p| p.kind.index()),
                        depth,
                        prev1_pt_to,
                        prev2_pt_to,
                        &searched_quiets[..searched_quiets_count],
                    );
                }

                // ----------------------------------------------------------
                // Capture history
                // ----------------------------------------------------------

                else {
                    let attacker = board
                        .piece_on(mv.from)
                        .map(|p| p.kind.index())
                        .unwrap_or(0);

                    let victim = match mv.flag {
                        MoveFlag::EnPassant => 0,

                        _ => board
                            .piece_on(mv.to)
                            .map(|p| p.kind.index())
                            .unwrap_or(0),
                    };

                    let bonus =
                        (depth * depth)
                            .min(HISTORY_BONUS_MAX);

                    let cap_entry =
                        &mut self.capture_history
                            [attacker]
                            [mv.to.index()]
                            [victim];

                    *cap_entry =
                        (*cap_entry + bonus)
                            .min(HISTORY_MAX);
                }

                break;
            }

            // --------------------------------------------------------------
            // Guardar quiet pesquisado
            // --------------------------------------------------------------

            if is_quiet && searched_quiets_count < 64 {
                searched_quiets
                    [searched_quiets_count] = Some(mv);

                searched_quiets_count += 1;
            }
        }

        // ------------------------------------------------------------------
        // Nenhum lance legal
        // ------------------------------------------------------------------

        if move_count == 0 {
            return if in_check {
                -MATE + ply as i32
            } else {
                0
            };
        }

        // ------------------------------------------------------------------
        // Store
        // ------------------------------------------------------------------

        let stored = best_score;

        if excluded_move.is_none() {
            if !cfg!(feature = "disable_tt") {
                self.tt.store(
                    board.hash,
                    depth,
                    tt_score_to(stored, ply),
                    bound,
                    best_move,
                );
            }

            // --------------------------------------------------------------
            // Correction history
            // --------------------------------------------------------------

            if depth >= 6
                && stored.abs() < MATE_IN_MAX
                && !in_check
            {
                let side = board.side.index();

                let idx =
                    (board.hash & 16383) as usize;

                let diff =
                    stored - static_eval;

                let entry =
                    &mut self.correction_history
                        [side]
                        [idx];

                *entry += (
                    (diff * CORRECTION_GRAVITY_DIVISOR)
                        - *entry
                ).clamp(
                    -CORRECTION_MAX_OFFSET,
                    CORRECTION_MAX_OFFSET,
                );
            }
        }

        best_score
    }
}

#[inline]
fn killers_for(
    searcher: &Searcher,
    ply: usize,
) -> [Option<Move>; 2] {
    if ply < MAX_PLY {
        searcher.killers[ply]
    } else {
        [None; 2]
    }
}

#[inline]
fn counter_for(
    searcher: &Searcher,
    ply: usize,
) -> Option<Move> {
    if ply == 0 {
        return None;
    }

    let prev = searcher.move_stack[ply - 1]?;

    searcher.counter_moves
        [prev.from.index()]
        [prev.to.index()]
}
