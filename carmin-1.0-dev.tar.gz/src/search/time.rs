//! Time Management and Search Limits module.
//!
//! Controls search duration based on UCI search parameters (`wtime`, `btime`,
//! `winc`, `binc`, `movestogo`, `movetime`, `infinite`, etc.).
//!
//! Provides hard time limits (absolute stop) and soft time limits (target completion duration).

use std::time::{Duration, Instant};
use crate::search::params::{MIN_TIME_ALLOC_MS, TIME_SAFETY_MARGIN_MS};
use crate::types::Color;

/// Search limits container specified by UCI commands.
#[derive(Debug, Clone, Default)]
pub struct SearchLimits {
    /// Target maximum search depth in plies.
    pub depth: Option<i32>,
    /// Fixed maximum time per move in milliseconds (`movetime`).
    pub movetime: Option<u64>,
    /// Remaining time for White in milliseconds.
    pub wtime: Option<u64>,
    /// Remaining time for Black in milliseconds.
    pub btime: Option<u64>,
    /// Increment per move for White in milliseconds.
    pub winc: Option<u64>,
    /// Increment per move for Black in milliseconds.
    pub binc: Option<u64>,
    /// Moves until next time control checkpoint (`movestogo`).
    pub movestogo: Option<u64>,
    /// Search infinitely until an explicit `stop` command is received.
    pub infinite: bool,
    /// Maximum nodes limit (`nodes`).
    pub nodes: Option<u64>,
    pub ponder: bool,
}

/// Time control manager responsible for calculating time allocations and polling elapsed time.
#[derive(Debug, Clone)]
pub struct TimeManager {
    pub start_time: Instant,
    pub hard_limit: Option<Duration>,
    pub soft_limit: Option<Duration>,
    pub max_nodes: Option<u64>,
}

impl Default for TimeManager {
    fn default() -> Self {
        Self::new()
    }
}

impl TimeManager {
    /// Create a default TimeManager initialized at `Instant::now()`.
    pub fn new() -> Self {
        Self {
            start_time: Instant::now(),
            hard_limit: None,
            soft_limit: None,
            max_nodes: None,
        }
    }

    /// Initialize time limits for a search given side to move and UCI search limits.
    pub fn init(&mut self, side: Color, limits: &SearchLimits) {
        self.start_time = Instant::now();
        self.max_nodes = limits.nodes;
        let (hard, soft) = compute_time_limits(side, limits);
        self.hard_limit = hard;
        self.soft_limit = soft;
    }

    /// Check if hard time limit or node limit has expired.
    #[inline]
    pub fn is_expired(&self, nodes: u64) -> bool {
        if let Some(max_n) = self.max_nodes {
            if nodes >= max_n {
                return true;
            }
        }
        if let Some(hard) = self.hard_limit {
            if self.start_time.elapsed() >= hard {
                return true;
            }
        }
        false
    }

    /// Check if soft target time limit has been exceeded.
    #[inline]
    pub fn is_soft_expired(&self) -> bool {
        if let Some(soft) = self.soft_limit {
            self.start_time.elapsed() >= soft
        } else {
            false
        }
    }

    /// Get total elapsed time since search start.
    #[inline]
    pub fn elapsed(&self) -> Duration {
        self.start_time.elapsed()
    }
}

/// Computes (hard_limit, soft_limit) durations for the active search.
pub fn compute_time_limits(
    side: Color,
    limits: &SearchLimits,
) -> (Option<Duration>, Option<Duration>) {
    if limits.infinite {
        return (None, None);
    }

    if let Some(mt) = limits.movetime {
        let hard = Duration::from_millis(
            mt.saturating_sub(TIME_SAFETY_MARGIN_MS)
                .max(MIN_TIME_ALLOC_MS),
        );
        return (Some(hard), Some(hard));
    }

    let (time, inc) = match side {
        Color::White => (limits.wtime, limits.winc.unwrap_or(0)),
        Color::Black => (limits.btime, limits.binc.unwrap_or(0)),
    };

    let time = match time {
        Some(t) => t,
        None => return (None, None),
    };

    let moves_to_go = limits.movestogo.unwrap_or(20).max(1);

    // Time distribution formula
    let base = time / moves_to_go;
    let alloc = base + (inc * 3) / 4;
    let safe_alloc = alloc
        .min(time.saturating_sub(TIME_SAFETY_MARGIN_MS * 5))
        .max(MIN_TIME_ALLOC_MS);

    let hard = Duration::from_millis(safe_alloc.min(time / 2));
    let soft = Duration::from_millis((safe_alloc * 4 / 10).max(5));

    (Some(hard), Some(soft))
}

/// Compute single hard time limit duration for backward compatibility.
pub fn compute_time_limit(side: Color, limits: &SearchLimits) -> Option<Duration> {
    compute_time_limits(side, limits).0
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_movetime_limit() {
        let limits = SearchLimits {
            movetime: Some(1000),
            ..Default::default()
        };
        let (hard, soft) = compute_time_limits(Color::White, &limits);
        assert!(hard.is_some());
        assert_eq!(hard, soft);
        assert_eq!(hard.unwrap(), Duration::from_millis(990));
    }

    #[test]
    fn test_wtime_calculation() {
        let limits = SearchLimits {
            wtime: Some(60000),
            winc: Some(1000),
            ..Default::default()
        };
        let (hard, soft) = compute_time_limits(Color::White, &limits);
        assert!(hard.is_some());
        assert!(soft.is_some());
        assert!(hard.unwrap() > soft.unwrap());
    }
}
