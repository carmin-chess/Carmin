//! Algoritmo de Aprofundamento Iterativo (Iterative Deepening) e Pesquisa na Raiz.

use std::time::Instant;

use crate::board::Board;
use crate::eval::{MATE, MATE_IN_MAX};
use crate::movepick::MovePicker;
use crate::search::negamax::tt_score_to;
use crate::search::params::*;
use crate::search::{SearchLimits, Searcher};
use crate::tt::Bound;
use crate::types::Move;

/// Estrutura para ordenar e gerir os lances no nó raiz.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct RootMove {
    pub mv: Move,
    pub score: i32,
    pub nodes: u64,
}

impl RootMove {
    pub fn new(mv: Move) -> Self {
        Self {
            mv,
            score: -INF,
            nodes: 0,
        }
    }
}

impl Searcher {
    /// Ponto de entrada chamado pelo `uci.rs`
    pub fn search<H>(
        &mut self,
        board: &Board,
        limits: &SearchLimits,
        _history: &H,
    ) -> Option<Move> {
        let mut board_work = board.clone();

        // Inicializa o gestor de tempo com a cor do lado a jogar e os limites UCI
        self.time_mgr.init(board.side, limits);

        let max_depth = limits
            .depth
            .map(|d| d as i32)
            .unwrap_or(MAX_PLY as i32);

        self.iterative_deepening_with_limit(&mut board_work, max_depth)
    }

    /// Reconstrói a Variação Principal (PV) completa percorrendo a TT a partir da raiz
    pub fn collect_pv(&self, board: &Board, max_depth: usize) -> Vec<Move> {
        let mut pv = Vec::new();
        let mut current_board = board.clone();
        let mut visited = Vec::new();

        let first_move = if let Some(mv) = self.root_best_move {
            mv
        } else if let Some(entry) = self.tt.probe(current_board.hash) {
            if let Some(mv) = entry.best {
                mv
            } else {
                return pv;
            }
        } else {
            return pv;
        };

        let mut next_move = Some(first_move);

        for _ in 0..max_depth {
            let mv = match next_move {
                Some(m) => m,
                None => break,
            };

            let hash = current_board.hash;
            if visited.contains(&hash) {
                break;
            }
            visited.push(hash);

            let undo = current_board.make_move_fast(mv);
            if current_board.in_check(current_board.side.opponent()) {
                current_board.unmake_move_fast(mv, undo);
                break;
            }

            pv.push(mv);

            next_move = self.tt.probe(current_board.hash).and_then(|e| e.best);
        }

        pv
    }

    pub fn iterative_deepening(&mut self, board: &mut Board) -> Option<Move> {
        self.iterative_deepening_with_limit(board, MAX_PLY as i32)
    }

    /// Executa o Aprofundamento Iterativo respeitando limite de profundidade e tempo
    pub fn iterative_deepening_with_limit(&mut self, board: &mut Board, max_depth: i32) -> Option<Move> {
        let start_time = Instant::now();

        self.stop = false;
        self.nodes = 0;
        self.root_best_move = None;

        let mut root_moves = self.generate_root_moves(board);
        if root_moves.is_empty() {
            return None;
        }

        // Tenta obter o melhor lance da TT para ordenação inicial na raiz
        if let Some(entry) = self.tt.probe(board.hash) {
            if let Some(tt_mv) = entry.best {
                if let Some(pos) = root_moves.iter().position(|rm| rm.mv == tt_mv) {
                    root_moves.swap(0, pos);
                }
            }
        }

        let mut last_score = 0;

        for depth in 1..=max_depth {
            self.check_stop();
            if self.stop {
                break;
            }

            // Para antes de iniciar uma nova profundidade se o soft limit expirou
            if depth > 1 && (self.time_mgr.is_soft_expired() || self.time_mgr.is_expired(self.nodes)) {
                break;
            }

            let mut alpha = -INF;
            let mut beta = INF;
            let mut delta = 25; // Janela inicial em centipões

            // Janela de Aspiração a partir do depth 4
            if depth >= 4 {
                alpha = (last_score - delta).max(-INF);
                beta = (last_score + delta).min(INF);
            }

            let mut score;

            // Loop da Janela de Aspiração
            loop {
                score = self.search_root(board, depth, alpha, beta, &mut root_moves);

                self.check_stop();
                if self.stop {
                    break;
                }

                // Fail-Low
                if score <= alpha {
                    beta = (alpha + beta) / 2;
                    alpha = (score - delta).max(-INF);
                    delta += delta + delta / 2;
                }
                // Fail-High
                else if score >= beta {
                    beta = (score + delta).min(INF);
                    delta += delta + delta / 2;
                }
                // Dentro da janela
                else {
                    break;
                }

                if delta >= 3000 {
                    alpha = -INF;
                    beta = INF;
                }
            }

            if self.stop {
                break;
            }

            last_score = score;

            // Re-ordena os lances da raiz com base na pontuação atual
            root_moves.sort_by(|a, b| b.score.cmp(&a.score));

            if let Some(best) = root_moves.first() {
                self.root_best_move = Some(best.mv);
            }

            let elapsed_ms = start_time.elapsed().as_millis().max(1);
            let nps = (self.nodes as u128 * 1000) / elapsed_ms;

            if self.is_main_thread {
                self.print_uci_info(depth, score, elapsed_ms, nps, board);
            }
        }

        self.root_best_move
    }

    /// Pesquisa PVS na raiz
    fn search_root(
        &mut self,
        board: &mut Board,
        depth: i32,
        mut alpha: i32,
        beta: i32,
        root_moves: &mut [RootMove],
    ) -> i32 {
        self.pv_table.init_ply(0);
        let mut best_score = -INF;

        for i in 0..root_moves.len() {
            let mv = root_moves[i].mv;

            if self.excluded_root_moves.contains(&mv) {
                continue;
            }

            let nodes_before = self.nodes;
            let undo = board.make_move(mv);

            if !self.move_stack.is_empty() {
                self.move_stack[0] = Some(mv);
            }

            let mut score;

            if i == 0 {
                // PV Move
                score = -self.negamax(board, depth - 1, -beta, -alpha, 1, None);
            } else {
                // Non-PV Move
                score = -self.negamax(board, depth - 1, -alpha - 1, -alpha, 1, None);

                if score > alpha && score < beta {
                    score = -self.negamax(board, depth - 1, -beta, -alpha, 1, None);
                }
            }

            board.unmake_move(mv, undo);

            self.check_stop();
            if self.stop {
                return 0;
            }

            let node_delta = self.nodes - nodes_before;
            root_moves[i].nodes += node_delta;
            root_moves[i].score = score;

            if score > best_score {
                best_score = score;
            }

            if score > alpha {
                alpha = score;
                self.pv_table.update(0, mv);

                if !cfg!(feature = "disable_tt") {
                    self.tt.store(
                        board.hash,
                        depth,
                        tt_score_to(score, 0),
                        if score >= beta { Bound::Lower } else { Bound::Exact },
                        Some(mv),
                    );
                }

                if score >= beta {
                    break;
                }
            }
        }

        best_score
    }

    /// Gera lances legais na raiz
    fn generate_root_moves(&mut self, board: &mut Board) -> Vec<RootMove> {
        let mut moves = Vec::new();
        let mut picker = MovePicker::new(board, None, [None; 2], None, 0);

        while let Some(mv) = picker.next(board, self) {
            let undo = board.make_move_fast(mv);
            let legal = !board.in_check(board.side.opponent());
            board.unmake_move_fast(mv, undo);

            if legal {
                moves.push(RootMove::new(mv));
            }
        }

        moves
    }

    /// Imprime saída UCI com a PV completa
    fn print_uci_info(&self, depth: i32, score: i32, elapsed_ms: u128, nps: u128, board: &Board) {
        let score_str = if score >= MATE_IN_MAX {
            let mate_in = (MATE - score + 1) / 2;
            format!("score mate {}", mate_in)
        } else if score <= -MATE_IN_MAX {
            let mate_in = (-MATE - score) / 2;
            format!("score mate {}", mate_in)
        } else {
            format!("score cp {}", score)
        };

        let pv_moves = self.collect_pv(board, depth as usize);
        let pv_str = if !pv_moves.is_empty() {
            let moves_formatted: Vec<String> = pv_moves.iter().map(|m| format!("{}", m)).collect();
            format!(" pv {}", moves_formatted.join(" "))
        } else {
            String::new()
        };

        println!(
            "info depth {} {} time {} nodes {} nps {}{}",
            depth, score_str, elapsed_ms, self.nodes, nps, pv_str
        );
    }
}
