//! Search statistics and UCI reporting telemetry.
//!
//! This module tracks node counts, quiescence node counts, transposition table
//! hit rates, beta cutoffs, search depth benchmarks, and provides formatted
//! UCI reporting strings for engine communication.

use std::fmt;
use std::time::Duration;
use crate::eval::{MATE, MATE_IN_MAX};
use crate::types::Move;

/// Comprehensive statistics collected during a search run.
#[derive(Debug, Clone, Default)]
pub struct SearchStats {
    /// Total regular negamax nodes visited.
    pub nodes: u64,
    /// Total quiescence search nodes visited.
    pub qnodes: u64,
    /// Transposition table hits during main search.
    pub tt_hits: u64,
    /// Transposition table cutoffs (exact/lower/upper bound cutoffs).
    pub tt_cutoffs: u64,
    /// First move beta cutoffs (measure of move ordering quality).
    pub first_move_cutoffs: u64,
    /// Total beta cutoffs occurring in move loop.
    pub total_cutoffs: u64,
    /// Number of aspiration window re-searches.
    pub aspiration_researches: u64,
    /// Maximum depth reached in main search tree.
    pub max_depth_reached: i32,
    /// Maximum ply reached (including quiescence).
    pub max_ply_reached: usize,
}

impl SearchStats {
    /// Create a new, blank statistics instance.
    pub fn new() -> Self {
        Self::default()
    }

    /// Reset all counter statistics to zero.
    pub fn reset(&mut self) {
        *self = Self::default();
    }

    /// Record a main search node visit.
    #[inline]
    pub fn record_node(&mut self) {
        self.nodes = self.nodes.saturating_add(1);
    }

    /// Record a quiescence node visit.
    #[inline]
    pub fn record_qnode(&mut self) {
        self.qnodes = self.qnodes.saturating_add(1);
    }

    /// Record a transposition table hit.
    #[inline]
    pub fn record_tt_hit(&mut self) {
        self.tt_hits = self.tt_hits.saturating_add(1);
    }

    /// Record a transposition table cutoff.
    #[inline]
    pub fn record_tt_cutoff(&mut self) {
        self.tt_cutoffs = self.tt_cutoffs.saturating_add(1);
    }

    /// Record a beta cutoff at a given move index (1-based).
    #[inline]
    pub fn record_cutoff(&mut self, move_index: usize) {
        self.total_cutoffs = self.total_cutoffs.saturating_add(1);
        if move_index == 1 {
            self.first_move_cutoffs = self.first_move_cutoffs.saturating_add(1);
        }
    }

    /// Calculate first-move cutoff percentage (efficiency indicator).
    pub fn first_move_cutoff_pct(&self) -> f64 {
        if self.total_cutoffs == 0 {
            0.0
        } else {
            (self.first_move_cutoffs as f64 / self.total_cutoffs as f64) * 100.0
        }
    }

    /// Calculate combined total nodes (main nodes + qnodes).
    #[inline]
    pub fn total_nodes(&self) -> u64 {
        self.nodes.saturating_add(self.qnodes)
    }

    /// Compute Nodes Per Second (NPS) given an elapsed time duration.
    pub fn compute_nps(&self, elapsed: Duration) -> u64 {
        let millis = elapsed.as_millis().max(1) as u64;
        let total = self.total_nodes();
        total.saturating_mul(1000) / millis
    }
}

/// Formatter helper for UCI evaluation score reporting.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum UciScore {
    Centipawns(i32),
    Mate(i32),
}

impl UciScore {
    /// Convert an internal evaluation score and current ply into a `UciScore`.
    pub fn from_raw(score: i32, _ply: usize) -> Self {
        if score.abs() >= MATE_IN_MAX {
            let mate_in = (MATE - score.abs() + 1) / 2;
            let signed = if score > 0 { mate_in } else { -mate_in };
            UciScore::Mate(signed)
        } else {
            UciScore::Centipawns(score)
        }
    }
}

impl fmt::Display for UciScore {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self {
            UciScore::Centipawns(cp) => write!(f, "cp {}", cp),
            UciScore::Mate(m) => write!(f, "mate {}", m),
        }
    }
}

/// Helper struct for emitting clean UCI `info` protocol output.
pub struct UciInfoReporter;

impl UciInfoReporter {
    /// Format search iteration results into UCI standard line format.
    pub fn format_info_line(
        depth: i32,
        score: i32,
        nodes: u64,
        nps: u64,
        elapsed_ms: u64,
        pv_moves: &[Move],
    ) -> String {
        let score_obj = UciScore::from_raw(score, 0);
        let pv_string = pv_moves
            .iter()
            .map(|m| m.to_uci())
            .collect::<Vec<_>>()
            .join(" ");

        format!(
            "info depth {} score {} nodes {} nps {} time {} pv {}",
            depth, score_obj, nodes, nps, elapsed_ms, pv_string
        )
    }

    /// Format detailed search telemetry info (with extra stats if requested).
    pub fn format_verbose_info(
        depth: i32,
        seldepth: usize,
        score: i32,
        stats: &SearchStats,
        elapsed: Duration,
        pv_moves: &[Move],
    ) -> String {
        let elapsed_ms = elapsed.as_millis().max(1) as u64;
        let total_nodes = stats.total_nodes();
        let nps = stats.compute_nps(elapsed);
        let score_obj = UciScore::from_raw(score, 0);
        let pv_string = pv_moves
            .iter()
            .map(|m| m.to_uci())
            .collect::<Vec<_>>()
            .join(" ");

        format!(
            "info depth {} seldepth {} score {} nodes {} nps {} time {} pv {}",
            depth, seldepth, score_obj, total_nodes, nps, elapsed_ms, pv_string
        )
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_uci_score_formatting() {
        let cp_score = UciScore::from_raw(150, 0);
        assert_eq!(cp_score.to_string(), "cp 150");

        let mate_winning = UciScore::from_raw(MATE - 3, 0);
        assert_eq!(mate_winning.to_string(), "mate 2");

        let mate_losing = UciScore::from_raw(-MATE + 3, 0);
        assert_eq!(mate_losing.to_string(), "mate -2");
    }

    #[test]
    fn test_search_stats_nps() {
        let mut stats = SearchStats::new();
        stats.nodes = 5000;
        stats.qnodes = 5000;
        let nps = stats.compute_nps(Duration::from_millis(1000));
        assert_eq!(nps, 10000);
    }
}
