//! Endgame specific search logic.
//!
//! Também concentra a lógica de escalonamento de profundidade por fase de
//! jogo: com menos peças no tabuleiro, o fator de ramificação médio cai
//! bastante (menos lances legais por lado), então o mesmo orçamento de
//! tempo/nós de busca rende bem mais plies de profundidade "de graça".

use crate::board::Board;
use crate::search::params::*;

/// Número de peças (incluindo reis) para disparar a busca de mate no final.
pub const N_PIECES_ENDGAME: u32 = 5;

/// Verifica se o tabuleiro está em um final profundo onde devemos buscar até o mate
/// ignorando o limite de profundidade (depth) enviado.
pub fn is_mate_search_endgame(board: &Board) -> bool {
    board.occupancy.count_ones() <= N_PIECES_ENDGAME
}

/// Fase de jogo, classificada de forma simples pela contagem de peças
/// restantes no tabuleiro (incluindo reis).
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum GamePhase {
    Opening,
    Middlegame,
    Endgame,
}

/// Classifica a fase atual do jogo com base na contagem de peças.
///
/// É uma heurística propositalmente simples (só contagem de material, sem
/// olhar pra desenvolvimento ou número de lances jogados) — barata de
/// calcular a cada `go`, e suficiente pra decidir "quanto bônus de depth dar",
/// que é uma decisão grosseira por natureza.
pub fn classify_phase(board: &Board) -> GamePhase {
    let piece_count = board.occupancy.count_ones();

    if piece_count >= OPENING_MIN_PIECES {
        GamePhase::Opening
    } else if piece_count <= N_PIECES_ENDGAME + 1 {
        // Mantém consistência com is_mate_search_endgame: "6 peças ou menos"
        // já conta como final profundo pra fins de bônus de depth, mesmo que
        // o gatilho de busca-até-o-mate (<=5) só dispare um pouco depois.
        GamePhase::Endgame
    } else {
        GamePhase::Middlegame
    }
}

/// Bônus de profundidade (em plies) a somar ao depth pedido via UCI,
/// de acordo com a fase atual do jogo.
///
/// Exemplo com `go depth 14`:
/// - Abertura (>=28 peças): +0  -> depth efetivo 14
/// - Meio-jogo (13-27 peças): +1 -> depth efetivo 15
/// - Meio-jogo tardio (7-12 peças): +2 -> depth efetivo 16
/// - Final (<=6 peças): +6 -> depth efetivo 20
pub fn phase_depth_bonus(board: &Board) -> i32 {
    let piece_count = board.occupancy.count_ones();

    match classify_phase(board) {
        GamePhase::Opening => 0,
        GamePhase::Endgame => ENDGAME_PLY_BONUS_DEEP,
        GamePhase::Middlegame => {
            if piece_count <= MIDDLEGAME_HIGH_MIN_PIECES {
                MIDDLEGAME_PLY_BONUS_HIGH
            } else {
                MIDDLEGAME_PLY_BONUS_LOW
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    // Nota: testes de tabuleiro real dependem de Board::from_fen ou similar,
    // que não está incluído neste módulo — cobrir na suíte de integração do
    // crate. Aqui só documentamos os limiares esperados como referência.
    #[test]
    fn test_thresholds_consistency() {
        assert!(OPENING_MIN_PIECES > MIDDLEGAME_HIGH_MIN_PIECES);
        assert!(MIDDLEGAME_HIGH_MIN_PIECES > N_PIECES_ENDGAME);
        assert!(ENDGAME_PLY_BONUS_DEEP > MIDDLEGAME_PLY_BONUS_HIGH);
        assert!(MIDDLEGAME_PLY_BONUS_HIGH > MIDDLEGAME_PLY_BONUS_LOW);
    }
}
