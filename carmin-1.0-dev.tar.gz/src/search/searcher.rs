//! Searcher state and thread management module.
//!
//! Maintains per-thread search state including killer move tables, history heuristic tables,
//! continuation history tables, evaluation stacks, move stacks, stop signals, and statistics.

use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::Arc;
use std::time::{Duration, Instant};

use crate::board::Board;
use crate::search::params::*;
use crate::search::pv::PvTable;
use crate::search::statistics::SearchStats;
use crate::search::time::TimeManager;
use crate::tt::TranspositionTable;
use crate::types::Move;

/// Contexto de execução e estado heurístico de cada thread de busca.
pub struct Searcher {
    pub tt: Arc<TranspositionTable>,
    pub is_main_thread: bool,
    pub killers: [[Option<Move>; 2]; MAX_PLY],
    pub history: [[[i32; 64]; 64]; 2],
    pub capture_history: [[[i32; 7]; 64]; 7],
    pub root_best_move: Option<Move>,
    pub counter_moves: [[Option<Move>; 64]; 64],
    pub cont_hist_1ply: Box<[[[[i32; 64]; 6]; 64]; 6]>,
    pub cont_hist_2ply: Box<[[[[i32; 64]; 6]; 64]; 6]>,
    pub correction_history: Box<[[i32; CORRECTION_TABLE_SIZE]; 2]>,
    pub eval_stack: [i32; MAX_PLY],
    pub move_stack: [Option<Move>; MAX_PLY],
    pub piece_stack: [(usize, usize); MAX_PLY],
    pub nodes: u64,
    pub start: Instant,
    pub time_limit: Option<Duration>,
    pub soft_time_limit: Option<Duration>,
    pub time_mgr: TimeManager,
    pub stop: bool,
    pub stop_signal: Option<Arc<AtomicBool>>,
    pub ponder_signal: Option<Arc<AtomicBool>>,
    pub num_threads: usize,
    pub contempt: i32,
    pub multipv: usize,
    pub skill_level: usize,
    pub pondering: bool,
    pub excluded_root_moves: Vec<Move>,
    pub stats: SearchStats,
    pub pv_table: PvTable,
}

impl Searcher {
    /// Constrói um novo contexto para a thread do Searcher.
    pub fn new(
        tt: Arc<TranspositionTable>,
        is_main_thread: bool,
        num_threads: usize,
    ) -> Searcher {
        Searcher {
            tt,
            is_main_thread,
            killers: [[None; 2]; MAX_PLY],
            history: [[[0; 64]; 64]; 2],
            capture_history: [[[0i32; 7]; 64]; 7],
            counter_moves: [[None; 64]; 64],
            cont_hist_1ply: Box::new([[[[0i32; 64]; 6]; 64]; 6]),
            cont_hist_2ply: Box::new([[[[0i32; 64]; 6]; 64]; 6]),
            correction_history: Box::new([[0i32; CORRECTION_TABLE_SIZE]; 2]),
            eval_stack: [0; MAX_PLY],
            move_stack: [None; MAX_PLY],
            piece_stack: [(0, 0); MAX_PLY],
            nodes: 0,
            start: Instant::now(),
            time_limit: None,
            soft_time_limit: None,
            time_mgr: TimeManager::new(),
            stop: false,
            stop_signal: None,
            ponder_signal: None,
            num_threads,
            skill_level: 1,
            contempt: DEFAULT_CONTEMPT,
            stats: SearchStats::new(),
            root_best_move: None,
            pv_table: PvTable::new(),
            multipv: 1,
            pondering: false,
            excluded_root_moves: Vec::new(),
        }
    }

    /// Conecta a flag atômica de interrupção (stop).
    pub fn set_stop_signal(&mut self, signal: Arc<AtomicBool>) {
        self.stop_signal = Some(signal);
    }

    /// Conecta a flag atômica de Pondering (para detectar PonderHit dinamicamente).
    pub fn set_ponder_signal(&mut self, signal: Arc<AtomicBool>) {
        self.ponder_signal = Some(signal);
    }

    /// Retorna um lance de ponder GARANTIDAMENTE legal na posição real
    /// após `mv` já ter sido jogado.
    pub fn ponder_move(&self, mv: Move, board_after: &crate::board::Board) -> Option<Move> {
        let real_line = self.pv_table.get_line(0);

        if real_line.first() == Some(&mv) {
            if let Some(&reply) = real_line.get(1) {
                return Some(reply);
            }
        }

        crate::search::pv::PvCollector::collect_from_tt(board_after, &self.tt, 1)
            .first()
            .copied()
    }

    /// Skill Level 1 = strongest (best move). Higher values intentionally
    /// pick weaker MultiPV alternatives (handicap).
    pub fn get_skill_move(&self, board: &Board) -> Option<Move> {
        let mut multipv_moves: Vec<Move> = Vec::new();
        if let Some(mv) = self.root_best_move {
            multipv_moves.push(mv);
        }
        for &mv in &self.excluded_root_moves {
            if !multipv_moves.contains(&mv) {
                multipv_moves.push(mv);
            }
        }
        if multipv_moves.is_empty() {
            return self.collect_pv(board, 1).first().copied();
        }
        if self.skill_level <= 1 {
            return Some(multipv_moves[0]);
        }
        let target_idx = (self.skill_level - 1).min(multipv_moves.len() - 1);
        Some(multipv_moves[target_idx])
    }

    /// Reinicia tabelas heurísticas e estatísticas para uma nova partida.
    pub fn new_game(&mut self) {
        self.killers = [[None; 2]; MAX_PLY];
        self.history = [[[0; 64]; 64]; 2];
        self.capture_history = [[[0i32; 7]; 64]; 7];
        self.counter_moves = [[None; 64]; 64];
        *self.cont_hist_1ply = [[[[0i32; 64]; 6]; 64]; 6];
        *self.cont_hist_2ply = [[[[0i32; 64]; 6]; 64]; 6];
        *self.correction_history = [[0i32; CORRECTION_TABLE_SIZE]; 2];
        self.eval_stack = [0; MAX_PLY];
        self.move_stack = [None; MAX_PLY];
        self.piece_stack = [(0, 0); MAX_PLY];
        self.stats.reset();
        self.pv_table.clear();
    }

    pub fn get_capture_history(&self, attacker: usize, to: usize, victim: usize) -> i32 {
        self.capture_history[attacker][to][victim]
    }

    pub fn get_history(&self, side: usize, from: usize, to: usize) -> i32 {
        self.history[side][from][to]
    }

    pub fn get_cont_hist_1ply(&self, ppt: usize, pto: usize, cpt: usize, cto: usize) -> i32 {
        self.cont_hist_1ply[ppt][pto][cpt][cto]
    }

    pub fn get_cont_hist_2ply(&self, ppt: usize, pto: usize, cpt: usize, cto: usize) -> i32 {
        self.cont_hist_2ply[ppt][pto][cpt][cto]
    }

    pub fn get_move_stack(&self, ply: usize) -> Option<Move> {
        if ply < MAX_PLY {
            self.move_stack[ply]
        } else {
            None
        }
    }

    pub fn get_piece_stack(&self, ply: usize) -> (usize, usize) {
        if ply < MAX_PLY {
            self.piece_stack[ply]
        } else {
            (0, 0)
        }
    }

    /// Verifica os sinais de parada (sinal atômico ou limite de tempo estourado).
    #[inline]
    pub fn check_stop(&mut self) {
        if let Some(ponder_signal) = &self.ponder_signal {
            self.pondering = ponder_signal.load(Ordering::Relaxed);
        }

        if let Some(signal) = &self.stop_signal {
            if signal.load(Ordering::Relaxed) {
                self.stop = true;
                return;
            }
        }

        if !self.pondering && self.nodes & TIME_CHECK_NODE_INTERVAL == 0 && self.out_of_time() {
            self.stop = true;
        }
    }

    /// Verifica se o limite de tempo estourou.
    #[inline]
    pub fn out_of_time(&self) -> bool {
        if self.pondering {
            return false;
        }
        self.time_mgr.is_expired(self.nodes)
    }

    #[inline]
    pub fn update_killers(&mut self, mv: Move, ply: usize) {
        if ply >= MAX_PLY {
            return;
        }
        if self.killers[ply][0] != Some(mv) {
            self.killers[ply][1] = self.killers[ply][0];
            self.killers[ply][0] = Some(mv);
        }
    }

    pub fn update_history_with_gravity(
        &mut self,
        board: &Board,
        cutoff_mv: Move,
        cutoff_piece_type: usize,
        depth: i32,
        prev1_pt_to: Option<(usize, usize)>,
        prev2_pt_to: Option<(usize, usize)>,
        searched_quiets: &[Option<Move>],
    ) {
        let side = board.side.index();
        let bonus = (depth * depth).min(HISTORY_BONUS_MAX);

        let entry = &mut self.history[side][cutoff_mv.from.index()][cutoff_mv.to.index()];
        *entry += bonus - (*entry * bonus.abs()) / HISTORY_GRAVITY_DIVISOR;
        *entry = (*entry).clamp(-HISTORY_MAX, HISTORY_MAX);

        if let Some((ppt, pto)) = prev1_pt_to {
            let cont_entry =
                &mut self.cont_hist_1ply[ppt][pto][cutoff_piece_type][cutoff_mv.to.index()];
            *cont_entry += bonus - (*cont_entry * bonus.abs()) / HISTORY_GRAVITY_DIVISOR;
            *cont_entry = (*cont_entry).clamp(-HISTORY_MAX, HISTORY_MAX);
        }

        if let Some((ppt, pto)) = prev2_pt_to {
            let cont_entry =
                &mut self.cont_hist_2ply[ppt][pto][cutoff_piece_type][cutoff_mv.to.index()];
            *cont_entry += bonus - (*cont_entry * bonus.abs()) / HISTORY_GRAVITY_DIVISOR;
            *cont_entry = (*cont_entry).clamp(-HISTORY_MAX, HISTORY_MAX);
        }

        for &opt_mv in searched_quiets {
            if let Some(failed_mv) = opt_mv {
                if failed_mv != cutoff_mv {
                    let fail_entry =
                        &mut self.history[side][failed_mv.from.index()][failed_mv.to.index()];
                    *fail_entry -= bonus + (*fail_entry * bonus.abs()) / HISTORY_GRAVITY_DIVISOR;
                    *fail_entry = (*fail_entry).clamp(-HISTORY_MAX, HISTORY_MAX);

                    if let Some((ppt, pto)) = prev1_pt_to {
                        let cur_pt = board.piece_on(failed_mv.from).map_or(0, |p| p.kind.index());
                        let cont_fail =
                            &mut self.cont_hist_1ply[ppt][pto][cur_pt][failed_mv.to.index()];
                        *cont_fail -=
                            bonus + (*cont_fail * bonus.abs()) / HISTORY_GRAVITY_DIVISOR;
                        *cont_fail = (*cont_fail).clamp(-HISTORY_MAX, HISTORY_MAX);
                    }

                    if let Some((ppt, pto)) = prev2_pt_to {
                        let cur_pt = board.piece_on(failed_mv.from).map_or(0, |p| p.kind.index());
                        let cont_fail =
                            &mut self.cont_hist_2ply[ppt][pto][cur_pt][failed_mv.to.index()];
                        *cont_fail -=
                            bonus + (*cont_fail * bonus.abs()) / HISTORY_GRAVITY_DIVISOR;
                        *cont_fail = (*cont_fail).clamp(-HISTORY_MAX, HISTORY_MAX);
                    }
                }
            }
        }
    }
}
