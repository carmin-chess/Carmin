//! Search Extensions module.
//!
//! Provides rules for dynamic search extensions (check extensions, pawn pushes to 7th rank,
//! single reply extensions, mate threat extensions).

use crate::board::Board;
use crate::types::{Color, Move, PieceType};

/// Computes search depth extension (0 or +1) for a given move.
pub fn compute_extensions(
    board: &Board,
    mv: Move,
    in_check: bool,
    _is_pv: bool,
    _ply: usize,
    _move_count: usize,
) -> i32 {
    let mut extension = 0;

    // Check extension (+1 ply)
    if in_check {
        extension = 1;
    }

    // Pawn push to 7th rank extension (+1 ply)
    if extension == 0 {
        if let Some(p) = board.piece_on(mv.from) {
            if p.kind == PieceType::Pawn {
                let rel_rank = match board.side {
                    Color::White => mv.to.rank(),
                    Color::Black => 7 - mv.to.rank(),
                };
                if rel_rank == 6 {
                    extension = 1;
                }
            }
        }
    }

    extension
}
