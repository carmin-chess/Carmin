//! Principal Variation (PV) table and PV collection utilities.
//!
//! The PV table records the sequence of best moves calculated at each ply
//! in the search tree. This module provides:
//! - A triangular PV array structure (`PvTable`) for exact node-level line tracking.
//! - Transposition Table (TT) fallback PV collection routines.
//! - Validation routines ensuring all exported PV lines are strictly legal.

use crate::board::Board;
use crate::movegen::generate_legal;
use crate::search::params::MAX_PLY;
use crate::tt::TranspositionTable;
use crate::types::Move;

/// Triangular array structure storing the Principal Variation per ply.
#[derive(Clone)]
pub struct PvTable {
    /// Triangular move storage matrix.
    table: [[Option<Move>; MAX_PLY]; MAX_PLY],
    /// Length of PV line recorded at each ply.
    length: [usize; MAX_PLY],
}

impl Default for PvTable {
    fn default() -> Self {
        Self::new()
    }
}

impl PvTable {
    /// Create a new, initialized PV table with zero lengths.
    pub fn new() -> Self {
        Self {
            table: [[None; MAX_PLY]; MAX_PLY],
            length: [0; MAX_PLY],
        }
    }

    /// Clear all recorded PV lines.
    pub fn clear(&mut self) {
        self.length = [0; MAX_PLY];
        for row in self.table.iter_mut() {
            row.fill(None);
        }
    }

    /// Initialize line length at a given ply to zero (leaf/quiescence entrance).
    #[inline]
    pub fn init_ply(&mut self, ply: usize) {
        if ply < MAX_PLY {
            self.length[ply] = 0;
        }
    }

    /// Store a move at `ply` and copy the PV line from `ply + 1`.
    #[inline]
    pub fn update(&mut self, ply: usize, mv: Move) {
        if ply >= MAX_PLY {
            return;
        }
        self.table[ply][ply] = Some(mv);
        let next_len = if ply + 1 < MAX_PLY { self.length[ply + 1] } else { 0 };

        for i in (ply + 1)..(ply + 1 + next_len).min(MAX_PLY) {
            self.table[ply][i] = self.table[ply + 1][i];
        }
        self.length[ply] = 1 + next_len.min(MAX_PLY - ply - 1);
    }

    /// Get the recorded PV line starting at a given ply as a slice of moves.
    pub fn get_line(&self, ply: usize) -> Vec<Move> {
        if ply >= MAX_PLY {
            return Vec::new();
        }
        let len = self.length[ply];
        let mut line = Vec::with_capacity(len);
        for i in ply..(ply + len).min(MAX_PLY) {
            if let Some(mv) = self.table[ply][i] {
                line.push(mv);
            } else {
                break;
            }
        }
        line
    }

    /// Retrieve the best move at the root (ply 0).
    pub fn root_best_move(&self) -> Option<Move> {
        self.table[0][0]
    }
}

/// Fallback PV collector that reconstructs the line by probing the TT.
pub struct PvCollector;

impl PvCollector {
    /// Walk the Transposition Table from `board` up to `max_len` plies to build the PV line.
    pub fn collect_from_tt(
        board: &Board,
        tt: &TranspositionTable,
        max_len: usize,
    ) -> Vec<Move> {
        let mut pv = Vec::with_capacity(max_len.min(MAX_PLY));
        let mut current_board = board.clone();
        let mut visited = Vec::with_capacity(max_len);

        for _ in 0..max_len.min(MAX_PLY) {
            let hash = current_board.hash;
            if visited.contains(&hash) {
                break; // Prevent repetition loops
            }
            visited.push(hash);

            if let Some(entry) = tt.probe(hash) {
                if let Some(mv) = entry.best {
                    // Verify legality before following TT recommendation
                    let legals = generate_legal(&mut current_board);
                    if !legals.as_slice().contains(&mv) {
                        break;
                    }
                    pv.push(mv);
                    current_board.make_move(mv);
                    continue;
                }
            }
            break;
        }
        pv
    }

    /// Validate a given PV move sequence against board rules, returning only valid moves up to the first illegal move.
    pub fn validate_pv_line(board: &Board, pv: &[Move]) -> Vec<Move> {
        let mut valid_line = Vec::new();
        let mut b = board.clone();

        for &mv in pv {
            let legals = generate_legal(&mut b);
            if legals.as_slice().contains(&mv) {
                valid_line.push(mv);
                b.make_move(mv);
            } else {
                break;
            }
        }
        valid_line
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::Square;

    #[test]
    fn test_pv_table_update() {
        let mut pv = PvTable::new();
        let mv1 = Move::new(
            Square::from_file_rank(4, 1),
            Square::from_file_rank(4, 3),
            crate::types::MoveFlag::Quiet,
        );
        let mv2 = Move::new(
            Square::from_file_rank(4, 6),
            Square::from_file_rank(4, 4),
            crate::types::MoveFlag::Quiet,
        );

        pv.init_ply(1);
        pv.update(1, mv2);

        pv.update(0, mv1);

        let line = pv.get_line(0);
        assert_eq!(line.len(), 2);
        assert_eq!(line[0], mv1);
        assert_eq!(line[1], mv2);
    }
}
