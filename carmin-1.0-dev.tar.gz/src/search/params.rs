//! Search parameters, thresholds, and operational constants for the Carmin search engine.
//!
//! This module defines configuration parameters governing:
//! - Maximum ply / depth bounds.
//! - Score boundaries (Infinity, Mate values).
//! - Aspiration window dimensions and growth factors.
//! - Quiescence search delta pruning margins.
//! - Time management parameters and depth bonuses.
//! - History heuristic gravity bounds and scaling.

use crate::eval::MATE;

/// Maximum search ply supported by stack structures.
pub const MAX_PLY: usize = 64;

/// Infinite score threshold for alpha-beta search.
pub const INF: i32 = MATE + 1;

/// Minimum mate score threshold to recognize checkmate bounds.
pub const MATE_THRESHOLD: i32 = MATE - 256;

/// Extra depth bonus added during endgame phases (when piece count is low).
pub const ENDGAME_PLY_BONUS: i32 = 2;


// -----------------------------------------------------------------------------
// Aspiration Window Parameters
// -----------------------------------------------------------------------------

/// Search depth threshold for Internal Iterative Deepening.
pub const IID_PV_DEPTH: i32 = 5;

/// Search depth at which aspiration window search begins.
pub const ASP_START_DEPTH: i32 = 6;

/// Initial score delta for the aspiration window (+/- centipawns).
pub const ASP_INITIAL_DELTA: i32 = 60;

/// Multiplier for widening aspiration window when a window bound fails.
pub const ASP_DELTA_MULTIPLIER: i32 = 2;

/// Maximum aspiration window expansion iterations before resetting to full window (-INF, INF).
pub const ASP_MAX_RETRY: usize = 4;

// -----------------------------------------------------------------------------
// Quiescence Search Parameters
// -----------------------------------------------------------------------------

/// Safety margin for delta pruning in Quiescence Search (centipawns).
pub const QS_DELTA_MARGIN: i32 = 50;

/// Maximum depth permitted inside quiescence search before hard termination.
pub const QS_MAX_PLY: usize = 64;

// -----------------------------------------------------------------------------
// Move Ordering and History Heuristic Bounds
// -----------------------------------------------------------------------------

/// Maximum absolute history score to prevent integer overflow and weight cap.
pub const HISTORY_MAX: i32 = 30_000;

/// Maximum bonus added to history tables upon a beta cutoff.
pub const HISTORY_BONUS_MAX: i32 = 2000;

/// History gravity divisor used to scale existing scores downward when adding bonuses.
pub const HISTORY_GRAVITY_DIVISOR: i32 = 32768;

/// Correction history table size (indexed by hash & 16383).
pub const CORRECTION_TABLE_SIZE: usize = 16384;

/// Correction history weight scaling divisor.
pub const CORRECTION_GRAVITY_DIVISOR: i32 = 16;

/// Maximum correction offset applied to static evaluation.
pub const CORRECTION_MAX_OFFSET: i32 = 1024;

// -----------------------------------------------------------------------------
// Time Control Thresholds
// -----------------------------------------------------------------------------

/// Default node check interval for time limit checking during search.
pub const TIME_CHECK_NODE_INTERVAL: u64 = 2047;

/// Minimum move time safety margin in milliseconds.
pub const TIME_SAFETY_MARGIN_MS: u64 = 10;

/// Minimum time allocation in milliseconds.
pub const MIN_TIME_ALLOC_MS: u64 = 10;

// -----------------------------------------------------------------------------
// Miscellaneous Parameters
// -----------------------------------------------------------------------------

/// Default contempt factor (in centipawns) for draw scoring.
pub const DEFAULT_CONTEMPT: i32 = -20;

/// Number of consecutive iterations with identical best move required for soft time exit.
pub const STABLE_MOVE_STREAK_THRESHOLD: u32 = 4;

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_params_consistency() {
        assert!(MAX_PLY <= 256);
        assert!(INF > MATE);
        assert!(ASP_INITIAL_DELTA > 0);
        assert!(HISTORY_MAX > 0);
    }
}

// Additional search heuristics constants
pub const NULL_MOVE_MARGIN: i32 = 200;
pub const RAZOR_DEPTH: i32 = 3;
pub const RAZOR_MARGIN1: i32 = 300;
pub const RAZOR_MARGIN2: i32 = 150;
pub const IQI_DEPTH: i32 = 2;
pub const FUTILITY_MARGIN1: i32 = 120;
pub const FUTILITY_MARGIN2: i32 = 100;
pub const THREAT_DEPTH: i32 = 3;
// LMP tuning
pub const LMP_BASE: usize = 3;
pub const LMP_SCALE: usize = 1;

//Singular extensions
pub const SINGULAR_MIN_DEPTH: i32 = 8;
pub const SINGULAR_TT_DEPTH_MARGIN: i32 = 3;
pub const SINGULAR_MARGIN_PER_PLY: i32 = 2;

// -----------------------------------------------------------------------------
// Root Move Pruning
// -----------------------------------------------------------------------------

/// Depth reportado após o qual cortamos a lista de lances de raiz.
/// Depth 1-3 continuam buscando TODOS os lances legais (é o que
/// ranqueia os candidatos); a partir daí só os N melhores seguem.
pub const ROOT_MOVE_CUT_DEPTH: i32 = 6;

/// Quantos lances de raiz sobrevivem ao corte.
pub const ROOT_MOVE_CUT_COUNT: usize = 8;

// -----------------------------------------------------------------------------
// Game Phase Depth Scaling
// -----------------------------------------------------------------------------

/// Peças (com reis) a partir da qual consideramos que ainda estamos na abertura
/// (poucas ou nenhuma troca aconteceu) — sem bônus de profundidade.
pub const OPENING_MIN_PIECES: u32 = 28;

/// Faixa de meio-jogo "cheio": bônus pequeno.
pub const MIDDLEGAME_HIGH_MIN_PIECES: u32 = 13;

/// Bônus de profundidade por fase (em plies, somado ao depth pedido via UCI).
pub const MIDDLEGAME_PLY_BONUS_LOW: i32 = 1;  // 13–27 peças: depth 14 -> 15
pub const MIDDLEGAME_PLY_BONUS_HIGH: i32 = 2; // 7–12 peças: depth 14 -> 16
pub const ENDGAME_PLY_BONUS_DEEP: i32 = 6;    // <=6 peças: depth 14 -> 20
