//! Quiescence Search module.

use crate::board::Board;
use crate::eval::{evaluate, MATE, MATE_IN_MAX};
use crate::movegen::generate_legal;
use crate::movepick::MovePicker;
use crate::search::negamax::{tt_score_from, tt_score_to};
use crate::search::params::*;
use crate::search::see::{mvv_lva, piece_value, see_ge};
use crate::search::Searcher;
use crate::tt::Bound;
use crate::types::{Move, MoveFlag, PieceType};

impl Searcher {
    pub fn quiescence(
        &mut self,
        board: &mut Board,
        mut alpha: i32,
        beta: i32,
        ply: usize,
    ) -> i32 {
        self.check_stop();

        if self.stop {
            return 0;
        }

        // Draw detection – treat draws as a small negative score (contempt)
        if board.is_draw() {
            return -self.contempt;
        }

        self.stats.record_qnode();
        self.nodes += 1;

        // ------------------------------------------------------------
        // Segurança de profundidade
        // ------------------------------------------------------------

        if ply >= MAX_PLY - 1 {
            return evaluate(board);
        }

        let original_alpha = alpha;

        let in_check = board.in_check(board.side);

        // ------------------------------------------------------------
        // Transposition Table
        //
        // QS não tinha probe/store nenhum antes: toda posição repetida
        // (comum em sequências de captura, que convergem pra mesma
        // posição por ordens de lance diferentes) era reavaliada e
        // rebuscada do zero, sem hash move pra ordenação nem cutoff.
        // ------------------------------------------------------------

        let mut tt_move: Option<Move> = None;

        if !cfg!(feature = "disable_tt") {
            if let Some(entry) = self.tt.probe(board.hash) {
                self.stats.record_tt_hit();

                tt_move = entry.best;

                let tt_score = tt_score_from(entry.score, ply);

                match entry.bound {
                    Bound::Exact => {
                        self.stats.record_tt_cutoff();
                        return tt_score;
                    }

                    Bound::Lower if tt_score >= beta => {
                        self.stats.record_tt_cutoff();
                        return tt_score;
                    }

                    Bound::Upper if tt_score <= alpha => {
                        self.stats.record_tt_cutoff();
                        return tt_score;
                    }

                    _ => {}
                }
            }
        }

        // ------------------------------------------------------------
        // Em xeque:
        // precisamos procurar TODAS as evasões.
        // Não existe stand-pat.
        // ------------------------------------------------------------

        if in_check {
            let mut moves = generate_legal(board);

            if moves.len == 0 {
                return -MATE + ply as i32;
            }

            // Ordenar evasões:
            // tt_move primeiro, depois capturas/promotions.
            let num_moves = moves.len;

            let mut scores = [0i32; 256];

            for i in 0..num_moves {
                let mv = moves.as_slice()[i];

                let mut score = 0;

                if Some(mv) == tt_move {
                    score += 1_000_000;
                }

                if mv.is_capture() {
                    score += mvv_lva(board, mv);
                    score += 1000;
                }

                if let Some(promo) = mv.promotion() {
                    score += piece_value(promo) + 5000;
                }

                scores[i] = score;
            }

            // Selection sort simples.
            for i in 0..num_moves {
                let mut best = i;

                for j in (i + 1)..num_moves {
                    if scores[j] > scores[best] {
                        best = j;
                    }
                }

                if best != i {
                    moves.as_mut_slice().swap(i, best);
                    scores.swap(i, best);
                }
            }

            let mut best_score = -INF;
            let mut best_move: Option<Move> = None;

            for i in 0..num_moves {
                let mv = moves.as_slice()[i];

                let undo = board.make_move(mv);

                // Prefetch da TT pra posição filha (mesma ideia do negamax).
                self.tt.prefetch(board.hash);

                // generate_legal já garante legalidade, mas
                // mantemos a proteção.
                if board.in_check(board.side.opponent()) {
                    board.unmake_move(mv, undo);
                    continue;
                }

                let score =
                    -self.quiescence(
                        board,
                        -beta,
                        -alpha,
                        ply + 1,
                    );

                board.unmake_move(mv, undo);

                if self.stop {
                    return 0;
                }

                if score > best_score {
                    best_score = score;
                    best_move = Some(mv);
                }

                if score >= beta {
                    if !cfg!(feature = "disable_tt") {
                        self.tt.store(
                            board.hash,
                            0,
                            tt_score_to(score, ply),
                            Bound::Lower,
                            Some(mv),
                        );
                    }

                    return score;
                }

                if score > alpha {
                    alpha = score;
                }
            }

            let final_score = best_score.max(alpha);

            if !cfg!(feature = "disable_tt") {
                let bound = if final_score > original_alpha {
                    Bound::Exact
                } else {
                    Bound::Upper
                };

                self.tt.store(
                    board.hash,
                    0,
                    tt_score_to(final_score, ply),
                    bound,
                    best_move,
                );
            }

            return final_score;
        }

        // ------------------------------------------------------------
        // Stand pat
        //
        // (antes disso havia uma segunda chamada de evaluate() logo no
        // início da função, só pra descartar o resultado — dobrava o
        // custo da eval completa em todo nó de QS fora de xeque.
        // Removida: só calculamos evaluate() aqui mesmo.)
        // ------------------------------------------------------------

        let stand_pat = evaluate(board);

        if stand_pat >= beta {
            if !cfg!(feature = "disable_tt") {
                self.tt.store(
                    board.hash,
                    0,
                    tt_score_to(stand_pat, ply),
                    Bound::Lower,
                    None,
                );
            }

            return stand_pat;
        }

        if stand_pat > alpha {
            alpha = stand_pat;
        }

        let mut best_score = stand_pat;
        let mut best_move: Option<Move> = None;

        // ------------------------------------------------------------
        // MovePicker:
        // somente capturas/promotions, agora com tt_move (se tático)
        // como primeiro lance experimentado.
        // ------------------------------------------------------------

        let mut picker =
            MovePicker::new_quiescence(board, tt_move);

        while let Some(mv) = picker.next(board, self) {

            // --------------------------------------------------------
            // Valor material da captura
            // --------------------------------------------------------

            let capture_value = match mv.flag {
                MoveFlag::EnPassant => {
                    piece_value(PieceType::Pawn)
                }

                _ => {
                    board
                        .piece_on(mv.to)
                        .map(|p| piece_value(p.kind))
                        .unwrap_or(0)
                }
            };

            let promotion_value =
                mv.promotion()
                    .map(piece_value)
                    .unwrap_or(0);

            let gain =
                capture_value + promotion_value;

            // --------------------------------------------------------
            // Delta pruning
            //
            // Só podemos descartar se mesmo ganhando a peça
            // capturada não chegamos perto de alpha.
            // --------------------------------------------------------

            if stand_pat
                + gain
                + QS_DELTA_MARGIN
                < alpha
                && stand_pat < MATE_IN_MAX
            {
                continue;
            }

            // --------------------------------------------------------
            // SEE pruning
            //
            // Capturas claramente perdedoras são descartadas.
            //
            // EXCEÇÃO:
            // promoções nunca devem ser descartadas por SEE.
            // --------------------------------------------------------

            if mv.promotion().is_none()
                && !see_ge(board, mv, 0)
            {
                continue;
            }

            // --------------------------------------------------------
            // Fazer lance
            // --------------------------------------------------------

            let undo = board.make_move(mv);

            // Prefetch da TT pra posição filha (mesma ideia do negamax).
            self.tt.prefetch(board.hash);

            // Segurança de legalidade.
            if board.in_check(board.side.opponent()) {
                board.unmake_move(mv, undo);
                continue;
            }

            // --------------------------------------------------------
            // Recursive QS
            // --------------------------------------------------------

            let score =
                -self.quiescence(
                    board,
                    -beta,
                    -alpha,
                    ply + 1,
                );

            board.unmake_move(mv, undo);

            if self.stop {
                return 0;
            }

            if score > best_score {
                best_score = score;
                best_move = Some(mv);
            }

            // --------------------------------------------------------
            // Beta cutoff
            // --------------------------------------------------------

            if score >= beta {
                if !cfg!(feature = "disable_tt") {
                    self.tt.store(
                        board.hash,
                        0,
                        tt_score_to(score, ply),
                        Bound::Lower,
                        Some(mv),
                    );
                }

                return score;
            }

            // --------------------------------------------------------
            // Alpha improvement
            // --------------------------------------------------------

            if score > alpha {
                alpha = score;
            }
        }

        if !cfg!(feature = "disable_tt") {
            let bound = if best_score > original_alpha {
                Bound::Exact
            } else {
                Bound::Upper
            };

            self.tt.store(
                board.hash,
                0,
                tt_score_to(best_score, ply),
                bound,
                best_move,
            );
        }

        best_score
    }
}
