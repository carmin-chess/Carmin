//! Move Ordering heuristics and staged Move Picker.
//!
//! Move ordering is critical for alpha-beta search efficiency. This module implements:
//! - Transposition Table move prioritization (Hash Move).
//! - MVV-LVA (Most Valuable Victim - Least Valuable Attacker) for captures.
//! - Capture History heuristic scoring.
//! - Killer Moves per ply (2 killer move slots per ply).
//! - Counter Moves (move played in response to opponent's previous move).
//! - History Heuristic with gravity scaling.
//! - 1-Ply and 2-Ply Continuation History.
//! - Static Exchange Evaluation (SEE) cutoff sorting (Good Captures vs Bad Captures).

use crate::board::Board;
use crate::movegen::{generate_pseudo_captures, generate_pseudo_quiets, MoveList};
use crate::search::see::{mvv_lva, piece_value, see_ge};
use crate::search::Searcher;
use crate::types::{Move, MoveFlag};

/// Stages of move generation and picking during search.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MovePickerStage {
    /// Probe and yield Transposition Table move if pseudo-legal.
    TTMove,
    /// Generate pseudo-legal capture moves.
    GenerateCaptures,
    /// Pick winning and equal captures (filtered by SEE >= 0).
    GoodCaptures,
    /// Yield killer moves stored for current ply.
    Killers,
    /// Yield counter move corresponding to previous move.
    Counter,
    /// Generate pseudo-legal quiet moves.
    GenerateQuiets,
    /// Yield quiet moves ordered by History and Continuation History.
    Quiets,
    /// Yield losing captures (SEE < 0).
    BadCaptures,
    /// End of move picking.
    Done,
}

/// Dynamic move picker yielding moves one-by-one in optimal search order.
pub struct MovePicker {
    stage: MovePickerStage,
    moves: MoveList,
    scores: [i32; 256],
    index: usize,
    bad_captures: MoveList,
    tt_move: Option<Move>,
    killers: [Option<Move>; 2],
    counter: Option<Move>,
    skip_quiets: bool,
    ply: usize,
}

impl MovePicker {
    /// Initialize move picker for regular negamax search.
    pub fn new(
        _board: &Board,
        tt_move: Option<Move>,
        killers: [Option<Move>; 2],
        counter: Option<Move>,
        ply: usize,
    ) -> Self {
        Self {
            stage: MovePickerStage::TTMove,
            moves: MoveList::new(),
            scores: [0; 256],
            index: 0,
            bad_captures: MoveList::new(),
            tt_move,
            killers,
            counter,
            skip_quiets: false,
            ply,
        }
    }

    /// Initialize move picker for quiescence search (captures and checks only).
    pub fn new_quiescence(_board: &Board, tt_move: Option<Move>) -> Self {
        Self {
            stage: MovePickerStage::TTMove,
            moves: MoveList::new(),
            scores: [0; 256],
            index: 0,
            bad_captures: MoveList::new(),
            tt_move,
            killers: [None; 2],
            counter: None,
            skip_quiets: true,
            ply: 0,
        }
    }

    /// Fetch the next move in priority order. Returns `None` when all moves are exhausted.
    pub fn next(&mut self, board: &mut Board, searcher: &Searcher) -> Option<Move> {
        loop {
            match self.stage {
                MovePickerStage::TTMove => {
                    self.stage = MovePickerStage::GenerateCaptures;
                    if let Some(mv) = self.tt_move {
                        // Em quiescence (skip_quiets) só podemos yieldar o
                        // tt_move aqui se for capture/promotion — senão
                        // quebraria o contrato de "só lances táticos" da QS.
                        // Um tt_move quieto (vindo de uma entrada de busca
                        // completa) simplesmente não é usado como hash move
                        // aqui, mas continua guardado pra dedup mais abaixo.
                        let tactical =
                            mv.is_capture() || mv.promotion().is_some();

                        if (!self.skip_quiets || tactical)
                            && board.is_pseudo_legal(mv)
                        {
                            return Some(mv);
                        }
                    }
                }
                MovePickerStage::GenerateCaptures => {
                    generate_pseudo_captures(board, &mut self.moves);
                    self.score_captures(board, searcher);
                    self.index = 0;
                    self.stage = MovePickerStage::GoodCaptures;
                }
                MovePickerStage::GoodCaptures => {
                    while self.index < self.moves.len {
                        self.partial_sort();
                        let mv = self.moves.as_slice()[self.index];
                        self.index += 1;
                        if Some(mv) == self.tt_move {
                            continue;
                        }
                        if see_ge(board, mv, 0) {
                            return Some(mv);
                        } else {
                            self.bad_captures.push(mv);
                        }
                    }
                    self.index = 0;
                    self.stage = MovePickerStage::Killers;
                }
                MovePickerStage::Killers => {
                    if self.skip_quiets {
                        self.stage = MovePickerStage::Done;
                        continue;
                    }
                    if self.index == 0 {
                        self.index = 1;
                        if let Some(mv) = self.killers[0] {
                            if Some(mv) != self.tt_move && board.is_pseudo_legal(mv) {
                                return Some(mv);
                            }
                        }
                    } else if self.index == 1 {
                        self.index = 2;
                        if let Some(mv) = self.killers[1] {
                            if Some(mv) != self.tt_move
                                && Some(mv) != self.killers[0]
                                && board.is_pseudo_legal(mv)
                            {
                                return Some(mv);
                            }
                        }
                    } else {
                        self.index = 0;
                        self.stage = MovePickerStage::Counter;
                    }
                }
                MovePickerStage::Counter => {
                    self.stage = MovePickerStage::GenerateQuiets;
                    if let Some(mv) = self.counter {
                        if Some(mv) != self.tt_move
                            && Some(mv) != self.killers[0]
                            && Some(mv) != self.killers[1]
                            && board.is_pseudo_legal(mv)
                        {
                            return Some(mv);
                        }
                    }
                }
                MovePickerStage::GenerateQuiets => {
                    self.moves.len = 0;
                    generate_pseudo_quiets(board, &mut self.moves);
                    self.score_quiets(board, searcher);
                    self.index = 0;
                    self.stage = MovePickerStage::Quiets;
                }
                MovePickerStage::Quiets => {
                    while self.index < self.moves.len {
                        self.partial_sort();
                        let mv = self.moves.as_slice()[self.index];
                        self.index += 1;
                        if Some(mv) == self.tt_move
                            || Some(mv) == self.killers[0]
                            || Some(mv) == self.killers[1]
                            || Some(mv) == self.counter
                        {
                            continue;
                        }
                        return Some(mv);
                    }
                    self.index = 0;
                    self.stage = MovePickerStage::BadCaptures;
                }
                MovePickerStage::BadCaptures => {
                    if self.index < self.bad_captures.len {
                        let mv = self.bad_captures.as_slice()[self.index];
                        self.index += 1;
                        return Some(mv);
                    }
                    self.stage = MovePickerStage::Done;
                }
                MovePickerStage::Done => {
                    return None;
                }
            }
        }
    }

    /// Score capture moves using MVV-LVA, promotion bonus, and capture history.
    fn score_captures(&mut self, board: &Board, searcher: &Searcher) {
        for i in 0..self.moves.len {
            let mv = self.moves.as_slice()[i];
            let attacker = board
                .piece_on(mv.from)
                .map(|p| p.kind.index())
                .unwrap_or(0);
            let victim = match mv.flag {
                MoveFlag::EnPassant => 0,
                _ => board
                    .piece_on(mv.to)
                    .map(|p| p.kind.index())
                    .unwrap_or(0),
            };
            let cap_h = searcher.get_capture_history(attacker, mv.to.index(), victim);
            self.scores[i] = 100_000 + mvv_lva(board, mv) + cap_h.clamp(-30_000, 30_000);
            if let Some(pt) = mv.promotion() {
                self.scores[i] += piece_value(pt);
            }
        }
    }

    /// Score quiet moves using main history table and continuation history tables.
    fn score_quiets(&mut self, board: &Board, searcher: &Searcher) {
        let side = board.side.index();
        let prev_move_1 = if self.ply > 0 {
            searcher.get_move_stack(self.ply - 1)
        } else {
            None
        };
        let prev_move_2 = if self.ply > 1 {
            searcher.get_move_stack(self.ply - 2)
        } else {
            None
        };
        let prev1_pt_to = if prev_move_1.is_some() {
            Some(searcher.get_piece_stack(self.ply - 1))
        } else {
            None
        };
        let prev2_pt_to = if prev_move_2.is_some() {
            Some(searcher.get_piece_stack(self.ply - 2))
        } else {
            None
        };

        for i in 0..self.moves.len {
            let mv = self.moves.as_slice()[i];
            let hist = searcher.get_history(side, mv.from.index(), mv.to.index());
            let cur_pt = board
                .piece_on(mv.from)
                .map(|p| p.kind.index())
                .unwrap_or(0);

            let cont1 = if let Some((ppt, pto)) = prev1_pt_to {
                searcher.get_cont_hist_1ply(ppt, pto, cur_pt, mv.to.index())
            } else {
                0
            };
            let cont2 = if let Some((ppt, pto)) = prev2_pt_to {
                searcher.get_cont_hist_2ply(ppt, pto, cur_pt, mv.to.index())
            } else {
                0
            };

            self.scores[i] = hist + cont1 + cont2;
        }
    }

    /// Selection sort: finds maximum remaining score and swaps it to current `self.index`.
    fn partial_sort(&mut self) {
        let mut best_idx = self.index;
        for j in (self.index + 1)..self.moves.len {
            if self.scores[j] > self.scores[best_idx] {
                best_idx = j;
            }
        }
        self.moves.as_mut_slice().swap(self.index, best_idx);
        self.scores.swap(self.index, best_idx);
    }


}
