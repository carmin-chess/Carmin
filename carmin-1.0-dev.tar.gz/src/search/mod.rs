//! Comprehensive search module for the Carmin chess engine.
//!
//! Submodules:
//! - `params`: Search constants, thresholds, and configuration parameters.
//! - `statistics`: Node counters, performance metrics, and UCI reporting.
//! - `pv`: Principal Variation table and PV line extraction utilities.
//! - `time`: Time control manager and limit calculators.
//! - `see`: Static Exchange Evaluation (SEE) algorithms.
//! - `move_ordering`: Stage-based MovePicker, history heuristic, and killer moves.
//! - `quiescence`: Quiescence search framework for tactical resolution.
//! - `extensions`: Check and pawn push search extension logic.
//! - `searcher`: Searcher thread state context struct and methods.
//! - `negamax`: Core recursive Negamax alpha-beta search algorithm.
//! - `iterative`: Iterative deepening search loop with aspiration windows.

pub mod extensions;
pub mod r#final;
pub mod iterative;
pub mod move_ordering;
pub mod negamax;
pub mod params;
pub mod pv;
pub mod quiescence;
pub mod see;
pub mod searcher;
pub mod statistics;
pub mod time;

pub use extensions::compute_extensions;
pub use move_ordering::{MovePicker, MovePickerStage};
pub use negamax::{tt_score_from, tt_score_to};
pub use params::*;
pub use pv::{PvCollector, PvTable};
pub use searcher::Searcher;
pub use statistics::{SearchStats, UciInfoReporter, UciScore};
pub use time::{compute_time_limit, compute_time_limits, SearchLimits, TimeManager};

static LMR_TABLE_STATIC: std::sync::OnceLock<[[i32; 64]; 64]> = std::sync::OnceLock::new();

/// Late Move Reduction (LMR) table lookup helper.
pub fn lmr(depth: usize, moves: usize) -> i32 {
    let table = LMR_TABLE_STATIC.get_or_init(|| {
        let mut t = [[0i32; 64]; 64];
        for d in 1..64 {
            for m in 1..64 {
                t[d][m] = (0.77 + (d as f64).ln() * (m as f64).ln() / 2.36) as i32;
            }
        }
        t
    });
    table[depth.min(63)][moves.min(63)]
}
