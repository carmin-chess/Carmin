//! Static Exchange Evaluation (SEE) module.
//!
//! SEE evaluates tactical exchanges on a target square without performing full board updates
//! or deeper search trees. It returns whether a move wins or preserves material above a given threshold.

use crate::board::Board;
use crate::types::{Color, Move, MoveFlag, PieceType, Square};

/// Returns standard piece centipawn value for SEE calculations.
#[inline]
pub fn piece_value(pt: PieceType) -> i32 {
    match pt {
        PieceType::Pawn => 100,
        PieceType::Knight => 325,
        PieceType::Bishop => 335,
        PieceType::Rook => 500,
        PieceType::Queen => 975,
        PieceType::King => 20000,
    }
}

/// Computes Most Valuable Victim - Least Valuable Attacker (MVV-LVA) heuristic value.
#[inline]
pub fn mvv_lva(board: &Board, mv: Move) -> i32 {
    let victim = match mv.flag {
        MoveFlag::EnPassant => PieceType::Pawn,
        _ => match board.piece_on(mv.to) {
            Some(p) => p.kind,
            None => return 0,
        },
    };
    let attacker = board
        .piece_on(mv.from)
        .map(|p| p.kind)
        .unwrap_or(PieceType::King);
    piece_value(victim) * 16 - piece_value(attacker)
}

/// Checks if a side has any non-pawn material remaining (useful for endgame / NMP conditions).
#[inline]
pub fn has_non_pawn_material(board: &Board, color: Color) -> bool {
    board.pieces_of(color, PieceType::Knight) != 0
        || board.pieces_of(color, PieceType::Bishop) != 0
        || board.pieces_of(color, PieceType::Rook) != 0
        || board.pieces_of(color, PieceType::Queen) != 0
}

/// Finds the least valuable attacker of a square `sq` belonging to `side` within current occupancy `occ`.
pub fn least_valuable_attacker(
    board: &Board,
    sq: Square,
    occ: u64,
    side: Color,
) -> Option<(PieceType, Square)> {
    let pawns = board.pieces_of(side, PieceType::Pawn) & occ;
    let pawn_attackers = pawns & crate::attacks::pawn_attacks(side.opponent(), sq);
    if pawn_attackers != 0 {
        return Some((PieceType::Pawn, crate::bitboard::lsb(pawn_attackers)));
    }

    let knights = board.pieces_of(side, PieceType::Knight) & occ;
    let knight_attackers = knights & crate::attacks::knight_attacks(sq);
    if knight_attackers != 0 {
        return Some((PieceType::Knight, crate::bitboard::lsb(knight_attackers)));
    }

    let bishops = board.pieces_of(side, PieceType::Bishop) & occ;
    let bishop_attackers = bishops & crate::attacks::bishop_attacks(sq, occ);
    if bishop_attackers != 0 {
        return Some((PieceType::Bishop, crate::bitboard::lsb(bishop_attackers)));
    }

    let rooks = board.pieces_of(side, PieceType::Rook) & occ;
    let rook_attackers = rooks & crate::attacks::rook_attacks(sq, occ);
    if rook_attackers != 0 {
        return Some((PieceType::Rook, crate::bitboard::lsb(rook_attackers)));
    }

    let queens = board.pieces_of(side, PieceType::Queen) & occ;
    let queen_attackers = queens & crate::attacks::queen_attacks(sq, occ);
    if queen_attackers != 0 {
        return Some((PieceType::Queen, crate::bitboard::lsb(queen_attackers)));
    }

    let kings = board.pieces_of(side, PieceType::King) & occ;
    let king_attackers = kings & crate::attacks::king_attacks(sq);
    if king_attackers != 0 {
        return Some((PieceType::King, crate::bitboard::lsb(king_attackers)));
    }

    None
}

/// Static Exchange Evaluation predicate test: returns true if SEE score >= threshold.
pub fn see_ge(board: &Board, mv: Move, threshold: i32) -> bool {
    let from = mv.from;
    let to = mv.to;

    let victim_val = if mv.is_capture() {
        match mv.flag {
            MoveFlag::EnPassant => piece_value(PieceType::Pawn),
            _ => board.piece_on(to).map_or(0, |p| piece_value(p.kind)),
        }
    } else {
        0
    };

    let mut swap = victim_val - threshold;
    if swap < 0 {
        return false;
    }

    let attacker_pt = mv
        .promotion()
        .unwrap_or_else(|| board.piece_on(from).map_or(PieceType::Pawn, |p| p.kind));

    swap = piece_value(attacker_pt) - swap;
    if swap <= 0 {
        return true;
    }

    let mut occ = board.occupancy ^ from.bb();
    if mv.flag == MoveFlag::EnPassant {
        let ep_sq = Square::new(if board.side == Color::White {
            (to.index() - 8) as u8
        } else {
            (to.index() + 8) as u8
        });
        occ ^= ep_sq.bb();
    }

    let mut color = board.side.opponent();
    let mut res = 1;

    loop {
        if let Some((pt, sq)) = least_valuable_attacker(board, to, occ, color) {
            occ ^= sq.bb();
            swap = piece_value(pt) - swap;
            color = color.opponent();
            res ^= 1;
            if swap <= 0 {
                return res == 1;
            }
        } else {
            return res == 1;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_piece_values() {
        assert_eq!(piece_value(PieceType::Pawn), 100);
        assert_eq!(piece_value(PieceType::Queen), 975);
    }
}
