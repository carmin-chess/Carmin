//! Pawn Hash Table
//!
//! Cacheia a contribuição de score (mg/eg, por cor) e os candidate
//! passers calculados por `eval::pawns` + `eval::advanced_pawns` pra
//! uma dada estrutura de peões (chave = hash Zobrist só dos peões,
//! brancos e pretos juntos). Como a estrutura de peões muda pouco
//! lance a lance comparado com o resto do tabuleiro, isso evita
//! reprocessar ilhas/isolados/dobrados/backward/phalanx/buracos em
//! toda chamada de `evaluate()`.

pub struct PawnCacheEntry {
    pub key: u64,
    pub mg: [i32; 2],
    pub eg: [i32; 2],
    pub candidate_passers: [u64; 2],
}

pub struct PawnCache {
    entries: Vec<PawnCacheEntry>,
    mask: usize,
}

impl PawnCache {
    pub fn new() -> Self {
        // Potência de 2 pra permitir indexação via máscara (mais barato que %).
        const SIZE: usize = 1 << 16; // 65536 entradas ~ 1.5MB, cabe fácil na L2/L3
        let mut entries = Vec::with_capacity(SIZE);
        for _ in 0..SIZE {
            entries.push(PawnCacheEntry {
                key: 0,
                mg: [0, 0],
                eg: [0, 0],
                candidate_passers: [0, 0],
            });
        }
        Self { entries, mask: SIZE - 1 }
    }

    #[inline]
    pub fn probe(&self, key: u64) -> Option<&PawnCacheEntry> {
        let idx = (key as usize) & self.mask;
        let entry = &self.entries[idx];
        // key == 0 e key real 0 (posição sem peões) colidem raramente;
        // como o valor pra "sem peões" é sempre 0 mesmo, não há problema prático.
        if entry.key == key {
            Some(entry)
        } else {
            None
        }
    }

    #[inline]
    pub fn store(&mut self, key: u64, mg: [i32; 2], eg: [i32; 2], candidate_passers: [u64; 2]) {
        let idx = (key as usize) & self.mask;
        self.entries[idx] = PawnCacheEntry { key, mg, eg, candidate_passers };
    }
}

impl Default for PawnCache {
    fn default() -> Self {
        Self::new()
    }
}
