use carmin::attacks;
use carmin::uci;

fn main() {
    // Build attack/zobrist tables up front so the first search isn't slowed.
    attacks::init();
    uci::run();
}
