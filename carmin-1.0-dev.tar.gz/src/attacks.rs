//! Precomputed attack tables.
//!
//! Leaper attacks (pawn/knight/king) are simple lookup arrays. Sliding
//! attacks (bishop/rook/queen) use magic bitboards, with the magic
//! numbers found once at startup.

use crate::bitboard::*;
use crate::types::{Color, Square};
use std::sync::OnceLock;

// Helper nativo do Rust para contar os bits 1
#[inline]
pub fn popcount(bb: Bitboard) -> u32 {
    bb.count_ones()
}

struct AttackTables {
    knight: [Bitboard; 64],
    king: [Bitboard; 64],
    pawn: [[Bitboard; 64]; 2],
    rook: MagicTable,
    bishop: MagicTable,
    line_through: [[Bitboard; 64]; 64],
}

struct Magic {
    mask: Bitboard,
    magic: u64,
    shift: u32,
    offset: usize,
}

struct MagicTable {
    magics: Vec<Magic>,
    attacks: Vec<Bitboard>,
}

impl MagicTable {
    #[inline]
    fn attacks(&self, sq: Square, occ: Bitboard) -> Bitboard {
        let idx = sq.index();
        if idx >= 64 {
            return 0;
        }
        let m = &self.magics[idx];
        let idx = (((occ & m.mask).wrapping_mul(m.magic)) >> m.shift) as usize;
        self.attacks[m.offset + idx]
    }
}

static TABLES: OnceLock<AttackTables> = OnceLock::new();

fn tables() -> &'static AttackTables {
    TABLES.get_or_init(build_tables)
}

/// Force initialization of the attack tables
pub fn init() {
    tables();
}

#[inline]
pub fn knight_attacks(sq: Square) -> Bitboard {
    let idx = sq.index();
    if idx >= 64 {
        return 0;
    }
    tables().knight[idx]
}

#[inline]
pub fn king_attacks(sq: Square) -> Bitboard {
    let idx = sq.index();
    if idx >= 64 {
        return 0;
    }
    tables().king[idx]
}

#[inline]
pub fn pawn_attacks(color: Color, sq: Square) -> Bitboard {
    let idx = sq.index();
    if idx >= 64 {
        return 0;
    }
    tables().pawn[color.index()][idx]
}

#[inline]
pub fn bishop_attacks(sq: Square, occ: Bitboard) -> Bitboard {
    tables().bishop.attacks(sq, occ)
}

#[inline]
pub fn rook_attacks(sq: Square, occ: Bitboard) -> Bitboard {
    tables().rook.attacks(sq, occ)
}

#[inline]
pub fn queen_attacks(sq: Square, occ: Bitboard) -> Bitboard {
    bishop_attacks(sq, occ) | rook_attacks(sq, occ)
}

#[inline]
pub fn line_through(sq1: Square, sq2: Square) -> Bitboard {
    let idx1 = sq1.index();
    let idx2 = sq2.index();
    if idx1 >= 64 || idx2 >= 64 {
        return 0;
    }
    tables().line_through[idx1][idx2]
}

// --- Table construction ---------------------------------------------------

fn build_tables() -> AttackTables {
    let mut knight = [0u64; 64];
    let mut king = [0u64; 64];
    let mut pawn = [[0u64; 64]; 2];
    let mut line_through = [[0u64; 64]; 64];

    // Constantes hardcoded para evitar dependência externa de máscaras no crate::bitboard
    let not_a = 0xfefefefefefefefe;
    let not_h = 0x7f7f7f7f7f7f7f7f;

    for sq in 0..64u8 {
        let bb = 1u64 << sq;
        knight[sq as usize] = knight_from(bb);
        king[sq as usize] = king_from(bb);
        
        // White pawns attack up the board, black pawns attack down.
        pawn[Color::White.index()][sq as usize] =
            ((bb & not_a) << 7) | ((bb & not_h) << 9);
        pawn[Color::Black.index()][sq as usize] =
            ((bb & not_h) >> 7) | ((bb & not_a) >> 9);
    }

    let rook = build_magics(true);
    let bishop = build_magics(false);

    // Pré-computa a linha inteira que atravessa sq1 e sq2 se estiverem alinhados
    for sq1 in 0..64u8 {
        let r1 = slider_attacks(sq1, 0, &ROOK_DIRS);
        let b1 = slider_attacks(sq1, 0, &BISHOP_DIRS);

        for sq2 in 0..64u8 {
            let bb2 = 1u64 << sq2;
            if (r1 & bb2) != 0 {
                let r2 = slider_attacks(sq2, 0, &ROOK_DIRS);
                line_through[sq1 as usize][sq2 as usize] = (r1 & r2) | (1u64 << sq1) | bb2;
            } else if (b1 & bb2) != 0 {
                let b2 = slider_attacks(sq2, 0, &BISHOP_DIRS);
                line_through[sq1 as usize][sq2 as usize] = (b1 & b2) | (1u64 << sq1) | bb2;
            } else {
                line_through[sq1 as usize][sq2 as usize] = 0;
            }
        }
    }

    AttackTables {
        knight,
        king,
        pawn,
        rook,
        bishop,
        line_through,
    }
}

fn knight_from(bb: Bitboard) -> Bitboard {
    let not_a = 0xfefefefefefefefe;
    let not_ab = 0xfcfcfcfcfcfcfcfc;
    let not_h = 0x7f7f7f7f7f7f7f7f;
    let not_gh = 0x3f3f3f3f3f3f3f3f;
    
    let l1 = (bb >> 1) & not_h;
    let l2 = (bb >> 2) & not_gh;
    let r1 = (bb << 1) & not_a;
    let r2 = (bb << 2) & not_ab;
    let h1 = l1 | r1;
    let h2 = l2 | r2;
    (h1 << 16) | (h1 >> 16) | (h2 << 8) | (h2 >> 8)
}

fn king_from(bb: Bitboard) -> Bitboard {
    let not_a = 0xfefefefefefefefe;
    let not_h = 0x7f7f7f7f7f7f7f7f;
    let mut attacks = ((bb & not_a) >> 1) | ((bb & not_h) << 1);
    let row = attacks | bb;
    attacks |= row << 8;
    attacks |= row >> 8;
    attacks
}

const ROOK_DIRS: [(i8, i8); 4] = [(0, 1), (0, -1), (1, 0), (-1, 0)];
const BISHOP_DIRS: [(i8, i8); 4] = [(1, 1), (1, -1), (-1, 1), (-1, -1)];

fn slider_attacks(sq: u8, occ: Bitboard, dirs: &[(i8, i8); 4]) -> Bitboard {
    let mut attacks = 0u64;
    let f0 = (sq % 8) as i8;
    let r0 = (sq / 8) as i8;
    for &(df, dr) in dirs {
        let mut f = f0 + df;
        let mut r = r0 + dr;
        while (0..8).contains(&f) && (0..8).contains(&r) {
            let s = (r * 8 + f) as u8;
            attacks |= 1u64 << s;
            if occ & (1u64 << s) != 0 {
                break;
            }
            f += df;
            r += dr;
        }
    }
    attacks
}

fn slider_mask(sq: u8, dirs: &[(i8, i8); 4]) -> Bitboard {
    let mut mask = 0u64;
    let f0 = (sq % 8) as i8;
    let r0 = (sq / 8) as i8;
    for &(df, dr) in dirs {
        let mut f = f0 + df;
        let mut r = r0 + dr;
        while (0..8).contains(&f)
            && (0..8).contains(&r)
            && (0..8).contains(&(f + df))
            && (0..8).contains(&(r + dr))
        {
            mask |= 1u64 << (r * 8 + f);
            f += df;
            r += dr;
        }
    }
    mask
}

fn subset(index: usize, mask: Bitboard) -> Bitboard {
    let mut result = 0u64;
    let mut bits = mask;
    let mut i = index;
    while bits != 0 {
        let bit = bits & bits.wrapping_neg();
        bits &= bits - 1;
        if i & 1 != 0 {
            result |= bit;
        }
        i >>= 1;
    }
    result
}

struct Rng(u64);

impl Rng {
    fn next(&mut self) -> u64 {
        let mut x = self.0;
        x ^= x << 13;
        x ^= x >> 7;
        x ^= x << 17;
        self.0 = x;
        x
    }
    fn sparse(&mut self) -> u64 {
        self.next() & self.next() & self.next()
    }
}

fn build_magics(rook: bool) -> MagicTable {
    let dirs = if rook { &ROOK_DIRS } else { &BISHOP_DIRS };
    let mut magics: Vec<Magic> = Vec::with_capacity(64);
    let mut attacks: Vec<Bitboard> = Vec::new();
    let mut rng = Rng(0x1234_5678_9abc_def1);

    for sq in 0..64u8 {
        let mask = slider_mask(sq, dirs);
        let bits = popcount(mask);
        let size = 1usize << bits;
        let shift = 64 - bits;

        let mut occupancies = vec![0u64; size];
        let mut references = vec![0u64; size];
        for (i, occ) in occupancies.iter_mut().enumerate() {
            *occ = subset(i, mask);
            references[i] = slider_attacks(sq, *occ, dirs);
        }

        // Os buffers 'table' e 'used' são alocados UMA única vez por casa (sq)
        let mut table = vec![0u64; size];
        let mut used = vec![false; size];

        let magic = loop {
            let candidate = rng.sparse();
            if bits >= 6 && popcount((mask.wrapping_mul(candidate)) >> 56) < 6 {
                continue;
            }
            
            // Limpa o conteúdo dos buffers existentes em vez de realocar na heap
            table.fill(0);
            used.fill(false);
            
            let mut ok = true;
            for i in 0..size {
                let idx = ((occupancies[i].wrapping_mul(candidate)) >> shift) as usize;
                if used[idx] && table[idx] != references[i] {
                    ok = false;
                    break;
                }
                used[idx] = true;
                table[idx] = references[i];
            }
            if ok {
                break candidate;
            }
        };

        let offset = attacks.len();
        attacks.extend_from_slice(&table);
        magics.push(Magic {
            mask,
            magic,
            shift,
            offset,
        });
    }

    MagicTable { magics, attacks }
}
