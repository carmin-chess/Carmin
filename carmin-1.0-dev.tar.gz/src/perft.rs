//! Perft: count leaf nodes of the move tree to validate move generation.

use crate::board::Board;
use crate::movegen::generate_legal;

pub fn perft(board: &mut Board, depth: u32) -> u64 {
    if depth == 0 {
        return 1;
    }
    let moves = generate_legal(board);
    if depth == 1 {
        return moves.len as u64;
    }
    let mut nodes = 0;
    for &mv in moves.as_slice() {
        let undo = board.make_move(mv);
        nodes += perft(board, depth - 1);
        board.unmake_move(mv, undo);
    }
    nodes
}

/// Perft with a per-root-move breakdown ("divide"), useful for debugging.
pub fn perft_divide(board: &mut Board, depth: u32) -> u64 {
    let moves = generate_legal(board);
    let mut total = 0;
    for &mv in moves.as_slice() {
        let undo = board.make_move(mv);
        let nodes = if depth <= 1 { 1 } else { perft(board, depth - 1) };
        board.unmake_move(mv, undo);
        println!("{}: {}", mv.to_uci(), nodes);
        total += nodes;
    }
    println!("\nTotal: {}", total);
    total
}
