//! Personalities inspired by Komodo Dragon.
//!
//! Each personality adjusts evaluation weights (via multipliers) and contempt
//! to produce distinct playing styles without changing the core engine strength
//! too drastically. Default remains the strongest balanced personality.

use std::sync::atomic::{AtomicU8, Ordering};

/// Current active personality (shared across all threads).
static CURRENT_PERSONALITY: AtomicU8 = AtomicU8::new(0); // 0 = Default

#[derive(Clone, Copy, Debug, PartialEq, Eq)]
#[repr(u8)]
pub enum Personality {
    Default = 0,
    Aggressive = 1,
    Defensive = 2,
    Positional = 3,
    Active = 4,
    Human = 5,
    Passive = 6,
    AntiCarmin = 7,
}

impl Personality {
    pub fn from_str(s: &str) -> Option<Self> {
        match s.to_lowercase().as_str() {
            "default" => Some(Self::Default),
            "aggressive" => Some(Self::Aggressive),
            "defensive" => Some(Self::Defensive),
            "positional" => Some(Self::Positional),
            "active" => Some(Self::Active),
            "human" => Some(Self::Human),
            "passive" => Some(Self::Passive),
            "anticarmin" => Some(Self::AntiCarmin),
            _ => None,
        }
    }

    pub fn as_str(self) -> &'static str {
        match self {
            Self::Default => "Default",
            Self::Aggressive => "Aggressive",
            Self::Defensive => "Defensive",
            Self::Positional => "Positional",
            Self::Active => "Active",
            Self::Human => "Human",
            Self::Passive => "Passive",
            Self::AntiCarmin => "AntiCarmin",
        }
    }

    pub fn all() -> &'static [Self] {
        &[
            Self::Default,
            Self::Aggressive,
            Self::Defensive,
            Self::Positional,
            Self::Active,
            Self::Human,
            Self::Passive,
            Self::AntiCarmin,
        ]
    }

    pub fn from_u8(v: u8) -> Self {
        match v {
            1 => Self::Aggressive,
            2 => Self::Defensive,
            3 => Self::Positional,
            4 => Self::Active,
            5 => Self::Human,
            6 => Self::Passive,
            7 => Self::AntiCarmin,
            _ => Self::Default,
        }
    }
}

/// Multipliers are in percent (100 = normal).
#[derive(Clone, Copy, Debug)]
pub struct PersonalityConfig {
    pub personality: Personality,
    /// Mobility weight
    pub mobility: i32,
    /// Threats / attacking weight
    pub threats: i32,
    /// King safety / danger weight (higher = more careful about king safety)
    pub king_safety: i32,
    /// Space control
    pub space: i32,
    /// Passed pawns & advanced pawns
    pub passed: i32,
    /// Initiative / activity bias
    pub initiative: i32,
    /// Contempt for draws (centipawns). Positive = prefer to play on rather than accept draw.
    pub contempt: i32,
}

impl PersonalityConfig {
    pub const fn for_personality(p: Personality) -> Self {
        match p {
            Personality::Default => Self {
                personality: p,
                mobility: 100,
                threats: 100,
                king_safety: 100,
                space: 100,
                passed: 100,
                initiative: 100,
                contempt: -20,
            },
            // Relentless attack, undervalues own king safety, loves threats & activity
            Personality::Aggressive => Self {
                personality: p,
                mobility: 130,
                threats: 150,
                king_safety: 65,
                space: 110,
                passed: 105,
                initiative: 140,
                contempt: 35,
            },
            // Solid, prioritises king safety and structure, less tactical
            Personality::Defensive => Self {
                personality: p,
                mobility: 85,
                threats: 70,
                king_safety: 145,
                space: 95,
                passed: 90,
                initiative: 70,
                contempt: -40,
            },
            // Prefers closed/semi-closed play, space, pawn structure, long-term advantages
            Personality::Positional => Self {
                personality: p,
                mobility: 95,
                threats: 80,
                king_safety: 115,
                space: 140,
                passed: 130,
                initiative: 90,
                contempt: -10,
            },
            // Active pieces, open positions, but not suicidal
            Personality::Active => Self {
                personality: p,
                mobility: 120,
                threats: 120,
                king_safety: 85,
                space: 115,
                passed: 110,
                initiative: 125,
                contempt: 15,
            },
            // Human-like: avoids sterile simplifications, keeps tension, slight aggression
            Personality::Human => Self {
                personality: p,
                mobility: 110,
                threats: 115,
                king_safety: 95,
                space: 105,
                passed: 100,
                initiative: 120,
                contempt: 25,
            },
            // Passive: low activity, high caution, accepts draws more easily, solid but timid
            Personality::Passive => Self {
                personality: p,
                mobility: 70,
                threats: 55,
                king_safety: 160,
                space: 80,
                passed: 85,
                initiative: 50,
                contempt: -55,
            },
            Personality::AntiCarmin => Self {
                personality: p,
                mobility: -100,
                threats: -100,
                king_safety: -100,
                space: -100,
                passed: -100,
                initiative: -100,
                contempt: -100,
            },
        }
    }
    

    #[inline]
    pub fn scale(self, value: i32, mult: i32) -> i32 {
        (value * mult) / 100
    }
}

/// Set the global personality (called from UCI setoption).
pub fn set_personality(p: Personality) {
    CURRENT_PERSONALITY.store(p as u8, Ordering::Relaxed);
}

/// Read the currently active personality.
pub fn current() -> Personality {
    Personality::from_u8(CURRENT_PERSONALITY.load(Ordering::Relaxed))
}

/// Get the config for the currently active personality.
#[inline]
pub fn config() -> PersonalityConfig {
    PersonalityConfig::for_personality(current())
}
