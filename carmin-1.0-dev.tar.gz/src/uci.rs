//! UCI protocol front-end.
//!
//! Stdin is parsed on the main thread; searching happens on dedicated
//! threads so that `stop` and `ponderhit` can interrupt an ongoing search.
//!
//! Multi-session + concurrent searches:
//!   Cada `go` cria o seu próprio conjunto de Searchers e roda em paralelo.
//!   Assim você pode ter 2 (ou mais) searches em posições diferentes ao mesmo tempo.
//!
//! Comandos de sessão (funcionam no meio de search/perft):
//!   session / sess          → status da sessão atual
//!   session list            → lista todas
//!   session new             → cria nova (startpos)
//!   session N               → troca para índice N
//!   session next / prev     → navega (com wrap)
//!   session del             → remove a atual
//!   bash                    → spawna shell interativo

use crate::board::Board;
use crate::eval;
use crate::perft::perft_divide;
use crate::personality::{self, Personality};
use crate::search::{SearchLimits, Searcher};
use crate::tt::TranspositionTable;
use crate::types::{Move, PieceType, Square};
use std::io::{self, BufRead, Write};
use std::sync::atomic::{AtomicBool, Ordering};
use std::sync::mpsc;
use std::sync::Arc;
use std::thread;

const NAME: &str = "Carmin";
const AUTHOR: &str = "Cawl";
const DEFAULT_TT_MB: usize = 128;
const DEFAULT_THREADS: usize = 4;
const DEFAULT_MULTIPV: usize = 1;
const DEFAULT_SKILL_LEVEL: usize = 1;

struct Session {
    board: Board,
    move_history: Vec<String>,
}

enum Command {
    NewGame,
    Position(Box<Board>, Vec<String>),
    Go(SearchLimits),
    Perft(u32),
    PonderHit,
    SetOption {
        hash_mb: Option<usize>,
        threads: Option<usize>,
        multipv: Option<usize>,
        skill_level: Option<usize>,
        personality: Option<Personality>,
    },
    Quit,
}

pub fn run() {
    let stop = Arc::new(AtomicBool::new(false));
    let pondering = Arc::new(AtomicBool::new(false));

    let (tx, rx) = mpsc::channel();

    let worker_stop = Arc::clone(&stop);
    let worker_pondering = Arc::clone(&pondering);

    let worker = thread::spawn(move || {
        let mut tt_mb = DEFAULT_TT_MB;
        let mut num_threads = DEFAULT_THREADS;
        let mut multipv = DEFAULT_MULTIPV;
        let mut skill_level = DEFAULT_SKILL_LEVEL;

        let mut tt = Arc::new(TranspositionTable::new(tt_mb));
        // Mantemos um conjunto "template" só para recriar fácil no SetOption.
        // Cada Go cria o seu próprio conjunto e roda em paralelo.
        let mut searchers: Vec<Searcher> = (0..num_threads)
            .map(|i| {
                let mut s = Searcher::new(Arc::clone(&tt), i == 0, num_threads);
                s.multipv = multipv.max(1);
                s.skill_level = skill_level;
                s.contempt = personality::config().contempt;
                s
            })
            .collect();

        let mut board = Board::startpos();
        let mut move_history: Vec<String> = Vec::new();

        while let Ok(cmd) = rx.recv() {
            match cmd {
                Command::NewGame => {
                    if !cfg!(feature = "disable_tt") {
                        tt.clear();
                    }
                    for searcher in &mut searchers {
                        searcher.new_game();
                    }
                    move_history.clear();
                }
                Command::SetOption {
                    hash_mb,
                    threads,
                    multipv: mp,
                    skill_level: sl,
                    personality,
                } => {
                    if let Some(s) = sl {
                        skill_level = s.clamp(1, 20);
                        for searcher in &mut searchers {
                            searcher.skill_level = skill_level;
                        }
                    }
                    if let Some(m) = mp {
                        multipv = m.clamp(1, 500);
                    }

                    let effective_multipv = multipv.max(1);
                    for searcher in &mut searchers {
                        searcher.multipv = effective_multipv;
                    }

                    if let Some(p) = personality {
                        personality::set_personality(p);
                        let cfg = personality::config();
                        for searcher in &mut searchers {
                            searcher.contempt = cfg.contempt;
                        }
                    }

                    if let Some(mb) = hash_mb {
                        tt_mb = mb.clamp(1, 16384);
                        tt = Arc::new(TranspositionTable::new(tt_mb));
                        let cfg = personality::config();
                        searchers = (0..num_threads)
                            .map(|i| {
                                let mut s = Searcher::new(Arc::clone(&tt), i == 0, num_threads);
                                s.multipv = effective_multipv;
                                s.skill_level = skill_level;
                                s.contempt = cfg.contempt;
                                s
                            })
                            .collect();
                    }
                    if let Some(t) = threads {
                        num_threads = t.clamp(1, 512);
                        let cfg = personality::config();
                        searchers = (0..num_threads)
                            .map(|i| {
                                let mut s = Searcher::new(Arc::clone(&tt), i == 0, num_threads);
                                s.multipv = effective_multipv;
                                s.skill_level = skill_level;
                                s.contempt = cfg.contempt;
                                s
                            })
                            .collect();
                    }
                }
                Command::Position(b, hist) => {
                    board = *b;
                    move_history = hist;
                }
                Command::PonderHit => {
                    worker_pondering.store(false, Ordering::SeqCst);
                }
                Command::Perft(depth) => {
                    // Roda no worker (main continua livre para session/stop).
                    worker_stop.store(false, Ordering::SeqCst);
                    let mut b = board.clone();
                    perft_divide(&mut b, depth);
                    io::stdout().flush().ok();
                }
                Command::Go(limits) => {
                    // Cada Go cria SEU próprio conjunto de Searchers e roda
                    // em uma thread separada. O loop do worker NÃO bloqueia,
                    // então vários Goes podem rodar em paralelo.
                    worker_stop.store(false, Ordering::SeqCst);

                    if limits.ponder {
                        worker_pondering.store(true, Ordering::SeqCst);
                    } else {
                        worker_pondering.store(false, Ordering::SeqCst);
                    }

                    if !cfg!(feature = "disable_tt") {
                        tt.new_search();
                    }

                    let board_clone = board.clone();
                    let hist_clone = move_history.clone();
                    let limits_clone = limits.clone();
                    let stop_clone = Arc::clone(&worker_stop);
                    let ponder_clone = Arc::clone(&worker_pondering);
                    let tt_clone = Arc::clone(&tt);
                    let n_threads = num_threads;
                    let mp = multipv.max(1);
                    let sk = skill_level;
                    let cfg = personality::config();

                    // Cria searchers frescos só para este search
                    let mut this_searchers: Vec<Searcher> = (0..n_threads)
                        .map(|i| {
                            let mut s = Searcher::new(Arc::clone(&tt_clone), i == 0, n_threads);
                            s.multipv = mp;
                            s.skill_level = sk;
                            s.contempt = cfg.contempt;
                            s
                        })
                        .collect();

                    // Spawna o search em background — worker continua recebendo
                    thread::spawn(move || {
                        let searchers_moved = std::mem::take(&mut this_searchers);

                        let _returned = thread::scope(|s| {
                            let mut handles = Vec::with_capacity(n_threads);
                            for (i, mut searcher) in searchers_moved.into_iter().enumerate() {
                                let board_c = board_clone.clone();
                                let limits_c = limits_clone.clone();
                                let hist_c = hist_clone.clone();
                                let stop_c = Arc::clone(&stop_clone);
                                let ponder_c = Arc::clone(&ponder_clone);

                                searcher.set_stop_signal(Arc::clone(&stop_c));
                                searcher.set_ponder_signal(Arc::clone(&ponder_c));
                                searcher.multipv = mp;
                                searcher.skill_level = sk;

                                handles.push(s.spawn(move || {
                                    let searched =
                                        searcher.search(&board_c, &limits_c, &hist_c);
                                    if i == 0 {
                                        stop_c.store(true, Ordering::SeqCst);

                                        let chosen = if searcher.skill_level <= 1 {
                                            searched.or_else(|| searcher.get_skill_move(&board_c))
                                        } else {
                                            searcher.get_skill_move(&board_c).or(searched)
                                        };

                                        match chosen {
                                            Some(mv) => {
                                                let mut board_after = board_c.clone();
                                                board_after.make_move(mv);

                                                match searcher.ponder_move(mv, &board_after) {
                                                    Some(ponder_mv) => println!(
                                                        "bestmove {} ponder {}",
                                                        mv.to_uci(),
                                                        ponder_mv.to_uci()
                                                    ),
                                                    None => println!("bestmove {}", mv.to_uci()),
                                                }
                                            }
                                            None => println!("bestmove 0000"),
                                        }
                                        io::stdout().flush().ok();
                                    }
                                    searcher
                                }));
                            }

                            let mut res = Vec::with_capacity(n_threads);
                            for handle in handles {
                                res.push(handle.join().unwrap());
                            }
                            res
                        });
                    });
                }
                Command::Quit => break,
            }
        }
    });

    // ── Multi-session ──────────────────────────────────────────────────────
    let mut sessions: Vec<Session> = vec![Session {
        board: Board::startpos(),
        move_history: Vec::new(),
    }];
    let mut current: usize = 0;

    let stdin = io::stdin();
    for line in stdin.lock().lines() {
        let line = match line {
            Ok(l) => l,
            Err(_) => break,
        };
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        let mut tokens = line.split_whitespace();
        let cmd = tokens.next().unwrap_or("");

        match cmd {
            "uci" => {
                println!("id name {}", NAME);
                println!("id author {}", AUTHOR);
                println!(
                    "option name Hash type spin default {} min 1 max 16384",
                    DEFAULT_TT_MB
                );
                println!(
                    "option name Threads type spin default {} min 1 max 512",
                    DEFAULT_THREADS
                );
                println!(
                    "option name MultiPV type spin default {} min 1 max 500",
                    DEFAULT_MULTIPV
                );
                println!(
                    "option name Skill Level type spin default {} min 1 max 20",
                    DEFAULT_SKILL_LEVEL
                );
                println!("option name Ponder type check default true");
                print!("option name Personality type combo default Default");
                for p in Personality::all() {
                    print!(" var {}", p.as_str());
                }
                println!();
                println!("uciok");
            }
            "isready" => println!("readyok"),
            "ucinewgame" => {
                sessions[current].board = Board::startpos();
                sessions[current].move_history.clear();
                tx.send(Command::NewGame).ok();
            }
            "position" => {
                if let Some((b, hist)) = parse_position(line) {
                    sessions[current].board = b.clone();
                    sessions[current].move_history = hist.clone();
                    tx.send(Command::Position(Box::new(b), hist)).ok();
                }
            }
            "setoption" => {
                let mut hash_mb: Option<usize> = None;
                let mut threads: Option<usize> = None;
                let mut multipv: Option<usize> = None;
                let mut skill_level: Option<usize> = None;
                let mut personality: Option<Personality> = None;

                let line_lc = line.to_lowercase();
                let tokens: Vec<&str> = line_lc.split_whitespace().collect();

                let mut i = 1;
                while i < tokens.len() {
                    if tokens[i] == "name" {
                        if i + 2 < tokens.len()
                            && tokens[i + 1] == "skill"
                            && tokens[i + 2] == "level"
                        {
                            if i + 4 < tokens.len() && tokens[i + 3] == "value" {
                                skill_level = tokens[i + 4].parse().ok();
                                i += 5;
                                continue;
                            }
                        }

                        if i + 1 < tokens.len() {
                            let name = tokens[i + 1];
                            if name == "hash" && i + 3 < tokens.len() && tokens[i + 2] == "value"
                            {
                                hash_mb = tokens[i + 3].parse().ok();
                                i += 4;
                            } else if name == "threads"
                                && i + 3 < tokens.len()
                                && tokens[i + 2] == "value"
                            {
                                threads = tokens[i + 3].parse().ok();
                                i += 4;
                            } else if name == "multipv"
                                && i + 3 < tokens.len()
                                && tokens[i + 2] == "value"
                            {
                                multipv = tokens[i + 3].parse().ok();
                                i += 4;
                            } else if name == "personality"
                                && i + 3 < tokens.len()
                                && tokens[i + 2] == "value"
                            {
                                personality = Personality::from_str(tokens[i + 3]);
                                i += 4;
                            } else {
                                i += 2;
                            }
                        } else {
                            i += 1;
                        }
                    } else {
                        i += 1;
                    }
                }

                if hash_mb.is_some()
                    || threads.is_some()
                    || multipv.is_some()
                    || skill_level.is_some()
                    || personality.is_some()
                {
                    tx.send(Command::SetOption {
                        hash_mb,
                        threads,
                        multipv,
                        skill_level,
                        personality,
                    })
                    .ok();
                }
            }
            "go" => {
                // Sempre envia a posição da sessão atual antes do Go
                let sess = &sessions[current];
                tx.send(Command::Position(
                    Box::new(sess.board.clone()),
                    sess.move_history.clone(),
                ))
                .ok();

                stop.store(false, Ordering::SeqCst);
                let limits = parse_go(line);
                tx.send(Command::Go(limits)).ok();
            }
            "ponderhit" => {
                pondering.store(false, Ordering::SeqCst);
                tx.send(Command::PonderHit).ok();
            }
            "stop" => {
                // Para TODOS os searches que estiverem rodando
                pondering.store(false, Ordering::SeqCst);
                stop.store(true, Ordering::SeqCst);
            }
            "perft" => {
                if let Some(d) = tokens.next().and_then(|s| s.parse::<u32>().ok()) {
                    let sess = &sessions[current];
                    tx.send(Command::Position(
                        Box::new(sess.board.clone()),
                        sess.move_history.clone(),
                    ))
                    .ok();
                    stop.store(false, Ordering::SeqCst);
                    tx.send(Command::Perft(d)).ok();
                }
            }
            "d" | "print" => {
                println!("{}", sessions[current].board.to_fen());
            }
            "eval" => {
                let board = &sessions[current].board;
                let side_score = eval::evaluate(board);
                let white_score = match board.side {
                    crate::types::Color::White => side_score,
                    crate::types::Color::Black => -side_score,
                };

                println!("FEN: {}", board.to_fen());
                println!(
                    "Side to move: {}",
                    match board.side {
                        crate::types::Color::White => "white",
                        crate::types::Color::Black => "black",
                    }
                );
                println!("Static eval (side to move): {side_score} cp");
                println!("Static eval (white): {white_score} cp");
            }
            "clear" => {
                print!("\x1B[2J\x1B[H");
                io::stdout().flush().ok();
            }
            "ucpu" => {
                fn read_cpu_times() -> Option<(u64, u64)> {
                    let data = std::fs::read_to_string("/proc/stat").ok()?;
                    let line = data.lines().next()?;
                    let vals: Vec<u64> = line
                        .split_whitespace()
                        .skip(1)
                        .filter_map(|s| s.parse().ok())
                        .collect();
                    if vals.len() < 4 {
                        return None;
                    }
                    let total: u64 = vals.iter().sum();
                    let idle = vals[3];
                    Some((total, idle))
                }

                match read_cpu_times() {
                    Some((total1, idle1)) => {
                        std::thread::sleep(std::time::Duration::from_millis(250));
                        match read_cpu_times() {
                            Some((total2, idle2)) => {
                                let total_diff = total2.saturating_sub(total1);
                                let idle_diff = idle2.saturating_sub(idle1);
                                let usage = if total_diff > 0 {
                                    100.0 * (1.0 - idle_diff as f64 / total_diff as f64)
                                } else {
                                    0.0
                                };
                                println!("CPU usage: {:.1}%", usage);
                            }
                            None => println!("info string erro ao ler /proc/stat"),
                        }
                    }
                    None => println!("info string /proc/stat nao disponivel (somente Linux)"),
                }
            }

            // ── Multi-session (sempre disponíveis, inclusive no meio de search) ─
            "session" | "sess" => {
                let sub = tokens.next().unwrap_or("");
                match sub {
                    "" | "status" => {
                        println!(
                            "info string session {}/{}  FEN: {}",
                            current,
                            sessions.len().saturating_sub(1),
                            sessions[current].board.to_fen()
                        );
                    }
                    "list" => {
                        for (i, s) in sessions.iter().enumerate() {
                            let marker = if i == current { "*" } else { " " };
                            println!("info string {} [{}] {}", marker, i, s.board.to_fen());
                        }
                    }
                    "new" => {
                        sessions.push(Session {
                            board: Board::startpos(),
                            move_history: Vec::new(),
                        });
                        current = sessions.len() - 1;
                        println!("info string session {} created (startpos)", current);
                    }
                    "next" => {
                        current = if current + 1 < sessions.len() {
                            current + 1
                        } else {
                            0
                        };
                        println!(
                            "info string session {}  FEN: {}",
                            current,
                            sessions[current].board.to_fen()
                        );
                    }
                    "prev" => {
                        current = if current == 0 {
                            sessions.len() - 1
                        } else {
                            current - 1
                        };
                        println!(
                            "info string session {}  FEN: {}",
                            current,
                            sessions[current].board.to_fen()
                        );
                    }
                    "del" | "delete" | "rm" => {
                        if sessions.len() <= 1 {
                            println!("info string cannot delete the only session");
                        } else {
                            sessions.remove(current);
                            if current >= sessions.len() {
                                current = sessions.len() - 1;
                            }
                            println!(
                                "info string session deleted → now {}  FEN: {}",
                                current,
                                sessions[current].board.to_fen()
                            );
                        }
                    }
                    n if n.chars().all(|c| c.is_ascii_digit()) => {
                        if let Ok(idx) = n.parse::<usize>() {
                            if idx < sessions.len() {
                                current = idx;
                                println!(
                                    "info string session {}  FEN: {}",
                                    current,
                                    sessions[current].board.to_fen()
                                );
                            } else {
                                println!(
                                    "info string invalid session {} (0..{})",
                                    idx,
                                    sessions.len().saturating_sub(1)
                                );
                            }
                        }
                    }
                    _ => {
                        println!("info string usage: session [list|new|next|prev|del|N]");
                    }
                }
            }

            "bash" => {
                println!("info string launching bash (type 'exit' to return)");
                io::stdout().flush().ok();
                match std::process::Command::new("bash").status() {
                    Ok(status) => {
                        println!(
                            "info string bash exited with {}",
                            status.code().unwrap_or(-1)
                        );
                    }
                    Err(e) => println!("info string failed to launch bash: {}", e),
                }
            }

            "quit" => {
                stop.store(true, Ordering::SeqCst);
                tx.send(Command::Quit).ok();
                break;
            }
            _ => {}
        }
        io::stdout().flush().ok();
    }

    worker.join().ok();
}

fn parse_position(line: &str) -> Option<(Board, Vec<String>)> {
    let rest = line.strip_prefix("position")?.trim();
    let mut is_standard_start = false;

    let (mut board, after) = if let Some(after) = rest.strip_prefix("startpos") {
        is_standard_start = true;
        (Board::startpos(), after.trim())
    } else if let Some(after) = rest.strip_prefix("fen") {
        let after = after.trim();
        let (fen, remainder) = match after.find(" moves") {
            Some(idx) => (&after[..idx], &after[idx..]),
            None => (after, ""),
        };

        let fen_str = fen.trim();
        if fen_str == "rnbqkbnr/pppppppp/8/8/8/8/PPPPPPPP/RNBQKBNR w KQkq - 0 1" {
            is_standard_start = true;
        }

        (Board::from_fen(fen_str).ok()?, remainder.trim())
    } else {
        return None;
    };

    let mut move_history = Vec::new();

    if let Some(moves_str) = after.strip_prefix("moves") {
        for mv_str in moves_str.split_whitespace() {
            match find_move(&mut board, mv_str) {
                Some(mv) => {
                    board.make_move(mv);
                    move_history.push(mv_str.to_string());
                }
                None => break,
            }
        }
    }

    if !is_standard_start {
        move_history = vec!["DISABLE_BOOK".to_string()];
    }

    Some((board, move_history))
}

fn find_move(board: &mut Board, s: &str) -> Option<Move> {
    if s.len() < 4 {
        return None;
    }
    let from = Square::from_algebraic(&s[0..2])?;
    let to = Square::from_algebraic(&s[2..4])?;
    let promo = s.as_bytes().get(4).and_then(|&c| match c.to_ascii_lowercase() {
        b'q' => Some(PieceType::Queen),
        b'r' => Some(PieceType::Rook),
        b'b' => Some(PieceType::Bishop),
        b'n' => Some(PieceType::Knight),
        _ => None,
    });

    let legal = crate::movegen::generate_legal(board);
    for &mv in legal.as_slice() {
        if mv.from == from && mv.to == to {
            match (promo, mv.promotion()) {
                (Some(p), Some(q)) if p == q => return Some(mv),
                (None, None) => return Some(mv),
                (None, Some(_)) | (Some(_), None) => continue,
                (Some(_), Some(_)) => continue,
            }
        }
    }
    None
}

fn parse_go(line: &str) -> SearchLimits {
    let mut limits = SearchLimits::default();
    let tokens: Vec<&str> = line.split_whitespace().collect();
    let mut i = 1;
    while i < tokens.len() {
        let next = |i: usize| tokens.get(i + 1).and_then(|s| s.parse::<u64>().ok());
        match tokens[i] {
            "ponder" => {
                limits.ponder = true;
                i += 1;
            }
            "depth" => {
                limits.depth = next(i).map(|d| d as i32);
                i += 2;
            }
            "movetime" => {
                limits.movetime = next(i);
                i += 2;
            }
            "wtime" => {
                limits.wtime = next(i);
                i += 2;
            }
            "btime" => {
                limits.btime = next(i);
                i += 2;
            }
            "winc" => {
                limits.winc = next(i);
                i += 2;
            }
            "binc" => {
                limits.binc = next(i);
                i += 2;
            }
            "movestogo" => {
                limits.movestogo = next(i);
                i += 2;
            }
            "infinite" => {
                limits.infinite = true;
                i += 1;
            }
            _ => i += 1,
        }
    }
    if limits.depth.is_none()
        && limits.movetime.is_none()
        && limits.wtime.is_none()
        && limits.btime.is_none()
        && !limits.infinite
        && !limits.ponder
    {
        limits.infinite = true;
    }
    limits
}
