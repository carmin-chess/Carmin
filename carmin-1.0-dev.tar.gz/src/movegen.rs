//! Legal move generation.
//!
//! Pseudo-legal moves are generated with bitboards, then filtered for
//! legality by making the move and checking whether the mover's king is
//! left in check.

use crate::attacks;
use crate::bitboard::*;
use crate::board::*;
use crate::types::*;

/// A fixed-capacity move list to avoid heap allocations in search.
pub struct MoveList {
    pub moves: [Move; 256],
    pub len: usize,
}

impl MoveList {
    pub fn new() -> MoveList {
        MoveList {
            moves: [Move::new(Square(0), Square(0), MoveFlag::Quiet); 256],
            len: 0,
        }
    }

    #[inline]
    pub fn push(&mut self, mv: Move) {
        self.moves[self.len] = mv;
        self.len += 1;
    }

    #[inline]
    pub fn as_slice(&self) -> &[Move] {
        &self.moves[..self.len]
    }

    #[inline]
    pub fn as_mut_slice(&mut self) -> &mut [Move] {
        &mut self.moves[..self.len]
    }
}

impl Default for MoveList {
    fn default() -> Self {
        MoveList::new()
    }
}

/// Generate all legal moves for the side to move.
///
/// Takes `&mut Board` so legality can be verified with in-place
/// make/unmake (no per-node allocation); the board is left unchanged.
pub fn generate_legal(board: &mut Board) -> MoveList {
    let mut pseudo = MoveList::new();
    generate_pseudo(board, &mut pseudo);

    let mut legal = MoveList::new();
    let us = board.side;
    for &mv in pseudo.as_slice() {
        let undo = board.make_move_fast(mv);
        if !board.in_check(us) {
            legal.push(mv);
        }
        board.unmake_move_fast(mv, undo);
    }
    legal
}

/// Generate only "noisy" legal moves (captures and promotions), used by
/// quiescence search.
pub fn generate_captures(board: &mut Board) -> MoveList {
    let mut pseudo = MoveList::new();
    generate_pseudo_captures(board, &mut pseudo);

    let mut legal = MoveList::new();
    let us = board.side;
    for &mv in pseudo.as_slice() {
        let undo = board.make_move_fast(mv);
        if !board.in_check(us) {
            legal.push(mv);
        }
        board.unmake_move_fast(mv, undo);
    }
    legal
}

pub fn generate_pseudo_captures(board: &Board, list: &mut MoveList) {
    let us = board.side;
    let occ = board.occupancy;
    let enemy = board.color_bb[us.opponent().index()];
    
    gen_pawns(board, list, us, enemy, occ, true, false);
    gen_knights(board, list, us, enemy);
    gen_sliders(board, list, us, enemy, occ, PieceType::Bishop);
    gen_sliders(board, list, us, enemy, occ, PieceType::Rook);
    gen_sliders(board, list, us, enemy, occ, PieceType::Queen);
    gen_king(board, list, us, enemy);
}

pub fn generate_pseudo_quiets(board: &Board, list: &mut MoveList) {
    let us = board.side;
    let occ = board.occupancy;
    let empty = !occ;
    
    gen_pawns(board, list, us, empty, occ, false, true);
    gen_knights(board, list, us, empty);
    gen_sliders(board, list, us, empty, occ, PieceType::Bishop);
    gen_sliders(board, list, us, empty, occ, PieceType::Rook);
    gen_sliders(board, list, us, empty, occ, PieceType::Queen);
    gen_king(board, list, us, empty);
    gen_castles(board, list, us, occ);
}

pub fn generate_pseudo(board: &Board, list: &mut MoveList) {
    generate_pseudo_captures(board, list);
    generate_pseudo_quiets(board, list);
}

fn gen_knights(board: &Board, list: &mut MoveList, us: Color, target_mask: Bitboard) {
    // Cavalos cravados nunca possuem movimentos legais.
    // Descartamos peças cravadas antes da geração.
    let pinned = compute_pinned(board, us);
    let knights = board.pieces_of(us, PieceType::Knight) & !pinned;

    for from in iter(knights) {
        let targets = attacks::knight_attacks(from) & target_mask;
        add_targets(board, list, from, targets);
    }
}

/// Calcula o Bitboard contendo as peças próprias que estão em pino absoluto em relação ao Rei.
fn compute_pinned(board: &Board, us: Color) -> Bitboard {
    let mut pinned = 0;
    let king_sq = board.king_square(us);
    let them = us.opponent();
    let occ = board.occupancy;
    let my_pieces = board.color_bb[us.index()];

    // Identifica atacantes de raio inimigos alinhados ao Rei
    let pinners = (attacks::bishop_attacks(king_sq, 0)
        & (board.pieces_of(them, PieceType::Bishop) | board.pieces_of(them, PieceType::Queen)))
        | (attacks::rook_attacks(king_sq, 0)
        & (board.pieces_of(them, PieceType::Rook) | board.pieces_of(them, PieceType::Queen)));

    for pinner_sq in iter(pinners) {
        let ray = ray_between(king_sq, pinner_sq);
        let blockers = ray & occ;

        // Se existir exatamente 1 peça entre o Rei e o atacante, e for nossa, ela está cravada
        if blockers.count_ones() == 1 {
            let pinned_piece = blockers & my_pieces;
            if pinned_piece != 0 {
                pinned |= pinned_piece;
            }
        }
    }

    pinned
}

/// Função auxiliar interna para gerar as casas estritamente entre duas casas alinhadas.
fn ray_between(a: Square, b: Square) -> Bitboard {
    let sq1 = a.0 as i8;
    let sq2 = b.0 as i8;

    let f1 = sq1 & 7;
    let r1 = sq1 >> 3;
    let f2 = sq2 & 7;
    let r2 = sq2 >> 3;

    let df = (f2 - f1).signum();
    let dr = (r2 - r1).signum();

    if (df == 0 && dr == 0) || (df != 0 && dr != 0 && (f2 - f1).abs() != (r2 - r1).abs()) {
        return 0;
    }

    let step = dr * 8 + df;
    let mut curr = sq1 + step;
    let mut ray = 0u64;

    while curr != sq2 {
        ray |= 1u64 << curr;
        curr += step;
    }

    ray
}

fn gen_king(board: &Board, list: &mut MoveList, us: Color, target_mask: Bitboard) {
    let from = board.king_square(us);
    let targets = attacks::king_attacks(from) & target_mask;
    add_targets(board, list, from, targets);
}

fn gen_sliders(
    board: &Board,
    list: &mut MoveList,
    us: Color,
    target_mask: Bitboard,
    occ: Bitboard,
    kind: PieceType,
) {
    for from in iter(board.pieces_of(us, kind)) {
        let targets = match kind {
            PieceType::Bishop => attacks::bishop_attacks(from, occ),
            PieceType::Rook => attacks::rook_attacks(from, occ),
            PieceType::Queen => attacks::queen_attacks(from, occ),
            _ => unreachable!(),
        } & target_mask;
        add_targets(board, list, from, targets);
    }
}

/// Add quiet/capture moves for a set of destination squares.
fn add_targets(board: &Board, list: &mut MoveList, from: Square, targets: Bitboard) {
    for to in iter(targets) {
        let flag = if board.piece_on(to).is_some() {
            MoveFlag::Capture
        } else {
            MoveFlag::Quiet
        };
        list.push(Move::new(from, to, flag));
    }
}

fn gen_pawns(board: &Board, list: &mut MoveList, us: Color, _target_mask: Bitboard, occ: Bitboard, gen_caps: bool, gen_quiets: bool) {
    let pawns = board.pieces_of(us, PieceType::Pawn);
    let enemy = board.color_bb[us.opponent().index()];
    let empty = !occ;

    let (up, start_rank, promo_rank): (i8, Bitboard, Bitboard) = match us {
        Color::White => (8, RANK_2, RANK_8),
        Color::Black => (-8, RANK_7, RANK_1),
    };

    for from in iter(pawns) {
        if gen_quiets {
            let one = shift(from.bb(), up) & empty;
            if one != 0 {
                let to = lsb(one);
                if to.bb() & promo_rank != 0 {
                    push_promotions(list, from, to, false);
                } else {
                    list.push(Move::new(from, to, MoveFlag::Quiet));
                    if from.bb() & start_rank != 0 {
                        let two = shift(one, up) & empty;
                        if two != 0 {
                            list.push(Move::new(from, lsb(two), MoveFlag::DoublePawnPush));
                        }
                    }
                }
            }
        }

        if gen_caps {
            let caps = attacks::pawn_attacks(us, from) & enemy;
            for to in iter(caps) {
                if to.bb() & promo_rank != 0 {
                    push_promotions(list, from, to, true);
                } else {
                    list.push(Move::new(from, to, MoveFlag::Capture));
                }
            }

            if let Some(ep) = board.en_passant {
                if attacks::pawn_attacks(us, from) & ep.bb() != 0 {
                    list.push(Move::new(from, ep, MoveFlag::EnPassant));
                }
            }
        }
    }
}

fn push_promotions(list: &mut MoveList, from: Square, to: Square, capture: bool) {
    for &pt in &[
        PieceType::Queen,
        PieceType::Rook,
        PieceType::Bishop,
        PieceType::Knight,
    ] {
        let flag = if capture {
            MoveFlag::PromotionCapture(pt)
        } else {
            MoveFlag::Promotion(pt)
        };
        list.push(Move::new(from, to, flag));
    }
}

fn gen_castles(board: &Board, list: &mut MoveList, us: Color, occ: Bitboard) {
    let them = us.opponent();
    if board.in_check(us) {
        return;
    }
    match us {
        Color::White => {
            if board.castling & CASTLE_WK != 0
                && occ & 0x60 == 0
                && !board.is_attacked(Square(5), them)
                && !board.is_attacked(Square(6), them)
            {
                list.push(Move::new(Square(4), Square(6), MoveFlag::KingCastle));
            }
            if board.castling & CASTLE_WQ != 0
                && occ & 0x0E == 0
                && !board.is_attacked(Square(3), them)
                && !board.is_attacked(Square(2), them)
            {
                list.push(Move::new(Square(4), Square(2), MoveFlag::QueenCastle));
            }
        }
        Color::Black => {
            if board.castling & CASTLE_BK != 0
                && occ & (0x60u64 << 56) == 0
                && !board.is_attacked(Square(61), them)
                && !board.is_attacked(Square(62), them)
            {
                list.push(Move::new(Square(60), Square(62), MoveFlag::KingCastle));
            }
            if board.castling & CASTLE_BQ != 0
                && occ & (0x0Eu64 << 56) == 0
                && !board.is_attacked(Square(59), them)
                && !board.is_attacked(Square(58), them)
            {
                list.push(Move::new(Square(60), Square(58), MoveFlag::QueenCastle));
            }
        }
    }
}

/// Shift a bitboard vertically by whole ranks (positive = toward rank 8).
#[inline]
fn shift(bb: Bitboard, delta: i8) -> Bitboard {
    if delta >= 0 {
        bb << delta as u32
    } else {
        bb >> (-delta) as u32
    }
}
