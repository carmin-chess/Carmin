//! Bitboard type alias and small helpers.
//!
//! A `Bitboard` is a `u64` where bit `i` corresponds to square `i`
//! (a1 = bit 0, h8 = bit 63).

use crate::types::Square;

pub type Bitboard = u64;

pub const EMPTY: Bitboard = 0;
pub const FULL: Bitboard = !0;

pub const FILE_A: Bitboard = 0x0101_0101_0101_0101;
pub const FILE_B: Bitboard = FILE_A << 1;
pub const FILE_G: Bitboard = FILE_A << 6;
pub const FILE_H: Bitboard = FILE_A << 7;

pub const RANK_1: Bitboard = 0x0000_0000_0000_00FF;
pub const RANK_2: Bitboard = RANK_1 << 8;
pub const RANK_4: Bitboard = RANK_1 << 24;
pub const RANK_5: Bitboard = RANK_1 << 32;
pub const RANK_7: Bitboard = RANK_1 << 48;
pub const RANK_8: Bitboard = RANK_1 << 56;

pub const NOT_FILE_A: Bitboard = !FILE_A;
pub const NOT_FILE_H: Bitboard = !FILE_H;

/// Number of set bits.
#[inline]
pub fn popcount(bb: Bitboard) -> u32 {
    bb.count_ones()
}

/// Index of the least significant set bit. Undefined if `bb == 0`.
#[inline]
pub fn lsb(bb: Bitboard) -> Square {
    debug_assert!(bb != 0);
    Square(bb.trailing_zeros() as u8)
}

/// Pop the least significant set bit, returning its square.
#[inline]
pub fn pop_lsb(bb: &mut Bitboard) -> Square {
    let sq = lsb(*bb);
    *bb &= *bb - 1;
    sq
}

/// Iterator over the set squares of a bitboard.
pub struct BitIter(pub Bitboard);

impl Iterator for BitIter {
    type Item = Square;

    #[inline]
    fn next(&mut self) -> Option<Square> {
        if self.0 == 0 {
            None
        } else {
            Some(pop_lsb(&mut self.0))
        }
    }
}

#[inline]
pub fn iter(bb: Bitboard) -> BitIter {
    BitIter(bb)
}

/// Pretty-print a bitboard as an 8x8 grid (rank 8 at the top).
#[allow(dead_code)]
pub fn to_string(bb: Bitboard) -> String {
    let mut s = String::new();
    for rank in (0..8).rev() {
        for file in 0..8 {
            let sq = rank * 8 + file;
            s.push(if bb & (1u64 << sq) != 0 { 'X' } else { '.' });
            s.push(' ');
        }
        s.push('\n');
    }
    s
}
